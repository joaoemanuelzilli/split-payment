# Roteiro do prompt do site

Data de referência: 04/11/2026. Este roteiro diz o que o prompt para construir o site precisa conter. O prompt final depende das decisões em aberto no fim deste arquivo.

## Estrutura do prompt

O prompt do site tem oito partes. Ele é escrito para quem vai construir o site, seja uma pessoa ou uma ferramenta de criar sites com IA.

1. **Objetivo.** É um site de diagnóstico de caixa do split payment para a consultoria. O usuário escolhe categoria e nicho, preenche o formulário do setor e vê quanto capital de giro a mais vai precisar e se o caixa aguenta.

2. **Arquivos que acompanham o prompt e as regras de uso.**
   - O JSON é a fonte de todos os dados.
   - O `engine_v2.js` é o cálculo; o site usa o motor como está, sem reescrever as fórmulas.
   - O dicionário explica cada campo.

3. **Telas e fluxo.**
   - Menu de categoria e nicho.
   - Formulário com os campos comuns (caixa, limites, premissas) e os campos do nicho, preenchidos com o padrão, com ajuda, unidade e limites.
   - Resultado.
   - Próximos passos: tese de consultoria, perguntas da reunião e documentos a pedir.

4. **Do formulário para o cálculo.**
   - Como cada campo altera as linhas de receita e de compra (`alvos` e `derivacao`).
   - Uma função própria para os cerca de 25 campos com fórmula mais complexa.
   - Ajustar e avisar quando as porcentagens não somarem 100.
   - Campos de seleção que ativam regras especiais.
   - Simples puro como fluxo separado, que mostra a comparação de regime em vez de rodar o motor.

5. **Tela de resultado.**
   - De 2027 a 2033, cenários favorável e prudente lado a lado.
   - De onde vem o número: imposto que sai antes, crédito que espera o fornecedor pagar e saldo credor.
   - O saldo credor que já existe sem split, mostrado à parte.
   - Teste de caixa com semáforo e custo por ano.
   - Gráfico por ano.

6. **Avisos obrigatórios.** Vêm do relatório de revisão:
   - é diagnóstico financeiro, não parecer jurídico;
   - as datas do split são previsão;
   - os dois cenários aparecem sempre;
   - as estimativas são marcadas (crédito presumido, diesel, IBS, CBS de 2027);
   - o site não promete enquadramento nem prazo de ressarcimento.

7. **Teste de aceite.** Com os valores padrão, cada um dos 123 nichos tem de dar o mesmo `resultado_exemplo` que está na base. Assim vocês sabem se a implementação está certa.

8. **Requisitos gerais.** Português, funcionar no celular, visual limpo e exportar o resultado em PDF para mandar ao cliente.

## Decisões em aberto antes de escrever o prompt

Quatro decisões mudam o prompt:
- **Onde o site vai ser feito:** uma ferramenta tipo Lovable ou v0, ou um desenvolvedor.
- **Quem usa:**
  - só os consultores, como ferramenta interna;
  - ou o dono da empresa direto, como isca para captar clientes, com cadastro antes do resultado.
- **Simulações por cliente:** se precisam ficar salvas, o site precisa de login e banco de dados.
- **Identidade visual:** nome, cores e logo da consultoria.

## Os campos do formulário

A base já define os campos que o site deve mostrar para o usuário digitar os dados do cliente, em duas partes.

**Campos de cada nicho** (`campos_especificos`): de 5 a 14 por nicho, no vocabulário do setor. No produtor rural, por exemplo:
- se a fazenda é contribuinte de IBS/CBS;
- quanto dos grãos vai para cerealista e quanto para trading;
- quanto é boi vendido a frigorífico;
- em quantos dias recebe;
- quanto gasta com diesel e quanto compra de máquinas por ano.

Cada campo já traz o tipo (moeda, percentual, dias, seleção), os limites, um texto de ajuda e o que ele muda no cálculo.

**Campos comuns a todos os nichos** (`contexto_global.campos_comuns_formulario`):
- **Teste de caixa:** caixa hoje, caixa mínimo, limites de crédito não usados, custo do crédito, geração de caixa por mês e CDI.
- **Premissas que vocês podem mudar:** CBS de 2027, IBS cheio, adesão ao split em 2027 e de 2028 em diante, prazo do ressarcimento e ano do teste.

Os valores de `padrao` são só um exemplo de empresa típica, para o formulário não abrir vazio. Vocês trocam pelos números do cliente e o site recalcula.

Há mais duas listas por nicho que não são campos de digitar. `perguntas_diagnostico` é o roteiro da reunião e `dados_para_coletar` é a lista de documentos a pedir ao cliente. O site pode mostrá-las como checklist.

No prompt, isso vira uma instrução clara: o site monta o formulário a partir desses campos, com todos editáveis e preenchidos com o padrão, recalcula a cada mudança e permite salvar a simulação de cada cliente.
