# Split payment: impacto no caixa do middle market

Versão em arquivo do documento online: https://claude.ai/artifact/SbGCVj2A4wW2HmEt4pJK9r

Nov 3, 2026 · @ZIZA

## Resumo em 1 minuto

O split payment não muda quanto imposto a empresa paga, muda quando: o IBS/CBS passa a sair no momento em que o cliente paga, e não mais no último dia útil do mês seguinte. Para uma média empresa que vende a clientes do regime regular e recebe em até 30 dias, isso tira do caixa, de uma vez, entre 0,5 e 1,5 mês de débito de CBS. Entre 2029 e 2033, com a entrada do IBS, esse valor cresce de 2,5 a 3 vezes.

- **Status em 03/11/2026:** a regra está em lei (LC 214/2025, arts. 31 a 36), a plataforma está em testes com bancos desde 15/10/2026 e não há ato oficial com data de início. A Receita prevê uso facultativo, só entre empresas, no 2º semestre de 2027, e obrigatório entre empresas em 2028, meta ainda sem norma. Cartão e consumidor final não têm data.
- **O que já pesa em 2027, mesmo sem split:** a CBS cheia substitui PIS/Cofins em 01/01/2027 (o TCU calculou a alíquota de referência em 11,3468%; o Senado decide até 15/12/2026). E o crédito do comprador passa a depender do pagamento do fornecedor assim que o recolhimento pelo adquirente (RAD) estiver disponível, o que empurra clientes grandes a exigir RAD ou split dos fornecedores médios.
- **De onde vem o buraco:** (1) perda do prazo entre receber do cliente e recolher o imposto; (2) crédito das compras liberado mais tarde; (3) recebível antecipável passa a ser só o valor líquido; (4) saldo credor que vai para ressarcimento em 30, 60 ou 180 dias.
- **Por que o middle market:** usa o imposto a recolher como capital de giro sem saber, antecipa recebíveis, tem margem fina e não tem controladoria para medir o efeito antes que ele chegue.
- **A oportunidade:** um diagnóstico de caixa do split que responde quanto sai, quando sai e quem cobre (caixa próprio, crédito ou aporte do sócio), vendido junto com o contador da empresa, que vira acompanhamento mensal e depois software. O simulador protótipo da seção 8 já faz essa conta.

## Como o split payment funciona

No split, o banco ou a instituição de pagamento do vendedor separa o IBS/CBS no momento da liquidação e repassa ao governo; o vendedor recebe só o líquido. Hoje o vendedor recebe o valor cheio e recolhe o imposto no vencimento; com a CBS, esse vencimento é o último dia útil do mês seguinte ao da apuração ([art. 45 da parte comum dos regulamentos](https://radardareformatributaria.com/vencimento-ibs-cbs-ultimo-dia-util-mes-seguinte/)).

**Quem faz o quê.** A lei obriga os prestadores de serviço de pagamento a segregar e recolher (LC 214, art. 31). Na primeira fase, o uso é opcional para quem origina o pagamento, mas a implementação é obrigatória para todos os PSPs dos arranjos cobertos; a opção é feita preenchendo três campos novos: CBS informado, IBS informado e chave do documento fiscal ([Manual de Operações, minuta jun/2026](https://www.cgibs.gov.br/upload/arquivos/202606/30145925-minuta-split-payment-manual-de-operacoes.pdf)). No boleto, quem fala com a plataforma do governo é a Núclea.

| Modalidade | Meios de pagamento | Como o valor é definido | Crédito para o comprador | Fase |
| --- | --- | --- | --- | --- |
| Padrão "super inteligente" | Boleto, Pix dinâmico, Pix automático (iniciados pelo recebedor) | Vendedor informa; a plataforma pode corrigir contra a nota e reduzir pelo que já foi extinto | Sim | Fase 1, B2B, facultativa |
| Padrão "inteligente" | Pix estático, Pix por chave, TED, TEF (iniciados pelo pagador) | Banco segrega exatamente o que o pagador informou; excesso volta em 3 dias úteis | Sim | Fase 1, B2B, facultativa |
| Simplificado | Todos, em etapa posterior | Percentual fixo por setor, ainda não publicado | Não (LC 214, art. 33, §7º) | Sem data |
| Recolhimento pelo adquirente (RAD) | Qualquer meio que não permita split | Comprador recolhe por guia e paga o líquido ao fornecedor; excesso volta em 3 dias úteis | Sim | Previsto para 2027 |

Fonte da tabela: [Manual de Operações](https://www.cgibs.gov.br/upload/arquivos/202606/30145925-minuta-split-payment-manual-de-operacoes.pdf), [Decreto 12.955/2026](https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2026/decreto/D12955.htm) e [Fenacon sobre o RAD](https://fenacon.org.br/reforma-tributaria/rad-surge-como-alternativa-ao-split-payment-a-partir-de-janeiro-entenda-o-mecanismo/). Cartões, vouchers, Open Finance e o procedimento simplificado ficam fora da primeira fase.

**Regras que mexem no caixa.**

- **Valor segregado = débito da nota menos o que já foi extinto.** Créditos do vendedor compensados antes do pagamento reduzem a retenção; a imputação segue a ordem cronológica dos documentos, em janelas de até 48 horas, segundo a leitura do regulamento pela [Vectigalia](https://vectigalia.com.br/credito-condicionado-pagamento-fornecedor-ibs-cbs/). Na prática, venda recebida à vista tende a ter retenção cheia.
- **Venda parcelada:** a segregação é proporcional a cada parcela (LC 214, art. 34, II).
- **Antecipação de recebíveis** não é liquidação: a segregação acontece quando o cliente paga, e o banco tende a antecipar só o líquido ([Omie](https://www.omie.com.br/blog/split-payment-informe-segregacao-antecipacao-recebiveis/)).
- **Devolução e cancelamento:** não há estorno por desacordo comercial; o governo devolve o excesso ao vendedor em até 3 dias úteis.
- **Repasse ao governo** em D+N dias úteis após o informe de segregação, com N ainda não publicado.
- **Crédito condicionado:** o comprador só aproveita o crédito quando o débito do fornecedor for extinto (art. 47). A dispensa do art. 48, que dá crédito só pelo destaque na nota, vale apenas enquanto nem o split nem o RAD estiverem implementados; há parecer de que a mera disponibilidade do RAD já encerra a dispensa para quem poderia usá-lo ([Piraci Oliveira](https://piraciadv.blog/2026/09/06/parecer-sobre-o-momento-do-credito-de-cbs-a-partir-de-2027-e-a-relevancia-na-definicao-da-modalidade-hibrida-para-empresas-do-simples/)).
- **Saldo credor:** ressarcimento analisado em 30 dias (programa de conformidade), 60 dias (pedido dentro dos limites do art. 40) ou 180 dias, mais 15 dias para pagar se a Receita não se manifestar ([Decreto 12.955, arts. 39 e 40, via Taxcel](https://taxcel.com.br/credito-cbs-transferencia-ressarcimento-prazos)).

## Cronograma: o que é lei e o que é previsão

Só a CBS cheia em 01/01/2027, a subida do IBS a partir de 2029 e o IVA pleno em 2033 estão em lei com data; tudo o que se diz sobre quando o split começa é previsão, porque o ato conjunto RFB/CGIBS que fixaria o cronograma (LC 214, art. 31, §2º) ainda não foi publicado. Material comercial deve dizer "previsto" para essas datas.

| Data | Evento | Status | Fonte |
| --- | --- | --- | --- |
| 16/01/2025 | LC 214 cria o split (arts. 31 a 35) e o RAD (art. 36) | Lei | [Planalto](https://www.planalto.gov.br/ccivil_03/leis/lcp/lcp214.htm) |
| 30/04/2026 | Decreto 12.955 (regulamento da CBS): etapa 1 só com procedimento padrão, comprador do regime regular, boleto, Pix, TED e TEF, facultativa; sem datas | Regulamento | [Planalto](https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2026/decreto/D12955.htm) |
| 03/06/2026 | Manual de Integração e especificação da Plataforma Pública publicados | Técnico | [Receita Federal](https://www.gov.br/receitafederal/pt-br/assuntos/noticias/2026/junho/receita-federal-e-cgibs-publicaram-hoje-a-documentacao-tecnica-da-plataforma-publica-do-split-payment) |
| 12/08/2026 | CGIBS: split não estará disponível em janeiro de 2027, a pedido dos próprios bancos | Declaração | [Contábeis](https://www.contabeis.com.br/noticias/78723/split-payment-nao-comeca-em-janeiro-de-2027-entenda/) |
| 30/08/2026 | Receita trabalha com 2028 para a obrigatoriedade geral, "ainda não estabelecida em norma" | Previsão | [Estadão/Mercado&Consumo](https://mercadoeconsumo.com.br/30/08/2026/estadao-conteudo/receita-preve-obrigatoriedade-do-split-payment-para-2028-saiba-o-que-falta/) |
| 05/10/2026 | Campos que ligam pagamento e nota (grupo YC, evento 110300) em produção na NF-e | Técnico | [NT 2026.006](https://www.reformatributaria.com/wp-content/uploads/2026/08/NT_2026.006_v1.00_RTC_VinculacaoPagamento.pdf) |
| 15/10/2026 | Início dos testes de integração entre bancos e a plataforma, sem transações definitivas nem multas | Em curso | [IstoÉ Dinheiro](https://istoedinheiro.com.br/split-payment-reforma-tributaria-testes-receita-federal) |
| 28/10/2026 | TCU calcula a alíquota de referência da CBS 2027 em 11,3468%, contra 9,21% estimados antes | Ocorrido | [Agência Brasil](https://agenciabrasil.ebc.com.br/economia/noticia/2026-10/tcu-aprova-calculo-da-aliquota-de-referencia-da-cbs-em-113) |
| 10/11/2026 | Audiência pública na CAE do Senado sobre a alíquota; relator Eduardo Braga | Marcado | [Brasil em Folhas, 03/11/2026](https://brasilemfolhas.com.br/2026/11/senado-recebe-calculo-de-aliquota-da-cbs-na-proxima-terca/) |
| 13 e 16/11/2026 | Formulários e inscrição direta de outros PSPs nos testes | Marcado | [IstoÉ Dinheiro](https://istoedinheiro.com.br/split-payment-reforma-tributaria-testes-receita-federal) |
| 15/12/2026 | Prazo do Senado para fixar a CBS; sem resolução, vale o número do TCU | Lei | [Brasil em Folhas](https://brasilemfolhas.com.br/2026/11/senado-recebe-calculo-de-aliquota-da-cbs-na-proxima-terca/) |
| 01/01/2027 | CBS cheia, reduzida em 0,1 p.p., mais IBS de 0,1% (LC 214, arts. 344 e 347); fim de PIS/Cofins | Lei | [Simtax](https://simtax.com.br/reforma-tributaria-2027-cbs-ibs-01-2/) |
| fev/2027 | Primeira guia da CBS (competência janeiro), no último dia útil | Regulamento | [ROIT no reformatributaria.com](https://www.reformatributaria.com/opiniao/prudencia-nao-e-pessimismo-como-chegar-a-janeiro-de-2027-com-o-caixa-pronto-para-a-cbs-que-vence-em-fevereiro/) |
| mar a out/2027 | Etapas reportadas pela imprensa: TEF restrito em 01/03; TED e Pix estático em 03/05; boleto e Pix dinâmico em teste em 01/07; abertura a todas as empresas em 02/08 e 04/10 | Previsão, sem ato | [Contábeis, 28/10/2026](https://www.contabeis.com.br/noticias/80411/split-payment-comeca-a-ser-implementado-em-2027-veja-o-cronograma/) |
| 2028 | Split obrigatório entre empresas | Meta da Receita | [Estadão/Mercado&Consumo](https://mercadoeconsumo.com.br/30/08/2026/estadao-conteudo/receita-preve-obrigatoriedade-do-split-payment-para-2028-saiba-o-que-falta/) |
| 2029 a 2032 | IBS sobe de cerca de 10% a 40% da alíquota cheia; ICMS e ISS caem a 90%, 80%, 70% e 60% | Lei | [EC 132](https://www.planalto.gov.br/ccivil_03/constituicao/Emendas/Emc/emc132.htm) |
| 2033 | IVA completo (CBS + IBS); fim de ICMS e ISS | Lei | [EC 132](https://www.planalto.gov.br/ccivil_03/constituicao/Emendas/Emc/emc132.htm) |

Para o IBS cheio, a única referência pública é a projeção metodológica de 18,7% do CGIBS (Resolução CGIBS 14/2026), que somada à CBS do TCU passaria de 30% ([BMA](https://www.bmalaw.com.br/conteudo/direito-tributario/reforma-tributaria/reforma-tributaria-cgibs-divulga-nova-estimativa-para-as-aliquota-de-referencia-em-2027/pdf)).

## De onde vem o buraco no caixa

Numa distribuidora B2B de R$ 3 milhões/mês, o split e o crédito condicionado pedem de R$ 0,24 a 0,91 milhão a mais de capital de giro em 2028, e de R$ 0,64 a 2,4 milhões em 2033. A largura da faixa vem de uma regra ainda não publicada: se os créditos da empresa abatem a retenção em tempo real ou só na apuração mensal.

O que muda é o prazo, não a carga. São quatro efeitos, medidos contra o mesmo ano sem split e com crédito pelo destaque:

1. **Débito sai antes.** Hoje o imposto de uma venda recebida antes do vencimento fica no caixa até o último dia útil do mês seguinte, 45 dias em média depois da venda. Com split, sai na liquidação. Venda recebida depois do vencimento não muda, porque o imposto já é pago no vencimento.
2. **Recebível antecipado encolhe.** O banco passa a antecipar só o líquido. A empresa perde o imposto que hoje recebe na antecipação e usa até o vencimento: cerca de 43 dias de débito num recebível de 35 dias.
3. **Crédito das compras chega depois.** O crédito só vale quando o débito do fornecedor é extinto. Se ele recolhe no próprio vencimento, o crédito chega um mês depois do que chegaria hoje, e isso pode começar já em 2027 com o RAD.
4. **Saldo credor parado.** Se a compensação for só mensal e quase tudo for retido no split, sobram créditos sem débito em aberto para abater, e eles vão para ressarcimento em 60 dias mais 15. Pesa em quem tem margem fina e compra muito: distribuidor, atacado, exportador.

Regra de bolso para o efeito 1, em dias de débito de CBS/IBS que saem do caixa por prazo de recebimento:

| Prazo de recebimento | Dias de débito que saem do caixa |
| --- | --- |
| À vista (Pix, TED, D+1) | 44 |
| 15 dias | 30 |
| 30 dias | 15 |
| 45 dias | 4 |
| 60 dias ou mais | 0 |
| 35 dias, antecipado no banco | 43 |

O exemplo do gráfico abaixo usa o simulador da seção 8 com uma distribuidora: R$ 3 milhões/mês de vendas, 85% para empresas do regime regular, 20% recebido à vista e 75% em 35 dias (40% disso antecipado), compras com crédito de 80% das vendas, pagamento a fornecedores em 30 dias, CBS de 11,35% em 2027 e 2028 e IBS cheio de 18,7% em 2033. Adesão ao split de 30% das vendas B2B em 2027 e 100% a partir de 2028.

| Efeito em 2028 | Favorável (compensação em até 48 h) | Prudente (compensação só mensal) |
| --- | --- | --- |
| 1 e 2. Débito sai antes | R$ 256 mil | R$ 256 mil |
| 3. Crédito condicionado | −R$ 13 mil | R$ 259 mil |
| 4. Saldo credor em ressarcimento | zero | R$ 393 mil |
| **Total a colocar na frente** | **R$ 242 mil** | **R$ 907 mil** |

![Capital de giro extra da distribuidora B2B, 2027 a 2033](grafico-distribuidora.png)

No cenário prudente, cada ano de 2029 a 2032 pede cerca de R$ 150 mil novos, e 2033 traz o maior salto, R$ 0,9 milhão, quando o IBS vai à alíquota cheia.

Para os R$ 907 mil de 2028, essa empresa cobre R$ 500 mil com caixa livre e precisa de R$ 407 mil de crédito; o custo de juros e de oportunidade fica em R$ 172 mil por ano, 0,48% do faturamento ou 9,5% da geração de caixa. ICMS e ISS não entram no split e seguem como hoje até 2028.

## Por que o middle market é o mais exposto

A média empresa reúne os gatilhos do buraco e não tem como vê-lo chegar: vende para grandes compradores que vão exigir split ou RAD, recebe rápido ou antecipa recebíveis, trabalha com margem fina e não tem controladoria medindo a necessidade de capital de giro. O imposto a recolher financia o giro dela hoje sem aparecer em nenhum contrato de crédito.

- **O cliente grande dita a regra.** Como o crédito do comprador depende da extinção do débito do fornecedor, o comprador grande tende a pagar com split ou RAD. A Lojas Torra disse que quer controlar o RAD para fornecedores de maior risco, recém-abertos e de operações de alto valor ([Dootax](https://dootax.com.br/split-payment-rad/)).
- **O Presumido multiplica por 2,5 a 3 o débito que passa pelo caixa.** Sai do PIS/Cofins cumulativo de 3,65% para uma CBS de 9% a 11,35% sobre as vendas, com crédito nas compras; o float maior de 2027 é justamente o que o split retira depois.
- **O primeiro vencimento já aperta.** Numa carteira de mais de 7 mil CNPJs, a ROIT estimou que o tributo federal sobre consumo pode ir de 0,73% para até 3,41% do faturamento na guia de fevereiro de 2027, no pior caso sem créditos de CBS a tempo ([reformatributaria.com, 22/10/2026](https://www.reformatributaria.com/opiniao/prudencia-nao-e-pessimismo-como-chegar-a-janeiro-de-2027-com-o-caixa-pronto-para-a-cbs-que-vence-em-fevereiro/)).
- **Pouca gente mediu.** Na pesquisa da ROIT, 37% de 70 médias e grandes empresas não tinham avaliado o efeito do split no capital de giro ([Contábeis](https://www.contabeis.com.br/noticias/78908/24-das-empresas-nao-sabem-impacto-da-reforma-tributaria/)); a Toku disse que o cliente não entende o split porque nunca precisou viver sem esse capital de giro ([Finsiders](https://finsidersbrasil.com.br/noticias-sobre-fintechs/rad-e-split-payment-avancam-mas-empresas-ainda-tem-duvidas-sobre-operacao/)).

Quatro perfis rodados no simulador, com as mesmas premissas de alíquota e adesão da seção anterior:

| Perfil (vendas/mês) | Premissas que pesam | Capital extra em 2028, em % de um mês de vendas | Motor principal |
| --- | --- | --- | --- |
| Distribuidora B2B (R$ 3 mi) | 20% à vista, 75% em 35 dias (40% antecipado), compras de 80% das vendas | 8% a 30% | Saldo credor, se a compensação for mensal |
| Indústria (R$ 4 mi) | 90% em 60 dias (30% antecipado), compras de 55% | 12% | Recebível antecipado e crédito condicionado |
| Serviços B2B no Presumido (R$ 0,8 mi) | 30% via Pix, 70% em 20 dias, compras de 15% | 10% a 12% | Débito sai antes |
| Varejo misto (R$ 2,5 mi) | 50% em cartão, fora da fase 1; 30% B2B | 8% a 10% | Crédito condicionado nas compras |

Quem tem crédito estrutural acima do débito (investimento pesado, vendas com alíquota reduzida, exportação) fica refém do prazo de ressarcimento. Já a indústria que recebe em 60 dias sem antecipar quase não sente o efeito nas vendas: o imposto já sai antes de ela receber.

## Metodologia do diagnóstico de capital de giro

O diagnóstico responde três perguntas com dados que a empresa já tem, em cerca de uma semana: quanto dinheiro o split tira do caixa, em que ano e mês, e quem cobre esse valor (caixa próprio, crédito ou aporte do sócio). O ponto central para o dono: é uma necessidade permanente de capital de giro, que cresce com o IBS até 2033, e não um aperto de um mês.

1. **Coletar 12 meses de dados.** Vendas por cliente e por meio de recebimento (ERP, relatório de boletos, extrato bancário em OFX, maquininha); contas a receber com vencimentos e o que foi antecipado; compras e despesas com crédito e prazo de pagamento; saldo de caixa, limites e taxas das linhas; geração de caixa mensal. XML das notas e a EFD-Contribuições fecham o que o ERP não tiver.
2. **Classificar os clientes.** Pelo CNPJ, separar regime regular, Simples e consumidor final, e marcar os 20 maiores compradores: são eles que vão exigir split ou RAD primeiro. Isso define a parcela das vendas sujeita à retenção em cada ano.
3. **Medir o float de hoje.** Para cada grupo de recebimento, quantos dias de débito ficam no caixa até o vencimento (regra de bolso da seção 4). Recebível antecipado conta como recebido em D+2.
4. **Projetar os quatro efeitos por ano, de 2027 a 2033,** com a alíquota de cada ano (CBS do Senado ou do TCU, IBS subindo de 2029 a 2033) e em dois cenários de compensação de créditos, favorável e prudente:

```latex
\Delta NCG_{ano} = \frac{D \cdot s \cdot \sum_g w_g \, \text{dias}_g}{30} + \frac{C \cdot \text{atraso do crédito}}{30} + \text{saldo em ressarcimento}
```

Onde D é o débito mensal de CBS/IBS, s a parcela das vendas com split ou RAD, w e dias o peso e os dias de float de cada grupo de recebimento, e C o crédito mensal das compras.

5. **Testar se o caixa suporta.** Primeiro o caixa livre (caixa menos o mínimo de segurança), depois os limites já aprovados, e o que sobrar é lacuna: aporte do sócio ou linha nova. Três números resumem o risco: cobertura (caixa livre mais limites, dividido pela necessidade), custo anual dividido pela geração de caixa e meses de geração de caixa para repor.
6. **Dar o semáforo.** Verde: o caixa livre cobre e o custo fica abaixo de 5% da geração de caixa. Amarelo: precisa de crédito dentro do limite e o custo fica abaixo de 15%. Vermelho: falta dinheiro mesmo com todo o limite, ou o custo passa de 15%.
7. **Montar o plano de cobertura.** Em ordem de custo:
   - negociar prazo com fornecedores e encurtar o prazo dado a clientes que pagam com split;
   - combinar com os grandes compradores quem recolhe (split ou RAD) e em que prazo, já em contrato;
   - repassar no preço o custo financeiro, que nos perfis simulados ficou entre 0,1% e 0,5% do faturamento;
   - pedir o programa de conformidade, que leva a análise do ressarcimento a 30 dias;
   - contratar a linha antes da virada, com prazo longo, porque é necessidade permanente;
   - só então aporte do sócio, comparando o custo da dívida com o que o dinheiro dele rende hoje.

Aporte da pessoa física pode entrar como aumento de capital ou como mútuo; o mútuo exige contrato e tem IOF, e a escolha deve passar pelo contador. Financiar uma necessidade permanente rolando dívida de curto prazo é o erro clássico que o guia da EESC Finance aponta para quem não se preparou.

## Como transformar em consultoria

Venda um diagnóstico de caixa do split com preço fechado, feito junto com o contador da empresa, que termina num plano de cobertura e vira acompanhamento mensal quando o split entrar em produção. O espaço está vazio: ERPs já emitem a nota com IBS/CBS e as grandes consultorias atendem grandes empresas, mas ninguém vende para a média empresa a conta de quanto caixa ela precisa e de onde ele vem.

| Degrau | O que entrega | Prazo | Preço de referência | Para quem |
| --- | --- | --- | --- | --- |
| Raio-X do split | Simulador com 10 números e semáforo, em reunião | 30 min | Grátis, como porta de entrada via contador | Qualquer média B2B |
| Diagnóstico de caixa | 12 meses de dados, capital de giro extra por ano de 2027 a 2033 em dois cenários, teste de suporte, plano de cobertura | 1 a 2 semanas | R$ 2 mil a R$ 15 mil | Presumido e Real com vendas de R$ 0,5 a 30 mi/mês |
| Plano de cobertura | Negociação de prazos, cláusulas de split/RAD com grandes clientes, estruturação da linha de capital de giro, repasse de preço | 4 a 8 semanas | Fixo mais êxito sobre o caixa liberado | Quem saiu amarelo ou vermelho |
| Monitor mensal | Conciliação bruto, líquido e segregado; crédito condicionado por fornecedor; caixa projetado em 13 semanas | Mensal | R$ 1,5 mil a R$ 3,7 mil/mês | Quem já tem split ou RAD em produção |

As faixas de preço do diagnóstico e da consultoria mensal são as relatadas por escritórios contábeis em evento de 25/09/2026 ([reformatributaria.com](https://www.reformatributaria.com/iva/contadores-buscam-novas-formas-de-monetizar-e-precificar-servicos-com-a-reforma-tributaria/)); não há pesquisa de disposição a pagar em reais, então valide com pré-venda.

**Canal.** O contador é o filtro: 68% já foram procurados por clientes sobre a reforma e só cerca de 5% têm plano estruturado ([Sondagem Omie do setor contábil, 1º sem/2026](https://www.omie.com.br/assets/docs/report_sondagem_omie_contabil_1S2026.pdf)). Ofereça a ele o diagnóstico em formato de parceria, com a conta de caixa do seu lado e a parte tributária assinada por ele. Bancos, FIDCs e cooperativas de crédito são o segundo canal: precisam reprecificar a antecipação de recebíveis, que vira base líquida, e querem originar linhas de capital de giro. Se você já trabalha com crédito, deixe claro ao cliente quando a linha recomendada é sua, para não contaminar o diagnóstico.

**Tamanho.** São cerca de 1,51 milhão de empresas no Lucro Presumido e 230 mil no Lucro Real, que é onde está o middle market; a dor de caixa é maior nas que vendem B2B, recebem rápido ou antecipam (dados da RFB compilados no estudo do repositório).

**Cuidado regulatório.** Parecer sobre interpretação da lei tributária tem sido tratado por tribunais como atividade de advocacia, e consultoria tributária é atividade compartilhada com contadores (Resolução CFC 1.640/2021). Posicione o serviço como análise financeira e de tesouraria, e deixe a leitura jurídica das regras para o contador ou advogado parceiro.

## O software: o que automatizar

O produto que falta para a média empresa é a previsão de caixa sob split: ler os dados que ela já tem, calcular o capital de giro extra ano a ano e, quando o split estiver em produção, acompanhar todo mês o que foi retido, o crédito liberado e o saldo a ressarcir. O [Simulador de Caixa do Split](https://claude.ai/artifact/JYLcmkY1txKn8JPUc39hGj) é o protótipo da primeira parte: dez números de entrada, faixa favorável a prudente de 2027 a 2033, semáforo, quem cobre e alavancas.

Não construa o cálculo do imposto. A Receita distribui a calculadora oficial em código aberto e a apuração assistida já pré-calcula débitos e créditos; o valor está em ligar isso ao financeiro da empresa.

| Módulo | Entra | Sai | Quando |
| --- | --- | --- | --- |
| Simulador (protótipo pronto) | 10 números da empresa | Faixa de capital de giro extra, semáforo, cobertura, alavancas | Já, na pré-venda |
| Diagnóstico com dados reais | XML das notas, extratos OFX e retorno de cobrança, contas a pagar, regime de cada cliente pelo CNPJ | Capital extra por ano, por cliente e por meio de pagamento; curva mensal da virada; relatório | 1º semestre de 2027 |
| Monitor mensal | Arquivos de retorno dos bancos com valor original, pago e líquido e CBS/IBS informado, corrigido, em aberto e segregado; APIs da apuração assistida | Conciliação dos três valores, crédito pendente por fornecedor, excesso retido a devolver, caixa projetado em 13 semanas | Quando o split facultativo abrir, previsto para o 2º semestre de 2027 |
| Risco de fornecedor | Histórico de extinção dos débitos dos fornecedores | Crédito em risco e sugestão de RAD por fornecedor | 2028 |

O manual do split já obriga os bancos a entregar ao cliente PJ arquivos de retorno com esses campos ([Manual de Operações](https://www.cgibs.gov.br/upload/arquivos/202606/30145925-minuta-split-payment-manual-de-operacoes.pdf)), o que dá ao monitor uma fonte de dados padronizada sem integrar com a Plataforma Pública, que é restrita a PSPs.

Ordem de construção, presa ao calendário:

1. **Nov/2026 a fev/2027:** simulador e diagnóstico semimanual (planilha mais simulador) para fechar os primeiros contratos e calibrar premissas com dados reais.
2. **Mar a jun/2027:** importadores de XML e OFX e relatório automático; só automatize o que se repetiu em três clientes.
3. **Jul a dez/2027:** monitor lendo os arquivos de retorno à medida que bancos e empresas aderem ao split facultativo.
4. **2028 em diante:** assinatura por CNPJ, integração com ERPs usados pela média empresa e recalibração anual com o IBS subindo até 2033.

## Riscos, pontos em aberto e datas

O maior risco para quem vende esse serviço não é o split ser cancelado, e sim a data escorregar aos poucos e a urgência do cliente sumir; por isso a oferta deve se apoiar no que acontece de qualquer jeito em 2027 (CBS cheia, crédito condicionado, RAD), e não numa data do split.

**Pontos em aberto que mudam a conta:**

- **Compensação dos créditos:** em tempo real ou só na apuração mensal. É a diferença entre os cenários favorável e prudente, e pode valer centenas de milhares de reais numa distribuidora.
- **Fim da dispensa do art. 48:** se a simples disponibilidade do RAD em 2027 já condiciona o crédito de todas as compras. Há leitura nos dois sentidos.
- **Alíquota da CBS 2027:** 11,35% do TCU ou algo perto dos 9,21% estimados antes; muda o tamanho de todos os efeitos na mesma proporção.
- **Detalhes operacionais não publicados:** prazo D+N do repasse, percentuais do procedimento simplificado, regras de tempo da apuração assistida e a redução da devolução de 3 dias úteis para 24 horas, que a Receita estuda.
- **Pressão por adiamento:** tributaristas e parte da oposição pedem pausa, mas as datas-mestras estão na Constituição e mudar exige PEC; o estudo do repositório estimou em cerca de 10% a chance de adiamento formal da CBS.
- **Concorrência:** ERPs e bancos podem lançar simulador gratuito; a janela para consultoria tende a ser de 24 a 36 meses, como em ondas anteriores (SPED, eSocial).
- **Fornecedor inadimplente:** crédito que nunca chega não está no simulador e precisa de uma linha própria no diagnóstico.

| Data | O que acompanhar | Por que importa |
| --- | --- | --- |
| 10/11/2026 | Audiência pública na CAE sobre a alíquota da CBS | Sinal de onde o Senado vai fechar o número |
| 13 e 16/11/2026 | Abertura dos testes a outros PSPs | Quais bancos estarão prontos primeiro |
| 15/12/2026 | Resolução do Senado com a CBS 2027 | Sem ela, vale o cálculo do TCU |
| 01/01/2027 | CBS cheia e fim de PIS/Cofins | Começa o crédito condicionado, se o RAD estiver disponível |
| fim de fev/2027 | Primeira guia da CBS | Primeiro teste real de caixa das empresas |
| mar a out/2027 | Etapas previstas do split facultativo | Momento de vender o monitor mensal |
| 2028 | Obrigatoriedade entre empresas, se confirmada | O efeito vira 100% das vendas B2B |
| 2029 a 2033 | IBS subindo até a alíquota cheia | O capital extra cresce de 2,5 a 3 vezes |

## Fontes

Base do estudo: o repositório [joaoemanuelzilli/split-payment](https://github.com/joaoemanuelzilli/split-payment) (relatório de viabilidade e notas de 01/11/2026), conferido e atualizado com as páginas abaixo em 03/11/2026. Isto é análise financeira, não parecer jurídico ou contábil.

- [Manual de Operações do split, minuta jun/2026 (CGIBS)](https://www.cgibs.gov.br/upload/arquivos/202606/30145925-minuta-split-payment-manual-de-operacoes.pdf)
- [Decreto 12.955/2026, regulamento da CBS (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2026/decreto/D12955.htm)
- [LC 214/2025 (Planalto)](https://www.planalto.gov.br/ccivil_03/leis/lcp/lcp214.htm)
- [Vencimento do IBS/CBS no último dia útil do mês seguinte (Radar da Reforma Tributária)](https://radardareformatributaria.com/vencimento-ibs-cbs-ultimo-dia-util-mes-seguinte/)
- [Prazos de ressarcimento da CBS (Taxcel)](https://taxcel.com.br/credito-cbs-transferencia-ressarcimento-prazos)
- [Crédito condicionado à extinção do débito (Vectigalia)](https://vectigalia.com.br/credito-condicionado-pagamento-fornecedor-ibs-cbs/)
- [Parecer sobre o momento do crédito de CBS em 2027 (Piraci Oliveira)](https://piraciadv.blog/2026/09/06/parecer-sobre-o-momento-do-credito-de-cbs-a-partir-de-2027-e-a-relevancia-na-definicao-da-modalidade-hibrida-para-empresas-do-simples/)
- [Split payment e crédito condicionado (Migalhas, 28/10/2026)](https://www.migalhas.com.br/depeso/467031/o-empresario-que-morre-de-acerto-split-payment-e-credito-condicionado)
- [Split, RAD e fluxo de caixa em 2027 (Migalhas)](https://www.migalhas.com.br/depeso/467351/split-payment-recolhimento-pelo-adquirente-e-o-fluxo-de-caixa)
- [TCU calcula a CBS 2027 em 11,3468% (Agência Brasil, 28/10/2026)](https://agenciabrasil.ebc.com.br/economia/noticia/2026-10/tcu-aprova-calculo-da-aliquota-de-referencia-da-cbs-em-113)
- [Senado recebe o cálculo e marca audiência (Brasil em Folhas, 03/11/2026)](https://brasilemfolhas.com.br/2026/11/senado-recebe-calculo-de-aliquota-da-cbs-na-proxima-terca/)
- [CBS menos 0,1 p.p. e IBS de 0,1% em 2027 e 2028 (Simtax)](https://simtax.com.br/reforma-tributaria-2027-cbs-ibs-01-2/)
- [Estimativa do CGIBS para o IBS de referência (BMA)](https://www.bmalaw.com.br/conteudo/direito-tributario/reforma-tributaria/reforma-tributaria-cgibs-divulga-nova-estimativa-para-as-aliquota-de-referencia-em-2027/pdf)
- [Testes do split com PSPs a partir de 15/10/2026 (IstoÉ Dinheiro)](https://istoedinheiro.com.br/split-payment-reforma-tributaria-testes-receita-federal)
- [Split não começa em janeiro de 2027 (Contábeis)](https://www.contabeis.com.br/noticias/78723/split-payment-nao-comeca-em-janeiro-de-2027-entenda/)
- [Cronograma reportado para 2027 (Contábeis, 28/10/2026)](https://www.contabeis.com.br/noticias/80411/split-payment-comeca-a-ser-implementado-em-2027-veja-o-cronograma/)
- [Obrigatoriedade prevista para 2028 (Nota Gateway)](https://notagateway.com.br/blog/split-payment-adiado/)
- [Caixa para a primeira guia da CBS (ROIT no reformatributaria.com)](https://www.reformatributaria.com/opiniao/prudencia-nao-e-pessimismo-como-chegar-a-janeiro-de-2027-com-o-caixa-pronto-para-a-cbs-que-vence-em-fevereiro/)
- [37% não avaliaram o split no capital de giro (Contábeis)](https://www.contabeis.com.br/noticias/78908/24-das-empresas-nao-sabem-impacto-da-reforma-tributaria/)
- [RAD e split no debate com empresas (Finsiders)](https://finsidersbrasil.com.br/noticias-sobre-fintechs/rad-e-split-payment-avancam-mas-empresas-ainda-tem-duvidas-sobre-operacao/)
- [Como contadores devem orientar sobre capital de giro (Contábeis)](https://www.contabeis.com.br/noticias/79155/split-payment-afeta-capital-de-giro-como-orientar-empresas/)
