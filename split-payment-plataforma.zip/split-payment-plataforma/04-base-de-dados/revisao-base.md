# Revisão final da base de nichos: split payment de IBS/CBS

Data de referência: 04/11/2026. Revisor independente. Arquivos revisados: `out_L1.json` a `out_L9.json` (123 nichos). A base consolidada foi gerada de novo com `node merge.js` depois das correções.

## 1. Resumo

- **Estado final.** Os 9 lotes passam no `validate.js` ("TUDO OK", 123 nichos, nenhum faltando). O `merge.js` gerou `base_consolidada.json` com os 123 nichos.
- **Volume.** Foram 491 mudanças registradas em 94 nichos: 427 edições de conteúdo e 64 fontes acrescentadas. As mudanças foram mínimas e campo a campo. Nenhum nicho foi reescrito. A estrutura de chaves de todos os registros ficou igual à original.
- **A correção que mais muda números: momento do fato gerador.** Em 24 nichos com contrato mensal ou por etapa, o prazo de recebimento estava contado da nota até o pagamento (30 a 45 dias). Pelo art. 10, §3º, na redação da LC 227/2026 (conferida), o imposto nasce quando a parcela fica exigível, isto é, no vencimento. O L9 já fazia assim. Passei esses nichos para "atraso depois do vencimento" (padrão de 3 dias) e troquei os campos do formulário. O efeito de 2028 mais que dobrou em vários deles: limpeza foi de 4,6% para 9,6% de um mês de receita (cenário prudente); TI, de 5,6% para 12,6%; manutenção industrial, de 6,9% para 21,8%; refeições coletivas, de 5,7% para 12,4%.
- **Seis contradições entre lotes resolvidas com texto e números únicos:**
  - alíquota zero e manutenção de crédito: arts. 47, §10, e 51, conferidos;
  - escopo do Anexo VIII: 7 NCMs, art. 136, conferidos no Senado;
  - art. 127 e consultoria;
  - crédito presumido de produtor rural (1,1% a 3,0%) e de transportador autônomo (2,9% a 9,2%);
  - Imposto Seletivo;
  - CBS do diesel: 4,6% do preço em 2027-2028, em vez de 100% ou 6%.
- **Duas contradições novas, achadas na revisão:**
  - **Academia (C03-11):** a base dizia que o art. 127 exigia requisitos societários. O §3º do art. 127 dispensa esses requisitos para a pessoa jurídica de educação física fiscalizada pelo conselho. O padrão passou a ser 70% da cheia, como interpretação.
  - **Imobiliária (C07-08):** a comissão tinha prazo de 30 dias, mas o art. 254, §2º, põe o imposto em cada pagamento. O prazo passou a 0.
- **O que continua aberto e importa:**
  - os percentuais oficiais do crédito presumido de 2027 (não há ato conjunto na lista do CGIBS em 04/11/2026);
  - a regra de compensação em 48 horas ou mensal, que separa os cenários favorável e prudente;
  - a MP do Imposto Seletivo, anunciada para 04/11/2026 e não publicada até 03/11;
  - a NBS das academias;
  - o tratamento do repasse de financiamento (Finame e crédito rural) na etapa 1.
- **Aviso estrutural para o site (já corrigido no motor 1.1, ver seção 10).** O motor contava como "custo do split" o saldo credor que já existiria sem o split. Isso acontece nos nichos de alíquota zero (C04) e em alguns outros. Em C04-03, por exemplo, 7,4 dos 13,2 pontos do cenário prudente vêm daí. O site precisa separar essa parte (ver seção 6).

## 2. Checagens feitas e resultado

### 2.1 Validador

| Checagem | Antes | Depois |
| --- | --- | --- |
| `validate.js` por lote, com a lista de ids esperada | 9 × TUDO OK | 9 × TUDO OK |
| Avisos "regime regular com parcela < 100" | 4 | 4, todos justificados |
| `merge.js` | 123 nichos | 123 nichos, nenhum faltando |

Os 4 avisos estão certos. São receitas descontadas na fonte, sem pagamento do cliente, e por isso ficam fora do split:

- `comissao_midia` (C02-08);
- `cobranca_retida` (C02-10);
- `adm_pj` (C07-08);
- `cedentes_regular` (C14-01).

### 2.2 Mesmo tratamento legal, mesmo valor

| Tratamento | Valor esperado | Resultado da varredura (377 itens de venda e 582 linhas de receita) |
| --- | --- | --- |
| Cesta (Anexo I) e Anexo XV | 0 | OK em todos os nichos. |
| Anexo VII | 40 | OK. |
| Anexo VIII | 40 | OK no valor. O escopo foi corrigido nos textos (ver 4.2). |
| Bares e restaurantes | 60 | OK. Linhas com 68,8, 70, 76 e 86 são médias ponderadas com bebida alcoólica e revenda, com fórmula na observação (C06-02, C06-04, C06-05, C06-06, C06-08). |
| Hotelaria e parques | 60 | OK. O 62 de C06-07 é média com frigobar e bar, explicada. |
| Construção, incorporação e intermediação | 50 | OK. Incorporação e loteamento usam 20 a 42 depois do redutor de ajuste e do redutor social, com status "estimativa" (C07-04, C07-05). |
| Locação de imóveis | 30 | OK. O 23 residencial (C07-06) desconta o redutor social, com fórmula no campo. Aluguel pago a PJ, como compra: 30 em todas as 54 linhas dedicadas. |
| Saúde (Anexo III) e educação (Anexo II) | 40 | OK. A CBS zero do Prouni (C09-04) usa tabela por ano, explicada. |
| Profissões do art. 127 | 70 | OK. |
| Insumos do Anexo IX | 40, ou 0 com diferimento | OK. O diferimento aparece como 0 com observação. |
| Serviços financeiros | Mesma tabela por ano | OK. C14-01 usa 10,85 a 12,5 (ou 8,85 a 12,5 com ISS) × base. C14-02 e C14-03 usam 8,85 a 12,5 para corretagem, pela leitura conjunta dos arts. 228 e 233, §10 (artigo de 14/08/2026, conferido), marcada como interpretação. A tabela do art. 233 foi conferida no Juruá. |
| Fornecedor do Simples | 7 | OK em 79 linhas. Linhas mistas com 50, 55, 70, 80 ou 85 agora têm nota da estimativa (10 notas acrescentadas). |
| Combustíveis com condicionado = false | false | OK em todas as linhas de combustível. Corrigido o valor do crédito (ver 4.6). Linhas mistas de energia e gás ficam condicionadas, agora com nota (11). |

### 2.3 Regras de `parcela_sujeita_split`

Nenhuma linha com cartão, vale ou dinheiro, nem com cliente consumidor final, público, exportação, Simples ou produtor não contribuinte, tem parcela acima de 0. Os casos especiais são coerentes:

- linhas de regime regular com alíquota 0 e parcela 100 (suspensão, revenda de energia, livros a editoras): o split não retém nada, sem efeito no motor;
- linha "misto" de C01-01 com 45%;
- C11-05: hipótese de que o repasse do banco por TED entra na etapa 1, com campo para mudar.

### 2.4 Linhas de compra proibidas

Não há folha, pró-labore, tributos, juros nem tarifas bancárias. Casos de fronteira mantidos, todos justificados:

- vale-transporte e vale-refeição com 1% da cheia (crédito só sobre a taxa da operadora), em C02-03, C02-04, C02-09, C02-10 e C02-11;
- comissões de plataformas (C03-03, C06-07, C12-04): são serviço e dão crédito;
- royalties de franquia (C06-05, C09-05): idem.

### 2.5 Campos do formulário com alvo direto

O script comparou o `padrao` de cada campo com a linha que ele altera. Em 1.403 campos (1.405 depois da revisão), não sobrou nenhuma divergência real. As 25 diferenças apontadas são campos com fórmula: investimento anual ÷ 12 ÷ receita, CMV × fatia, 15 + dia, média ponderada de alíquota. Recalculei todas e elas reproduzem as linhas. Os campos novos ou trocados na revisão seguem o mesmo padrão. Todos os nichos têm de 5 a 14 campos.

### 2.6 Exposição, prioridade, linhas e resultado

Recalculei o motor por nicho (débito, crédito, efeito dominante, semáforo). Distribuição final:

- exposição: 44 alta, 41 média e 38 baixa;
- prioridade: 37 em 1, 49 em 2 e 37 em 3;
- semáforo de 2028: 103 verde, 19 amarelo e 1 vermelho.

Outliers conferidos, todos coerentes:

- **C11-05, máquinas agrícolas (2% a 37%).** A venda com alíquota zero a não contribuinte deixa o crédito sem débito para abater. Ainda assim, a alíquota zero mantém o crédito.
- **C01-11, C02-07, C07-01, C07-03 e C15-03.** O prudente fica mais de 3 vezes acima do favorável pelo mesmo mecanismo: o split leva o débito e o crédito sobra na apuração. A distância depende da regra de compensação, ainda não publicada.
- **C01-05, distribuidor de TI (semáforo vermelho).** O padrão tem caixa livre menor que a necessidade e custo de 16% da geração de caixa. É coerente com margem de 10% a 14% e metade da carteira antecipada.
- **C14-01, factoring (0,7%, prioridade 1).** O caixa próprio quase não muda. A prioridade é justificada pelo papel de parceiro.
- **C04-11, pescados (prioridade 3, 0,8% a 11,3%).** O próprio texto explica a faixa larga.
- **C02-14, representação comercial (prioridade 3 com 13% a 14%).** Em reais o efeito é pequeno, e a prioridade está justificada pelo valor absoluto.
- **C02-11.** A prioridade foi elevada sem explicação. Acrescentei a frase.
- **Exposição baixa com efeito de 5% a 7% (C03-06, C03-07, C03-09, C03-14).** O efeito é todo de crédito condicionado, sem split nas vendas. É coerente com a definição de exposição ao split usada na base.

## 3. Pesquisa feita na revisão (8 buscas e cerca de 30 páginas abertas)

| Ponto | Fonte aberta | Conclusão |
| --- | --- | --- |
| Alíquota zero e crédito | Juruá Docs, LC 214, arts. 47 e 51; Jurishand, arts. 49 e 125 | O §10 do art. 47 fala em "alíquota reduzida" e não cita a zero. O art. 51 anula crédito só na imunidade e na isenção. O art. 125 usa "ficam reduzidas a zero". A leitura do L4 é a que se sustenta no texto. O art. 49 veda o crédito do comprador na entrada com alíquota zero. |
| Anexo VIII | Senado, publicação 40180973; Jurishand, art. 136 | 7 itens: sabonete em barra 3401.11.90, creme dental 3306.10.00, escova 9603.21.00, papel higiênico 4818.10.00, água sanitária 3808.94.19, sabão em barra 3401.19.00 e fraldas e absorventes 9619.00.00. O art. 136 remete ao anexo. |
| Saúde menstrual e Anexo XV | Jurishand, arts. 147 e 148 | O art. 147 dá alíquota zero a tampões, absorventes, calcinhas absorventes e coletores do 9619.00.00 que atendam a norma da Anvisa. O art. 148 dá alíquota zero ao Anexo XV. |
| Art. 127 | Jurishand, art. 127; Simtax; Tactus; buscadorncm (cClassTrib 200052) | O rol inclui administradores (I), economistas (VIII) e educação física (X). O §3º afasta os §§1º e 2º para a PJ de educação física fiscalizada por conselho. |
| Art. 10 | Juruá Docs, art. 10; Migalhas (18/05/2026) | O §3º vale para toda execução continuada ou fracionada: o imposto nasce na exigibilidade da parcela ou no pagamento, o que vier primeiro (redação da LC 227/2026). O §4º trata da antecipação no pagamento antecipado. O §7º traz a regra dos 5 dias. |
| Art. 254 | Juruá Docs, art. 254 | Locação, administração e intermediação de imóveis: imposto em cada pagamento (§2º). Construção civil: no fornecimento. |
| Arts. 168 e 169 | Juruá Docs, art. 168; Jurishand, art. 169; TaxUp (30/10/2026); lista de atos conjuntos do CGIBS | Percentual anual por ato conjunto até setembro. O do art. 168 pode ser ressarcido (§8º); o do art. 169, só deduzido (§7º). Nenhum ato com percentuais na lista do CGIBS em 04/11/2026. |
| Diesel | Portaria MF 3.074/2026 (PDF no Portal da Reforma) | CBS de 2027: diesel R$ 0,3515/L, biodiesel R$ 0,1480/L, gasolina R$ 0,7925/L, etanol R$ 0,1922/L, GLP R$ 0,1677. Efeitos 91 dias após 09/10/2026. |
| Imposto Seletivo | Portal da Reforma (03/11/2026); Confeb (14/10/2026); Gazeta do Povo (28/10/2026) | A Fazenda disse que a MP sairia em 04/11/2026. Pela noventena, a cobrança começa em fevereiro de 2027, se a MP virar lei até 31/12/2026 (CF, art. 62, §2º); senão, em 2028. |
| Corretagem de seguros | Portal da Reforma (14/08/2026); Juruá Docs, art. 233 | Tabela de 8,85% a 12,5% é leitura de um autor, sem posição oficial. Mantida como interpretação. |

## 4. Contradições resolvidas

### 4.1 Alíquota zero e crédito

O texto do L4 está correto e ficou único em 13 nichos, com a mesma citação: "Alíquota zero não é isenção: a redução de alíquota, inclusive a zero, não estorna os créditos das compras (LC 214, art. 47, §10); a anulação do art. 51 vale só para imunidade e isenção."

- **Corrigidos:** C01-01, C01-11, C01-18, C03-01, C03-14, C05-01, C08-01, C08-05, C09-04, C11-03 e C11-05.
- **Já estavam certos:** C04-01 a C04-11.
- **C09-04 citava o art. 52.** Passou para os arts. 47, §10, e 51, com premissa F e fonte.
- **Pendências removidas:** 4 pendências do tipo "confirmar que alíquota zero mantém crédito" (C01-01, C03-01, C08-01, C09-04).
- **Distinção mantida, porque está certa:** quem compra com alíquota zero não toma crédito (art. 49). Isso aparece em C01-13, C05-02 e C15-01.

### 4.2 Escopo do Anexo VIII

São 7 NCMs, confirmados no Senado. O art. 136 é o artigo de remissão.

- **C05-01:** a base legal deixou de ser "artigo a confirmar" e passou a citar o art. 136. A linha de saúde menstrual passou a citar o art. 147, com status "lei".
- **C05-03:** base legal com o art. 136.
- **C03-01:** a lista "e similares" foi trocada pelos 7 itens, no item de venda e na ajuda do campo.
- **C08-05:** lista completa na observação e na ajuda.
- **C02-03:** a linha de compra trocou "sabão" por "sabão em barra".
- **C01-18:** lista completa na observação.
- **C01-09:** já estava certo.

### 4.3 Art. 127

O rol inclui administradores e economistas. O mapeamento preliminar de C02-12 ("fora do rol") estava errado.

- **C02-12:** já tinha corrigido isso, com campo de requisitos e redução de 30% opcional. Ganhou a fonte primária.
- **Família C10:** coerente.
- **C02-15:** a pendência "art. 127 bloqueado nos espelhos" foi trocada por "rol conferido", com fonte.
- **Única afirmação "fora do rol" errada que sobrava: C03-11 (academia).** A base dizia que academia não cumpre os requisitos societários. O §3º afasta justamente esses requisitos para a PJ de educação física fiscalizada pelo CREF. Mudanças em C03-11:
  - quatro linhas de receita passaram de 100 para 70;
  - novo campo `registro_cref`;
  - textos, premissa e tese ajustados;
  - status "interpretação", porque a tabela preliminar NBS × cClassTrib classifica "centros de ginástica" (1.2602.30.00) como tributação integral.
- **Já estavam certos:** C02-14 (representante) e C08-07 (psicólogo e fisioterapeuta) estão de fato fora do rol.

### 4.4 Crédito presumido

**Produtor rural ou integrado não contribuinte (art. 168).** Tabela única: 1,1 / 1,1 / 1,3 / 1,5 / 1,7 / 1,9 / 3,0% (2027 a 2033).

- Escolhi a tabela do L4 porque o racional acompanha a alíquota do ano: cerca de 10% do valor em insumos tributados não diferidos, vezes a alíquota cheia.
- O L8 usava 1,0% a 1,8%. A curva era achatada demais para 2033, quando o IBS cheio entra.
- Também unifiquei `condicionado = true`, porque o crédito é apropriado no pagamento ao produtor (Decreto 12.955, art. 245). O L8 usava false.
- Mesma nota em 12 linhas: C04-01, C04-02, C04-03, C04-04, C04-06, C04-07, C04-10, C04-11, C05-02, C11-01, C11-02 e C11-03.

**Transportador autônomo (art. 169).** Tabela única do L9: 2,9 / 2,9 / 3,6 / 4,2 / 4,9 / 5,5 / 9,2%.

- O L8 usava 4% a 8% sem racional.
- Mesma nota em 7 linhas: C11-01, C11-02, C11-03, C11-04, C12-01, C12-02 e C12-05.
- A nota avisa que esse crédito não pode ser ressarcido, o que o motor não distingue.

As premissas de C11-01 e C11-02 foram alinhadas. Pendência única do ato conjunto em 4 nichos que não a tinham.

### 4.5 Imposto Seletivo

Status único em 9 nichos: C01-01, C03-01, C03-04, C03-14, C06-04, C15-01, C15-02, C15-03 e C15-04.

- **O que diz:** MP anunciada para 04/11/2026 e não publicada até 03/11. Cobrança a partir de fevereiro de 2027 se a MP virar lei até 31/12/2026; senão, em 2028. Carga próxima à do IPI em 2027.
- **Por que mudou:** o L3 dizia "MP anunciada em outubro". O L1 dizia "não publicada em 27/10". O L8 omitia a condição de conversão em lei.
- **Fontes acrescentadas:** Portal da Reforma (03/11) e Confeb (14/10).

### 4.6 CBS ad rem do diesel

A Portaria MF 3.074/2026 foi conferida: R$ 0,3515/L de diesel e R$ 0,1480/L de biodiesel. Isso dá cerca de 4,6% do preço do S10. Era o valor do L9.

- **Onde estava errado:**
  - L1, L2, L3 e L4 usavam 100% da cheia (11,35% do valor, cerca de 2,5 vezes o real);
  - L8 usava 6% em 2027-2028 e 25% em 2033.
- **Correção:** 14 linhas de diesel (que somam 21 com as 7 do L9) passaram a `credito_fixo_pct_valor_por_ano` = 4,6 / 4,6 / 6,0 / 7,4 / 8,8 / 10,2 / 18,6, com a mesma nota do L9. São elas: C01-01, C01-02, C01-03, C02-06, C03-02, C04-10, C11-01 a C11-05, C15-01, C15-03 e C15-04.
- **Linhas de "combustível" sem tipo definido** (8 linhas, ficaram em 100%): ganharam nota explicando que 100% equivale à gasolina (cerca de 12% do preço) e que a diesel seria 4,6%.
- **GLP de cozinha** (4 linhas): nota de que o crédito real é perto de 2% do preço.
- **Notas de linha:** a chave `nota` do L9 virou `observacao`, para haver uma chave só na base.

### 4.7 Momento do fato gerador

**Execução continuada (art. 10, §3º).** O L9 tratava contratos mensais com o prazo contado do vencimento. L2, L5 e L6 contavam da nota.

- **Corrigido em 24 nichos:** C02-01 a C02-12, C02-14, C03-11 (repasse dos agregadores), C06-01, C07-01, C07-02, C07-03, C07-07, C09-01 (convênio), C10-01 a C10-04.
- **Linhas corrigidas:** prazo_dias passou a ser o atraso depois do vencimento (3 dias; 0 no Pix Automático).
- **Formulário:** 23 campos de prazo trocados por "Dias que o cliente costuma atrasar depois do vencimento", com ajuda que explica a regra. Os itens de entrega única ganharam campo próprio com o prazo da nota: peças em C02-05 (campo trocado) e produção em C02-08 (campo novo).
- **Textos:** regra, premissa H e fonte acrescentadas. Análises com números atualizados.
- **Mantidos com o prazo da nota:** projetos por entrega, venda de mercadorias e ensaios avulsos, porque não são execução continuada.

**Imóveis (art. 254, §2º).** C07-08 passou a ter prazo 0 nas comissões, porque o imposto nasce em cada pagamento. O campo de prazo virou só mensagem.

**Pagamento antecipado (art. 10, §4º).** Todas as 12 linhas de adiantamento usam prazo 1 e parcela 100.

- A regra foi acrescentada onde faltava (C02-15 e C13-02).
- C06-06 citava o §4º para a regra dos 5 dias, que é o §7º. Corrigido.

**Caução (C07-01 e C07-02).** Ficou como pendência: pelo §3º, a parte retida pode ter o imposto só na devolução.

### 4.8 Outras correções

- **Termos em inglês nos textos e rótulos:** "fee", "retainer", "in-company", "leads", "offshore", "sellers", "hub", "funding", "chargeback", "checklist" e "markup" foram trocados por termos em português. Ficaram "float" em análises antigas, que não estão em rótulos, e termos de mercado sem tradução usual ("trading", "barter", "royalties", "delivery", "marketplace", "e-commerce").
- **Rótulos com jargão de lei:** 9 rótulos tinham "Anexo VII", "Anexo IX" ou "art. 127/271". Foram reescritos para o dono do negócio.
- **Regra de Simples puro em `regras_especiais_calculo`:** acrescentada em 11 nichos que não a tinham. Nos nichos de atividade vedada no Simples (C07-04 a C07-06), a regra avisa que não se aplica.
- **C01-01:** o texto de prazos de ressarcimento falava em "pedido comum" e "análise longa" e ficou igual ao do contexto global.
- **C02-11:** acrescentada a justificativa da prioridade.
- **C03-01:** confirmados os arts. 147 e 148 e removidas as pendências correspondentes.

## 5. Pendências abertas, por prioridade

### Prioridade 1 (mudam o número que o cliente vê)

1. **Regra de compensação do crédito em tempo real ou só na apuração.** Ela separa favorável e prudente. Em 31 nichos o prudente é mais de 2 vezes o favorável (C11-05: 2% contra 37%). Sem norma publicada.
2. **Percentuais oficiais do crédito presumido de 2027 (arts. 168 e 169).** Não há ato conjunto na lista do CGIBS em 04/11/2026. Afetam 19 linhas em 16 nichos (C04, C05-02, C11 e C12).
3. **Saldo credor que já existiria sem split.** Resolvido no motor 1.1 (seção 10). O site só precisa mostrar `saldo_credor_sem_split` à parte.
4. **Repasse de financiamento na etapa 1:** Finame (C01-11), crédito rural e banco da montadora (C11-05), banco do consumidor (C03-04 e C13-02). Hoje cada nicho assume uma coisa, sempre com campo para mudar.

### Prioridade 2 (enquadramento de um nicho)

5. **NBS de academias (C03-11):** o §3º do art. 127 dá 30%, mas a tabela preliminar NBS 1.2602.30.00 aponta tributação integral. Confirmar na tabela cClassTrib definitiva.
6. **MP do Imposto Seletivo:** ler quando publicada e atualizar `pct_is` em C15-01 e C15-02. Saber se virou lei até 31/12/2026.
7. **Caução em C07-01 e C07-02:** se o imposto da parte retida nasce na medição ou só na devolução.
8. **IBS ad rem de combustíveis de 2029 em diante:** ainda não publicado. A base usa a equivalência com a alíquota de referência.
9. **Corretagem de seguros (C14-02 e C14-03):** confirmar se vale o redutor do art. 233, §10 (leitura de um autor).
10. **Agregadores de academia (C03-11) e plataformas:** quem é o adquirente no contrato.

### Prioridade 3 (já sinalizadas nos registros)

11. Pendências específicas já listadas em `pendencias_verificar` de cada nicho. Exemplos: regulamento sobre condomínio; Prouni e FIES depois da LC 227; sucumbência; e-books; Anexo XI em segurança; cooperativas e prorrogação da opção do art. 271.

## 6. Recomendações para quem for escrever o prompt do site

### 6.1 O que o motor precisa suportar ou corrigir

- **Separar o saldo credor estrutural (aplicado no motor 1.1, ver seção 10).** Antes `trapPrud` e `trapFav` medem o crédito que passa do débito em aberto, mas a linha de base (sem split) também tem saldo credor quando o crédito passa do débito total. O motor soma essa parte ao "efeito do split".
  - Em C04-03, 7,4 dos 13,2 pontos do prudente existem mesmo sem split.
  - Também acontece em C04-01 a C04-11, C09-04, C11-02, C13-04, C08-01, C07-01 e C07-04.
  - Recomendação: mostrar duas parcelas, "saldo credor que já existe por causa da alíquota zero" e "efeito do split", ou subtrair max(0, crédito − débito) × prazo extra / 30 da linha de base.
- **Crédito que não pode ser ressarcido.** O crédito presumido do art. 169 só abate débitos (§7º). O motor o trata como os demais e pode mandá-lo para ressarcimento. Falta um atributo de linha, por exemplo `ressarcivel: false`.
- **Fórmulas dos campos.** Cerca de 25 campos têm derivação não trivial: soma de fatias com "resto", investimento anual ÷ 12 ÷ receita, médias ponderadas de alíquota, tabelas por ano escolhidas por seleção (C02-07, C09-04, C14-01, C14-02, C14-03). O site precisa de um interpretador de `derivacao` ou de funções escritas à mão por nicho. Não basta "campo = linha".
- **Campos de seleção com valor texto** (`regime_empresa`, `tabela_aliquota`, `tributacao_seminovos`) e booleanos (`simular_b2c`, `gas_condicionado`). Eles acionam regras especiais, não só atributos.
- **Simples puro.** O motor não tem modo Simples. Cada nicho diz em `regras_especiais_calculo` o que fazer: não rodar o motor e mostrar a comparação de regime. Implementar como fluxo separado.
- **Normalização.** Quando as fatias informadas não somarem 100, normalizar e avisar, como quase todos os nichos pedem.
- **Sazonalidade e investimento pontual.** O motor usa média mensal e regime permanente. Safra, alta temporada, compra de frota e início de loteamento precisam de aviso, ou de um modo "mês de pico".
- **Adiantamento meses antes da entrega** (art. 10, §4º; C06-06, C01-11, C02-13). O motor trata como recebimento à vista. Mostrar o alerta já previsto nos registros.

### 6.2 Avisos que o site deve mostrar

- O aviso geral do `contexto_global`: diagnóstico financeiro, não parecer jurídico. As datas do split são previsão da Receita, sem ato normativo.
- Os dois cenários. O favorável supõe abatimento do crédito em 48 horas e o prudente, só na apuração. A regra ainda não foi publicada. Mostrar sempre os dois, nunca só o favorável.
- Estimativas marcadas:
  - crédito presumido (arts. 168 e 169);
  - diesel e IBS ad rem de 2029 em diante;
  - alíquotas de IBS (projeção do CGIBS);
  - CBS de 2027 (TCU 11,35%, sem resolução do Senado até 15/12/2026).
- Nos contratos mensais: o imposto nasce no vencimento, e o prazo do boleto não protege o caixa.
- Imposto Seletivo: depende de MP ainda não publicada e de conversão em lei até 31/12/2026. Não está no cálculo do caixa.
- Nos nichos de alíquota zero: parte do capital preso existe com ou sem split.

### 6.3 O que não prometer

- Não prometer o número exato nem a data do split. Cartão, vale e consumidor final não têm data.
- Não prometer enquadramento. Redução do art. 127, academia, Anexos VII e VIII por NCM, montagem industrial e Anexo XI dependem de conferir contrato, NCM ou NBS e quadro societário.
- Não prometer prazo de ressarcimento: 30, 60 ou 180 dias dependem do programa de conformidade e do enquadramento no art. 40.
- Não apresentar o cenário prudente como "pior caso". Pico de safra e compra grande de ativo podem passar dele.

## 7. Arquivos

- Lotes corrigidos: `out_L1.json` a `out_L9.json`. A formatação original de cada um foi mantida (indentação de 2 ou 1 espaço).
- Base consolidada: `base_consolidada.json`, gerada pelo `merge.js` depois das correções.
- Cópias originais, scripts e registro completo das mudanças em JSON: pasta `rev/` ao lado da pasta `base/` (`rev/orig/`, `rev/stage1.py` a `rev/stage5.py`, `rev/log_final.json`).

## 8. Efeito das correções no resultado de exemplo (2028, % de um mês de receita)

Mudaram 33 nichos. O resto ficou igual.

| Nicho | 2028 favorável antes → depois | 2028 prudente antes → depois | Efeito dominante (prudente) | Semáforo 2028 |
| --- | --- | --- | --- | --- |
| C01-01 | 5.1% → 5.1% | 14.7% → 14.4% | saldo credor | amarelo |
| C01-02 | 8.2% → 8.2% | 21.4% → 21.3% | crédito condicionado | amarelo |
| C01-03 | 8.3% → 8.3% | 24.4% → 24.2% | saldo credor | amarelo |
| C02-01 | 8.3% → 9.3% | 10.5% → 11.6% | débito antecipado | verde |
| C02-02 | 4.1% → 10.9% | 5.6% → 12.6% | débito antecipado | verde |
| C02-03 | 3.9% → 8.9% | 4.6% → 9.6% | débito antecipado | verde |
| C02-04 | 3.5% → 8.1% | 3.9% → 8.5% | débito antecipado | verde |
| C02-05 | 5.3% → 12.4% | 6.9% → 21.8% | crédito condicionado → débito antecipado | verde |
| C02-06 | 4.2% → 9.3% | 15.1% → 20.0% | crédito condicionado → débito antecipado | verde |
| C02-07 | 4.4% → 8.5% | 22.2% → 26.3% | saldo credor | verde |
| C02-08 | 3.5% → 8.1% | 5.4% → 9.9% | débito antecipado | verde |
| C02-09 | 4.7% → 9.3% | 6.7% → 11.3% | débito antecipado | verde |
| C02-10 | 4.9% → 11.5% | 5.9% → 13.3% | débito antecipado | verde |
| C02-11 | 10.2% → 13.4% | 10.6% → 13.9% | débito antecipado | verde → amarelo |
| C02-12 | 6.9% → 7.5% | 8.0% → 8.5% | débito antecipado | verde |
| C02-14 | 9.1% → 13.0% | 10.1% → 14.0% | débito antecipado | verde |
| C03-11 | 2.5% → 4.0% | 3.1% → 4.8% | crédito condicionado | verde |
| C04-10 | 2.1% → 1.6% | 4.6% → 4.1% | saldo credor | verde |
| C06-01 | 4.2% → 10.0% | 5.7% → 12.4% | débito antecipado | verde |
| C07-01 | 4.5% → 6.8% | 19.3% → 21.6% | saldo credor | verde |
| C07-02 | 3.3% → 6.2% | 5.4% → 8.2% | débito antecipado | verde |
| C07-03 | 2.6% → 6.2% | 14.6% → 19.5% | saldo credor | verde |
| C07-07 | 6.9% → 13.1% | 12.5% → 18.7% | débito antecipado | verde |
| C07-08 | 1.8% → 3.1% | 2.3% → 3.6% | crédito condicionado → débito antecipado | verde |
| C10-01 | 3.7% → 4.2% | 4.3% → 4.9% | débito antecipado | verde |
| C10-02 | 3.9% → 6.3% | 4.7% → 7.0% | débito antecipado | verde |
| C10-03 | 2.0% → 5.9% | 2.7% → 7.0% | débito antecipado | verde |
| C10-04 | 2.4% → 3.9% | 3.1% → 4.6% | débito antecipado | verde |
| C11-02 | 1.7% → 1.3% | 9.4% → 9.6% | saldo credor | amarelo |
| C11-03 | 1.3% → 1.2% | 4.9% → 5.1% | saldo credor | verde |
| C11-04 | 3.4% → 3.4% | 9.1% → 8.8% | saldo credor | verde |
| C11-05 | 2.1% → 2.1% | 36.9% → 36.8% | saldo credor | amarelo |
| C15-03 | 5.6% → 5.6% | 18.4% → 18.3% | saldo credor | amarelo |

## 9. Tabela das mudanças (nicho, campo, antes, depois, motivo)

Total: 491 mudanças registradas (427 edições de conteúdo e 64 fontes adicionadas), em 94 nichos. Cada linha é um campo alterado; textos longos estão abreviados com "…".

| Grupo | Mudanças |
| --- | --- |
| A. Alíquota zero e manutenção de crédito | 20 |
| B. Anexo VIII e saúde menstrual | 20 |
| C. Art. 127 e academia | 19 |
| D. Crédito presumido (arts. 168 e 169) | 38 |
| E. Diesel, combustíveis e gás | 80 |
| F. Imposto Seletivo | 15 |
| G. Fato gerador (art. 10, §§3º, 4º e 7º; art. 254) | 172 |
| H. Simples Nacional nas regras da calculadora | 11 |
| I. Português e rótulos | 37 |
| J. Outras | 15 |
| K. Fontes adicionadas | 64 |

#### A. Alíquota zero e manutenção de crédito (20)

| Nicho | Campo | Antes | Depois | Motivo |
| --- | --- | --- | --- | --- |
| C01-01 | tratamento_tributario.regras_relevantes[0] | Venda com alíquota reduzida não estorna o crédito das compras (art. 47, §10); a alíquota zero … | Alíquota zero não é isenção: a redução de alíquota, inclusive a zero, não estorna os créditos … | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C01-01 | riscos_pontos_abertos[0] | Manutenção do crédito na venda com alíquota zero da cesta: leitura corrente é que se mantém, m… | Manutenção do crédito na venda da cesta com alíquota zero está no texto da lei (arts. 47, §10,… | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C01-01 | pendencias_verificar[0] | Confirmar no texto da LC 214 e do regulamento que a alíquota zero do art. 125 mantém os crédit… | (removido) | Resolvida na revisão: arts. 47, §10, e 51 conferidos |
| C01-11 | tratamento_tributario.vendas[1].observacao | Alíquota zero; o fabricante mantém o crédito das compras | Alíquota zero; o fabricante mantém o crédito das compras (art. 47, §10; o art. 51 só anula na … | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C01-11 | tratamento_tributario.regras_relevantes[+] | (vazio) | Alíquota zero não é isenção: a redução de alíquota, inclusive a zero, não estorna os créditos … | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C01-18 | tratamento_tributario.regras_relevantes[0] | Venda com alíquota reduzida não estorna o crédito dos insumos (art. 47, §10). | Alíquota zero não é isenção: a redução de alíquota, inclusive a zero, não estorna os créditos … | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C03-01 | tratamento_tributario.regras_relevantes[1] | Alíquota zero não é isenção: o art. 51 manda anular créditos só em imunidade e isenção. Por es… | Alíquota zero não é isenção: a redução de alíquota, inclusive a zero, não estorna os créditos … | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C03-01 | riscos_pontos_abertos[1] | Se a alíquota zero vier a ser tratada como isenção para fins de anulação de crédito, o crédito… | A manutenção do crédito com alíquota zero está no texto da lei (arts. 47, §10, e 51); acompanh… | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C03-01 | pendencias_verificar[1] | Confirmar se a alíquota zero mantém o crédito das despesas comuns (art. 51 trata só de imunida… | (removido) | Resolvida na revisão: arts. 47, §10, e 51 conferidos |
| C03-14 | tratamento_tributario.regras_relevantes[+] | (vazio) | Alíquota zero não é isenção: a redução de alíquota, inclusive a zero, não estorna os créditos … | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C05-01 | tratamento_tributario.regras_relevantes[1] | Venda com alíquota reduzida não estorna créditos (art. 47, §10). | Alíquota zero não é isenção: a redução de alíquota, inclusive a zero, não estorna os créditos … | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C08-01 | tratamento_tributario.regras_relevantes[1] | Vender com redução não obriga estornar o crédito das compras (art. 47, §10). O estorno proporc… | Alíquota zero não é isenção: a redução de alíquota, inclusive a zero, não estorna os créditos … | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C08-01 | pendencias_verificar[2] | Confirmar que a alíquota zero não exige estorno de crédito (art. 51 só cita imunidade e isençã… | (removido) | Resolvida na revisão: arts. 47, §10, e 51 conferidos |
| C08-05 | tratamento_tributario.regras_relevantes[3] | Vender com redução ou zero não obriga estornar créditos (art. 47, §10; art. 51 só exige estorn… | Alíquota zero não é isenção: a redução de alíquota, inclusive a zero, não estorna os créditos … | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C09-04 | tratamento_tributario.regras_relevantes[2] | Alíquota zero mantém o crédito das etapas anteriores (leitura de fontes; uso do saldo depende … | Alíquota zero não é isenção: a redução de alíquota, inclusive a zero, não estorna os créditos … | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C09-04 | premissas_operacionais[3] | Manutenção do crédito com alíquota zero: Créditos das compras mantidos | Manutenção do crédito com alíquota zero: Créditos das compras mantidos | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C09-04 | pendencias_verificar[1] | Confirmar a regra de manutenção de crédito para receita com alíquota zero (art. 52 citado por … | (removido) | Resolvida na revisão: arts. 47, §10, e 51 conferidos |
| C11-03 | premissas_operacionais[4] | Manutenção dos créditos da cooperativa com alíquota zero: Mantidos | Manutenção dos créditos da cooperativa com alíquota zero: Mantidos, salvo a regra própria do a… | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C11-05 | tratamento_tributario.regras_relevantes[1] | A alíquota zero não exige estorno de crédito (art. 51 trata de imunidade e isenção). A venda c… | Alíquota zero não é isenção: a redução de alíquota, inclusive a zero, não estorna os créditos … | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |
| C11-05 | premissas_operacionais[4] | Manutenção dos créditos na venda com alíquota zero: Sem estorno | Manutenção dos créditos na venda com alíquota zero: Sem estorno | Harmonização: texto e citação únicos para alíquota zero e manutenção de crédito (L4; arts. 47, §10, e 51 conf… |

#### B. Anexo VIII e saúde menstrual (20)

| Nicho | Campo | Antes | Depois | Motivo |
| --- | --- | --- | --- | --- |
| C03-01 | tratamento_tributario.vendas[1].observacao | Alíquota zero confirmada no contexto global; número do artigo a conferir no texto oficial. | Art. 148 conferido na revisão: "ficam reduzidas a zero" as alíquotas dos itens do Anexo XV. | Art. 148 conferido na revisão |
| C03-01 | tratamento_tributario.vendas[1].confianca | media | alta | Art. 148 conferido na revisão |
| C05-01 | tratamento_tributario.vendas[0].base_legal | LC 214, Anexo VIII (artigo de remissão a confirmar) | LC 214, art. 136 e Anexo VIII | Escopo do Anexo VIII conferido na revisão: 7 NCMs, art. 136 |
| C05-01 | tratamento_tributario.vendas[1].base_legal | LC 214, regra da saúde menstrual (contexto_global: alíquota zero) | LC 214, art. 147 | Art. 147 conferido na revisão (saúde menstrual, NCM 9619.00.00, requisitos da Anvisa) |
| C05-01 | tratamento_tributario.vendas[1].status | interpretacao | lei | Art. 147 conferido na revisão |
| C05-01 | tratamento_tributario.vendas[1].observacao | Mesmo NCM 9619.00.00 das fraldas; confirmar requisitos e o artigo exato da alíquota zero. | Mesmo NCM 9619.00.00 das fraldas; a alíquota zero vale para tampões, absorventes, calcinhas ab… | Art. 147 conferido na revisão |
| C05-01 | pendencias_verificar[0] | Número do artigo da LC 214 que remete ao Anexo VIII | (removido) | Resolvida: art. 136 |
| C05-03 | tratamento_tributario.vendas[0].base_legal | LC 214, Anexo VIII | LC 214, art. 136 e Anexo VIII | Escopo do Anexo VIII conferido na revisão: 7 NCMs, art. 136 |
| C03-01 | tratamento_tributario.vendas[3].item | Higiene pessoal e limpeza do Anexo VIII (sabonete, creme dental, papel higiênico, água sanitár… | Higiene pessoal e limpeza do Anexo VIII (sabonete em barra (3401.11.90), creme dental (3306.10… | Escopo do Anexo VIII conferido na revisão: 7 NCMs, art. 136; lista é fechada, "e similares" induzia erro |
| C03-01 | tratamento_tributario.vendas[3].base_legal | LC 214, art. 128, VII, e Anexo VIII | LC 214, arts. 128, VII, e 136, e Anexo VIII | Escopo do Anexo VIII conferido na revisão: 7 NCMs, art. 136 |
| C03-01 | tratamento_tributario.vendas[3].confianca | media | alta | Escopo do Anexo VIII conferido na revisão: 7 NCMs, art. 136 |
| C03-01 | campos_especificos[3].ajuda | Só os itens do Anexo VIII (sabonete, creme dental, papel higiênico, água sanitária, sabão em b… | Só os 7 itens do Anexo VIII: sabonete em barra, creme dental, escova de dentes, papel higiênic… | Escopo do Anexo VIII conferido na revisão: 7 NCMs, art. 136 |
| C08-05 | tratamento_tributario.vendas[2].base_legal | LC 214, art. 128, VII; Anexo VIII | LC 214, arts. 128, VII, e 136, e Anexo VIII | Escopo do Anexo VIII conferido na revisão: 7 NCMs, art. 136 |
| C08-05 | tratamento_tributario.vendas[2].observacao | Só os itens e NCMs do anexo. | Só os 7 itens do anexo: sabonete em barra (3401.11.90), creme dental (3306.10.00), escova de d… | Escopo do Anexo VIII conferido na revisão: 7 NCMs, art. 136 |
| C08-05 | campos_especificos[5].ajuda | Redução de 60%. | Redução de 60% só para sabonete em barra, creme dental, escova de dentes, papel higiênico, águ… | Escopo do Anexo VIII conferido na revisão: 7 NCMs, art. 136 |
| C08-05 | pendencias_verificar[1] | Conferir os NCMs de higiene no Anexo VIII | (removido) | Resolvida: 7 NCMs conferidos no Senado |
| C08-05 | riscos_pontos_abertos[1] | Itens de higiene que estão ou não no Anexo VIII | Cadastro por NCM: só 7 itens de higiene têm a redução do Anexo VIII | Escopo do Anexo VIII conferido na revisão: 7 NCMs, art. 136 |
| C02-03 | linhas_compra.higiene_reduzida.nome | Papel higiênico, sabão e água sanitária (redução de 60%) | Papel higiênico, sabão em barra e água sanitária (Anexo VIII, redução de 60%) | Escopo do Anexo VIII conferido na revisão: 7 NCMs, art. 136; sabão líquido não está no anexo |
| C02-03 | pendencias_verificar[1] | Confirmar se itens do Anexo VIII (higiene e limpeza com redução de 60%) incluem os produtos pr… | Conferir o NCM dos produtos profissionais comprados: o Anexo VIII vale por NCM (7 itens); sabã… | Escopo do Anexo VIII conferido na revisão: 7 NCMs, art. 136 |
| C01-18 | tratamento_tributario.vendas[1].observacao | Redução vale pelo NCM, sem condição de renda do comprador. | Redução vale pelo NCM, sem condição de renda do comprador. O Anexo VIII tem só 7 itens: sabone… | Escopo do Anexo VIII conferido na revisão: 7 NCMs, art. 136 |

#### C. Art. 127 e academia (19)

| Nicho | Campo | Antes | Depois | Motivo |
| --- | --- | --- | --- | --- |
| C02-15 | pendencias_verificar[0] | Abrir o texto oficial do art. 127 (bloqueado nos espelhos) e confirmar os requisitos e eventua… | Rol e requisitos do art. 127 conferidos na revisão (Jurishand): químicos (XV), engenheiros (XI… | Art. 127 conferido na revisão |
| C03-11 | tratamento_tributario.resumo | Academia de musculação e ginástica fica, em regra, com alíquota cheia. A redução de 60% das at… | Academia registrada no CREF tem redução de 30% nos serviços de educação física (LC 214, art. 1… | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | tratamento_tributario.vendas[0] | Musculação e ginástica: 100, art. 127 exigiria requisitos societários | Musculação e ginástica: 70, art. 127, X, e §3º (interpretação) | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | linhas_receita.recorrente.aliquota_pct_cheia | 100 | 70 | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | linhas_receita.pix_boleto_pf.aliquota_pct_cheia | 100 | 70 | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | linhas_receita.agregadores.aliquota_pct_cheia | 100 | 70 | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | linhas_receita.personal.aliquota_pct_cheia | 100 | 70 | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | tratamento_tributario.vendas[2].aliquota_pct_cheia | 100 | 70 | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | tratamento_tributario.vendas[2].observacao | O agregador paga a academia por TED; se for o adquirente do regime regular, entra no split. | O agregador paga a academia por TED; se for o adquirente do regime regular, entra no split. Me… | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | tratamento_tributario.vendas[3].item | Loja de suplementos e personal trainer | Loja de suplementos e acessórios | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | campos_especificos[+] | (vazio) | {"id": "registro_cref", "rotulo": "A academia é registrada no CREF e as aulas são dadas por pr… | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | tratamento_tributario.regras_relevantes[1] | NBS 1.2602.30.00 (bem-estar físico) inclui centros de ginástica, spas e saunas, com tributação… | Art. 127, X, e §3º: serviços de educação física têm redução de 30%, e a academia registrada no… | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | tratamento_tributario.simples_nacional.tratamento | mas a alíquota cheia sobre a mensalidade costuma pesar mais. | mas o imposto sobre a mensalidade (70% da cheia com registro no CREF) costuma pesar mais. | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | regras_especiais_calculo[0] | musculação e ginástica têm alíquota cheia, mas aulas de modalidades esportivas podem ter reduç… | musculação e ginástica têm redução de 30% se a academia for registrada no CREF, e aulas de mod… | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | analise_critica | a academia de musculação e ginástica se classifica como bem-estar físico, com tributação integ… | para musculação e ginástica vale a redução de 30% do art. 127, X: o §3º dispensa a academia re… | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | tese_consultoria | Enquadramento por modalidade (musculação cheia; ensino esportivo com possível redução de 60%) … | Enquadramento por modalidade (musculação e ginástica com 30% de redução pelo registro no CREF,… | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | premissas_operacionais[0] | Musculação e ginástica com alíquota cheia: NBS 1.2602.30.00, tributação integral | Musculação e ginástica com redução de 30%: 70% da cheia com registro no CREF | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | riscos_pontos_abertos[+] | (vazio) | Conflito entre o art. 127, §3º (30% para academia registrada no CREF) e a NBS 1.2602.30.00 da … | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |
| C03-11 | pendencias_verificar[+] | (vazio) | Confirmar na tabela cClassTrib definitiva se a academia registrada no CREF usa o código 200052… | Art. 127 conferido na revisão: rol inclui educação física (X) e o §3º afasta os requisitos societários da PJ … |

#### D. Crédito presumido (arts. 168 e 169) (38)

| Nicho | Campo | Antes | Depois | Motivo |
| --- | --- | --- | --- | --- |
| C04-01 | linhas_compra.gado_nao_contribuinte.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 168 da LC 214 na compra de produt… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C04-02 | linhas_compra.leite_nao_contribuinte.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 168 da LC 214 na compra de produt… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C04-03 | linhas_compra.grao_nao_contribuinte.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 168 da LC 214 na compra de produt… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C04-04 | linhas_compra.trigo_nao_contribuinte.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 168 da LC 214 na compra de produt… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C04-06 | linhas_compra.cafe_produtor.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 168 da LC 214 na compra de produt… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C04-07 | linhas_compra.milho_produtor.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 168 da LC 214 na compra de produt… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C04-10 | linhas_compra.produtor.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 168 da LC 214 na compra de produt… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C04-11 | linhas_compra.pescado_produtor.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 168 da LC 214 na compra de produt… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C05-02 | linhas_compra.materia_produtor.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 168 da LC 214 na compra de produt… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-01 | linhas_compra.graos_nc.credito_fixo_pct_valor_por_ano | {"2027": 1, "2028": 1, "2029": 1.1, "2030": 1.2, "2031": 1.4, "2032": 1.5, "2033": 1.8} | {"2027": 1.1, "2028": 1.1, "2029": 1.3, "2030": 1.5, "2031": 1.7, "2032": 1.9, "2033": 3} | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-01 | linhas_compra.graos_nc.condicionado | false | true | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-01 | linhas_compra.graos_nc.observacao | Crédito presumido do art. 168. Percentual de 2027 ainda não publicado; estimativa de cerca de … | Estimativa (mesma em toda a base): crédito presumido do art. 168 da LC 214 na compra de produt… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-02 | linhas_compra.graos_nc.credito_fixo_pct_valor_por_ano | {"2027": 1, "2028": 1, "2029": 1.1, "2030": 1.2, "2031": 1.4, "2032": 1.5, "2033": 1.8} | {"2027": 1.1, "2028": 1.1, "2029": 1.3, "2030": 1.5, "2031": 1.7, "2032": 1.9, "2033": 3} | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-02 | linhas_compra.graos_nc.condicionado | false | true | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-02 | linhas_compra.graos_nc.observacao | Crédito presumido do art. 168, apropriado no pagamento. Percentual estimado. | Estimativa (mesma em toda a base): crédito presumido do art. 168 da LC 214 na compra de produt… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-03 | linhas_compra.producao_assoc_nc.credito_fixo_pct_valor_por_… | {"2027": 1, "2028": 1, "2029": 1.1, "2030": 1.2, "2031": 1.4, "2032": 1.5, "2033": 1.8} | {"2027": 1.1, "2028": 1.1, "2029": 1.3, "2030": 1.5, "2031": 1.7, "2032": 1.9, "2033": 3} | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-03 | linhas_compra.producao_assoc_nc.condicionado | false | true | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-03 | linhas_compra.producao_assoc_nc.observacao | Art. 168, §9º. Percentual estimado. | Estimativa (mesma em toda a base): crédito presumido do art. 168 da LC 214 na compra de produt… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-01 | linhas_compra.frete_autonomo.credito_fixo_pct_valor_por_ano | {"2027": 4, "2028": 4, "2029": 4, "2030": 5, "2031": 6, "2032": 7, "2033": 8} | {"2027": 2.9, "2028": 2.9, "2029": 3.6, "2030": 4.2, "2031": 4.9, "2032": 5.5, "2033": 9.2} | Unificação do crédito presumido do art. 169 (L8 4%-8% x L9 2,9%-9,2%): tabela do L9, com racional documentado |
| C11-01 | linhas_compra.frete_autonomo.observacao | Crédito presumido do art. 169; percentual estimado. | Estimativa (mesma em toda a base): crédito presumido do art. 169 da LC 214 na contratação de t… | Unificação do crédito presumido do art. 169 (L8 4%-8% x L9 2,9%-9,2%): tabela do L9, com racional documentado… |
| C11-02 | linhas_compra.frete_autonomo.credito_fixo_pct_valor_por_ano | {"2027": 4, "2028": 4, "2029": 4, "2030": 5, "2031": 6, "2032": 7, "2033": 8} | {"2027": 2.9, "2028": 2.9, "2029": 3.6, "2030": 4.2, "2031": 4.9, "2032": 5.5, "2033": 9.2} | Unificação do crédito presumido do art. 169 (L8 4%-8% x L9 2,9%-9,2%): tabela do L9, com racional documentado |
| C11-02 | linhas_compra.frete_autonomo.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 169 da LC 214 na contratação de t… | Unificação do crédito presumido do art. 169 (L8 4%-8% x L9 2,9%-9,2%): tabela do L9, com racional documentado… |
| C11-03 | linhas_compra.frete_autonomo.credito_fixo_pct_valor_por_ano | {"2027": 4, "2028": 4, "2029": 4, "2030": 5, "2031": 6, "2032": 7, "2033": 8} | {"2027": 2.9, "2028": 2.9, "2029": 3.6, "2030": 4.2, "2031": 4.9, "2032": 5.5, "2033": 9.2} | Unificação do crédito presumido do art. 169 (L8 4%-8% x L9 2,9%-9,2%): tabela do L9, com racional documentado |
| C11-03 | linhas_compra.frete_autonomo.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 169 da LC 214 na contratação de t… | Unificação do crédito presumido do art. 169 (L8 4%-8% x L9 2,9%-9,2%): tabela do L9, com racional documentado… |
| C11-04 | linhas_compra.frete_autonomo.credito_fixo_pct_valor_por_ano | {"2027": 4, "2028": 4, "2029": 4, "2030": 5, "2031": 6, "2032": 7, "2033": 8} | {"2027": 2.9, "2028": 2.9, "2029": 3.6, "2030": 4.2, "2031": 4.9, "2032": 5.5, "2033": 9.2} | Unificação do crédito presumido do art. 169 (L8 4%-8% x L9 2,9%-9,2%): tabela do L9, com racional documentado |
| C11-04 | linhas_compra.frete_autonomo.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 169 da LC 214 na contratação de t… | Unificação do crédito presumido do art. 169 (L8 4%-8% x L9 2,9%-9,2%): tabela do L9, com racional documentado… |
| C12-01 | linhas_compra.autonomos_tac.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 169 da LC 214 na contratação de t… | Unificação do crédito presumido do art. 169 (L8 4%-8% x L9 2,9%-9,2%): tabela do L9, com racional documentado… |
| C12-02 | linhas_compra.autonomos_tac.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 169 da LC 214 na contratação de t… | Unificação do crédito presumido do art. 169 (L8 4%-8% x L9 2,9%-9,2%): tabela do L9, com racional documentado… |
| C12-05 | linhas_compra.entregadores.observacao | (vazio) | Estimativa (mesma em toda a base): crédito presumido do art. 169 da LC 214 na contratação de t… | Unificação do crédito presumido do art. 169 (L8 4%-8% x L9 2,9%-9,2%): tabela do L9, com racional documentado… |
| C11-01 | premissas_operacionais[4] | Crédito presumido na compra de produtor não contribuinte: 1,0% do valor em 2027-2028, subindo … | Crédito presumido na compra de produtor não contribuinte: 1,1% do valor em 2027-2028, subindo … | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-01 | campos_especificos[5].ajuda | só o crédito presumido (perto de 1%). | só o crédito presumido (estimado em 1,1% do valor em 2027-2028). | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-02 | premissas_operacionais[3] | Crédito presumido na compra de não contribuinte: 1,0% do valor pago em 2027-2028 | Crédito presumido na compra de não contribuinte: 1,1% do valor pago em 2027-2028, subindo a 3,… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-02 | regras_especiais_calculo[2] | Crédito presumido tratado como não condicionado porque é apropriado no pagamento ao produtor, … | Crédito presumido tratado como condicionado ao prazo de pagamento ao produtor, porque é apropr… | Unificação do crédito presumido do art. 168 (L4 1,1%-3,0% x L8 1,0%-1,8%): tabela do L4, que acompanha a alíq… |
| C11-03 | analise_critica | vai de 1,3% (favorável) a 4,9% (prudente) | vai de 1,2% (favorável) a 5,1% (prudente) | Números da análise atualizados ao resultado do motor após a harmonização do crédito presumido (art. 168) e do… |
| C11-04 | analise_critica | vai de 3,4% (favorável) a 9,1% (prudente) | vai de 3,4% (favorável) a 8,8% (prudente) | Números da análise atualizados ao resultado do motor após a harmonização do crédito presumido (art. 168) e do… |
| C11-03 | pendencias_verificar[+] | (vazio) | Ato conjunto MF/CGIBS com os percentuais de crédito presumido de 2027 (arts. 168 e 169): não c… | Pendência única para o ato conjunto dos créditos presumidos (consultado em 04/11/2026 na lista do CGIBS: sem … |
| C11-04 | pendencias_verificar[+] | (vazio) | Ato conjunto MF/CGIBS com os percentuais de crédito presumido de 2027 (arts. 168 e 169): não c… | Pendência única para o ato conjunto dos créditos presumidos (consultado em 04/11/2026 na lista do CGIBS: sem … |
| C12-02 | pendencias_verificar[+] | (vazio) | Ato conjunto MF/CGIBS com os percentuais de crédito presumido de 2027 (arts. 168 e 169): não c… | Pendência única para o ato conjunto dos créditos presumidos (consultado em 04/11/2026 na lista do CGIBS: sem … |

#### E. Diesel, combustíveis e gás (80)

| Nicho | Campo | Antes | Depois | Motivo |
| --- | --- | --- | --- | --- |
| C01-01 | linhas_compra.combustivel.credito_pct_cheia | 100 | (removido) | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C01-01 | linhas_compra.combustivel.credito_fixo_pct_valor_por_ano | (vazio) | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C01-01 | linhas_compra.combustivel.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C01-01 | linhas_compra.combustivel.observacao | (vazio) | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C01-02 | linhas_compra.combustivel.credito_pct_cheia | 100 | (removido) | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C01-02 | linhas_compra.combustivel.credito_fixo_pct_valor_por_ano | (vazio) | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C01-02 | linhas_compra.combustivel.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C01-02 | linhas_compra.combustivel.observacao | (vazio) | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C01-03 | linhas_compra.combustivel.credito_pct_cheia | 100 | (removido) | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C01-03 | linhas_compra.combustivel.credito_fixo_pct_valor_por_ano | (vazio) | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C01-03 | linhas_compra.combustivel.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C01-03 | linhas_compra.combustivel.observacao | (vazio) | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C02-06 | linhas_compra.combustivel.credito_pct_cheia | 100 | (removido) | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C02-06 | linhas_compra.combustivel.credito_fixo_pct_valor_por_ano | (vazio) | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C02-06 | linhas_compra.combustivel.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C02-06 | linhas_compra.combustivel.observacao | (vazio) | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C03-02 | linhas_compra.diesel.credito_pct_cheia | 100 | (removido) | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C03-02 | linhas_compra.diesel.credito_fixo_pct_valor_por_ano | (vazio) | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C03-02 | linhas_compra.diesel.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C03-02 | linhas_compra.diesel.observacao | (vazio) | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C04-10 | linhas_compra.combustivel.credito_pct_cheia | 100 | (removido) | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C04-10 | linhas_compra.combustivel.credito_fixo_pct_valor_por_ano | (vazio) | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C04-10 | linhas_compra.combustivel.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C04-10 | linhas_compra.combustivel.observacao | (vazio) | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-01 | linhas_compra.diesel_frota.credito_fixo_pct_valor_por_ano | {"2027": 6, "2028": 6, "2029": 7.9, "2030": 9.7, "2031": 11.6, "2032": 13.5, "2033": 25} | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-01 | linhas_compra.diesel_frota.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-01 | linhas_compra.diesel_frota.observacao | Combustível monofásico ad rem: crédito pelo valor do documento, sem esperar o pagamento (art. … | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-02 | linhas_compra.diesel.credito_fixo_pct_valor_por_ano | {"2027": 6, "2028": 6, "2029": 7.9, "2030": 9.7, "2031": 11.6, "2032": 13.5, "2033": 25} | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-02 | linhas_compra.diesel.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-02 | linhas_compra.diesel.observacao | (vazio) | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-03 | linhas_compra.diesel.credito_fixo_pct_valor_por_ano | {"2027": 6, "2028": 6, "2029": 7.9, "2030": 9.7, "2031": 11.6, "2032": 13.5, "2033": 25} | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-03 | linhas_compra.diesel.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-03 | linhas_compra.diesel.observacao | (vazio) | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-04 | linhas_compra.diesel.credito_fixo_pct_valor_por_ano | {"2027": 6, "2028": 6, "2029": 7.9, "2030": 9.7, "2031": 11.6, "2032": 13.5, "2033": 25} | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-04 | linhas_compra.diesel.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-04 | linhas_compra.diesel.observacao | Monofásico ad rem: crédito pelo valor do documento, sem condição de pagamento (art. 47, §§4º e… | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-05 | linhas_compra.diesel.credito_fixo_pct_valor_por_ano | {"2027": 6, "2028": 6, "2029": 7.9, "2030": 9.7, "2031": 11.6, "2032": 13.5, "2033": 25} | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-05 | linhas_compra.diesel.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C11-05 | linhas_compra.diesel.observacao | (vazio) | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C15-01 | linhas_compra.diesel.credito_fixo_pct_valor_por_ano | {"2027": 6, "2028": 6, "2029": 7.9, "2030": 9.7, "2031": 11.6, "2032": 13.5, "2033": 25} | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C15-01 | linhas_compra.diesel.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C15-01 | linhas_compra.diesel.observacao | (vazio) | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C15-03 | linhas_compra.diesel.credito_fixo_pct_valor_por_ano | {"2027": 6, "2028": 6, "2029": 7.9, "2030": 9.7, "2031": 11.6, "2032": 13.5, "2033": 25} | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C15-03 | linhas_compra.diesel.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C15-03 | linhas_compra.diesel.observacao | (vazio) | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C15-04 | linhas_compra.diesel.credito_fixo_pct_valor_por_ano | {"2027": 6, "2028": 6, "2029": 7.9, "2030": 9.7, "2031": 11.6, "2032": 13.5, "2033": 25} | {"2027": 4.6, "2028": 4.6, "2029": 6, "2030": 7.4, "2031": 8.8, "2032": 10.2, "2033": 18.6} | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C15-04 | linhas_compra.diesel.condicionado | false | false | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C15-04 | linhas_compra.diesel.observacao | Combustível ad rem: crédito pelo documento, sem condição de pagamento. | Crédito fixo em % do valor pago no diesel B (estimativa, mesma em toda a base). 2027-2028: CBS… | Harmonização do diesel: CBS ad rem de R$ 0,3515/L (Portaria MF 3.074/2026, conferida) dá 4,6% do preço; 100% … |
| C12-01 | linhas_compra.diesel.nota | (chave "nota") | (chave "observacao") | Uma só chave para notas de linha em toda a base |
| C12-02 | linhas_compra.diesel.nota | (chave "nota") | (chave "observacao") | Uma só chave para notas de linha em toda a base |
| C12-03 | linhas_compra.diesel.nota | (chave "nota") | (chave "observacao") | Uma só chave para notas de linha em toda a base |
| C12-04 | linhas_compra.diesel.nota | (chave "nota") | (chave "observacao") | Uma só chave para notas de linha em toda a base |
| C12-05 | linhas_compra.combustivel.nota | (chave "nota") | (chave "observacao") | Uma só chave para notas de linha em toda a base |
| C13-04 | linhas_compra.diesel_frota.nota | (chave "nota") | (chave "observacao") | Uma só chave para notas de linha em toda a base |
| C13-05 | linhas_compra.diesel_proprio.nota | (chave "nota") | (chave "observacao") | Uma só chave para notas de linha em toda a base |
| C01-01 | pendencias_verificar | ["Confirmar se o IS integra a base do IBS/CBS na venda do atacado (efeito sobre o débito das b… | ["Confirmar se o IS integra a base do IBS/CBS na venda do atacado (efeito sobre o débito das b… | Resolvida: diesel com a CBS ad rem da Portaria MF 3.074/2026 |
| C01-04 | linhas_compra.combustivel.observacao | (vazio) | Aproximação: 100% da cheia equivale à CBS ad rem da gasolina em 2027-2028 (R$ 0,7925/L, cerca … | Linha de combustível sem tipo definido: nota da aproximação usada (crédito ad rem) |
| C01-14 | linhas_compra.combustivel.observacao | (vazio) | Aproximação: 100% da cheia equivale à CBS ad rem da gasolina em 2027-2028 (R$ 0,7925/L, cerca … | Linha de combustível sem tipo definido: nota da aproximação usada (crédito ad rem) |
| C02-04 | linhas_compra.combustivel.observacao | (vazio) | Aproximação: 100% da cheia equivale à CBS ad rem da gasolina em 2027-2028 (R$ 0,7925/L, cerca … | Linha de combustível sem tipo definido: nota da aproximação usada (crédito ad rem) |
| C02-05 | linhas_compra.combustivel.observacao | (vazio) | Aproximação: 100% da cheia equivale à CBS ad rem da gasolina em 2027-2028 (R$ 0,7925/L, cerca … | Linha de combustível sem tipo definido: nota da aproximação usada (crédito ad rem) |
| C02-14 | linhas_compra.combustivel.observacao | (vazio) | Aproximação: 100% da cheia equivale à CBS ad rem da gasolina em 2027-2028 (R$ 0,7925/L, cerca … | Linha de combustível sem tipo definido: nota da aproximação usada (crédito ad rem) |
| C05-03 | linhas_compra.combustivel.observacao | (vazio) | Aproximação: 100% da cheia equivale à CBS ad rem da gasolina em 2027-2028 (R$ 0,7925/L, cerca … | Linha de combustível sem tipo definido: nota da aproximação usada (crédito ad rem) |
| C08-09 | linhas_compra.combustivel.observacao | (vazio) | Aproximação: 100% da cheia equivale à CBS ad rem da gasolina em 2027-2028 (R$ 0,7925/L, cerca … | Linha de combustível sem tipo definido: nota da aproximação usada (crédito ad rem) |
| C10-05 | linhas_compra.combustivel.observacao | (vazio) | Aproximação: 100% da cheia equivale à CBS ad rem da gasolina em 2027-2028 (R$ 0,7925/L, cerca … | Linha de combustível sem tipo definido: nota da aproximação usada (crédito ad rem) |
| C06-01 | linhas_compra.combustivel.observacao | (vazio) | Aproximação que superestima o crédito: a CBS ad rem do GLP em 2027 é R$ 0,1677/kg (Portaria MF… | GLP com 100% da cheia: nota da aproximação (crédito ad rem real perto de 2% do preço) |
| C06-02 | linhas_compra.gas.observacao | (vazio) | Aproximação que superestima o crédito: a CBS ad rem do GLP em 2027 é R$ 0,1677/kg (Portaria MF… | GLP com 100% da cheia: nota da aproximação (crédito ad rem real perto de 2% do preço) |
| C06-05 | linhas_compra.gas.observacao | (vazio) | Aproximação que superestima o crédito: a CBS ad rem do GLP em 2027 é R$ 0,1677/kg (Portaria MF… | GLP com 100% da cheia: nota da aproximação (crédito ad rem real perto de 2% do preço) |
| C06-06 | linhas_compra.gas.observacao | (vazio) | Aproximação que superestima o crédito: a CBS ad rem do GLP em 2027 é R$ 0,1677/kg (Portaria MF… | GLP com 100% da cheia: nota da aproximação (crédito ad rem real perto de 2% do preço) |
| C04-10 | analise_critica | Com os padrões, o capital preso fica entre 2% e 5% de um mês de faturamento, | Com os padrões, o capital preso fica entre 1,5% e 4% de um mês de faturamento, | Número atualizado: crédito do diesel passou a seguir a CBS ad rem (4,6% do preço) |
| C01-09 | linhas_compra.energia_comb.observacao | (vazio) | Linha mista: a parte de gás (natural ou GLP) é combustível, com crédito pelo documento e sem c… | Coerência com C01-10 e com a regra de combustíveis: nota da simplificação na linha mista de energia e gás |
| C01-12 | linhas_compra.energia.observacao | (vazio) | Linha mista: a parte de gás (natural ou GLP) é combustível, com crédito pelo documento e sem c… | Coerência com C01-10 e com a regra de combustíveis: nota da simplificação na linha mista de energia e gás |
| C01-13 | linhas_compra.energia.observacao | (vazio) | Linha mista: a parte de gás (natural ou GLP) é combustível, com crédito pelo documento e sem c… | Coerência com C01-10 e com a regra de combustíveis: nota da simplificação na linha mista de energia e gás |
| C03-15 | linhas_compra.energia_agua.observacao | (vazio) | Linha mista: a parte de gás (natural ou GLP) é combustível, com crédito pelo documento e sem c… | Coerência com C01-10 e com a regra de combustíveis: nota da simplificação na linha mista de energia e gás |
| C04-01 | linhas_compra.embalagens_insumos.observacao | (vazio) | Linha mista: a parte de gás (natural ou GLP) é combustível, com crédito pelo documento e sem c… | Coerência com C01-10 e com a regra de combustíveis: nota da simplificação na linha mista de energia e gás |
| C04-02 | linhas_compra.energia_insumos.observacao | (vazio) | Linha mista: a parte de gás (natural ou GLP) é combustível, com crédito pelo documento e sem c… | Coerência com C01-10 e com a regra de combustíveis: nota da simplificação na linha mista de energia e gás |
| C04-05 | linhas_compra.energia_gas.observacao | (vazio) | Linha mista: a parte de gás (natural ou GLP) é combustível, com crédito pelo documento e sem c… | Coerência com C01-10 e com a regra de combustíveis: nota da simplificação na linha mista de energia e gás |
| C04-06 | linhas_compra.energia_gas.observacao | (vazio) | Linha mista: a parte de gás (natural ou GLP) é combustível, com crédito pelo documento e sem c… | Coerência com C01-10 e com a regra de combustíveis: nota da simplificação na linha mista de energia e gás |
| C05-01 | linhas_compra.energia.observacao | (vazio) | Linha mista: a parte de gás (natural ou GLP) é combustível, com crédito pelo documento e sem c… | Coerência com C01-10 e com a regra de combustíveis: nota da simplificação na linha mista de energia e gás |
| C05-02 | linhas_compra.energia.observacao | (vazio) | Linha mista: a parte de gás (natural ou GLP) é combustível, com crédito pelo documento e sem c… | Coerência com C01-10 e com a regra de combustíveis: nota da simplificação na linha mista de energia e gás |
| C15-02 | linhas_compra.energia_co2.observacao | (vazio) | Linha mista: a parte de gás (natural ou GLP) é combustível, com crédito pelo documento e sem c… | Coerência com C01-10 e com a regra de combustíveis: nota da simplificação na linha mista de energia e gás |

#### F. Imposto Seletivo (15)

| Nicho | Campo | Antes | Depois | Motivo |
| --- | --- | --- | --- | --- |
| C01-01 | tratamento_tributario.regras_relevantes[2] | Imposto Seletivo sobre bebidas açucaradas (art. 409, §1º, V) incide uma vez na indústria ou im… | Imposto Seletivo sobre bebidas açucaradas (art. 409, §1º, V) incide uma vez na indústria ou im… | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C01-01 | riscos_pontos_abertos[2] | Alíquotas do Imposto Seletivo de bebidas açucaradas para 2027, pendentes de medida provisória | Alíquotas do Imposto Seletivo de bebidas açucaradas: MP anunciada para 04/11/2026; vigência em… | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C03-01 | tratamento_tributario.vendas[5].observacao | Alíquotas do IS ainda dependem da MP anunciada em outubro de 2026. | Alíquotas do IS: MP anunciada para 04/11/2026 (não publicada até 03/11); cobrança a partir de … | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C03-01 | riscos_pontos_abertos[3] | Alíquotas do Imposto Seletivo pendentes da MP anunciada em outubro de 2026: risco de preço e d… | Alíquotas do Imposto Seletivo pendentes da MP anunciada para 04/11/2026 (vigência em 2027 só s… | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C03-04 | tratamento_tributario.regras_relevantes[2] | Alíquotas pendentes da MP anunciada em outubro de 2026; o governo indicou manter em 2027 a car… | Alíquotas do IS: MP anunciada para 04/11/2026 (não publicada até 03/11); cobrança a partir de … | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C03-14 | tratamento_tributario.vendas[1].observacao | Alíquotas do IS ainda dependem da MP anunciada em outubro de 2026. | Alíquotas do IS: MP anunciada para 04/11/2026 (não publicada até 03/11); cobrança a partir de … | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C03-14 | analise_critica | que ainda dependem da MP anunciada em outubro de 2026. | que ainda dependem da MP anunciada para 04/11/2026 e só valem em 2027 se ela virar lei até 31/… | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C03-14 | riscos_pontos_abertos[0] | Alíquotas do IS pendentes da MP anunciada em outubro de 2026, com efeito em preço e volume | Alíquotas do IS pendentes da MP anunciada para 04/11/2026 (vigência em 2027 só se virar lei at… | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C03-14 | pendencias_verificar[1] | Acompanhar a publicação da MP do Imposto Seletivo | Acompanhar a publicação da MP do Imposto Seletivo (anunciada para 04/11/2026) e a conversão em… | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C06-04 | riscos_pontos_abertos[1] | Valor do Imposto Seletivo sobre bebidas alcoólicas, ainda em definição | Valor do Imposto Seletivo sobre bebidas alcoólicas: MP anunciada para 04/11/2026; vigência em … | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C15-01 | tratamento_tributario.resumo | Com a noventena, a cobrança começa em fevereiro de 2027, | Com a noventena, a cobrança começa em fevereiro de 2027, se a MP virar lei até 31/12/2026 (CF,… | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C15-01 | regras_especiais_calculo[3] | Em 2027, se a MP sair até 04/11/2026, o IS só é cobrado a partir de fevereiro; | Em 2027, se a MP sair até 04/11/2026 e virar lei até 31/12/2026, o IS só é cobrado a partir de… | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C15-02 | tratamento_tributario.resumo | Alíquotas: MP anunciada para 04/11/2026, cobrança a partir de fevereiro de 2027. | Alíquotas: MP anunciada para 04/11/2026, cobrança a partir de fevereiro de 2027 se a MP virar … | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C15-03 | tratamento_tributario.regras_relevantes[1] | cobrança a partir de fevereiro de 2027 pela noventena. | cobrança a partir de fevereiro de 2027 pela noventena, se a MP virar lei até 31/12/2026 (CF, a… | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |
| C15-04 | tratamento_tributario.regras_relevantes[2] | com cobrança a partir de fevereiro de 2027. | com cobrança a partir de fevereiro de 2027 se a MP virar lei até 31/12/2026 (senão, em 2028). | Status do IS harmonizado em 04/11/2026 (Portal Reforma Tributária, 03/11/2026; CF, art. 62, §2º) |

#### G. Fato gerador (art. 10, §§3º, 4º e 7º; art. 254) (172)

| Nicho | Campo | Antes | Depois | Motivo |
| --- | --- | --- | --- | --- |
| C02-01 | linhas_receita.mensal_regular.prazo_dias | 10 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-01 | linhas_receita.pix_auto.prazo_dias | 5 | 0 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-01 | campos_especificos.dias_vencimento | {"id": "dias_vencimento", "rotulo": "Dias entre a nota e o vencimento do boleto", "padrao": 10… | {"id": "atraso_mensalidade", "rotulo": "Dias que o cliente costuma atrasar depois do venciment… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-01 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-01 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-01 | premissas_operacionais[0] | Prazo de vencimento da mensalidade: 10 dias após a nota | Atraso do cliente depois do vencimento (mensalidade): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-01 | regras_especiais_calculo[+] | (vazio) | Pix Automático cobra no vencimento: pix_auto.prazo_dias = 0. | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-02 | linhas_receita.alocacao.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-02 | linhas_receita.projetos.prazo_dias | 45 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-02 | campos_especificos.prazo_cliente | {"id": "prazo_cliente", "rotulo": "Prazo de pagamento dos clientes privados", "padrao": 30, "a… | {"id": "atraso_alocacao", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento",… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-02 | campos_especificos.prazo_projeto | {"id": "prazo_projeto", "rotulo": "Prazo de pagamento dos marcos de projeto", "padrao": 45, "a… | {"id": "atraso_marcos", "rotulo": "Dias que o cliente atrasa o pagamento dos marcos depois do … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-02 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-02 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-02 | premissas_operacionais[0] | Prazo de pagamento da alocação: 30 dias | Atraso do cliente depois do vencimento (alocação e marcos): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-02 | analise_critica | Com prazo de 30 a 45 dias, boa parte do imposto já vence antes de o cliente pagar, então o spl… | Na alocação mensal e nos marcos, o imposto só nasce no vencimento da parcela (art. 10, §3º), e… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-02 | analise_critica | As entradas que mais mexem são prazo do cliente, percentual antecipado e parcela de clientes d… | As entradas que mais mexem são a parcela de clientes do regime regular, o atraso depois do ven… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-02 | split.observacoes[1] | Prazos longos (30 a 60 dias) reduzem o efeito; antecipação de recebíveis aumenta muito. | Prazo longo de pagamento não reduz o efeito, porque o imposto nasce no vencimento da parcela (… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-03 | linhas_receita.privados.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-03 | linhas_receita.simples.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-03 | campos_especificos.dia_pagamento | {"id": "dia_pagamento", "rotulo": "Dia do mês em que o cliente privado paga a fatura do mês an… | {"id": "atraso_privados", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento",… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-03 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-03 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-03 | premissas_operacionais[0] | Pagamento dos clientes privados: Dia 15 do mês seguinte | Atraso do cliente depois do vencimento: 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-03 | analise_critica | o dia de pagamento do cliente | o atraso do cliente depois do vencimento | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-04 | linhas_receita.privados.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-04 | linhas_receita.simples.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-04 | campos_especificos.dia_pagamento | {"id": "dia_pagamento", "rotulo": "Dia do mês em que o cliente privado paga a fatura do mês an… | {"id": "atraso_privados", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento",… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-04 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-04 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-04 | premissas_operacionais[0] | Pagamento dos clientes privados: Dia 15 do mês seguinte | Atraso do cliente depois do vencimento: 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-04 | analise_critica | o dia de pagamento e | o atraso do cliente depois do vencimento e | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-05 | linhas_receita.manutencao_contrato.prazo_dias | 45 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-05 | linhas_receita.paradas_montagem.prazo_dias | 60 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-05 | campos_especificos.prazo_medicao | {"id": "prazo_medicao", "rotulo": "Prazo de pagamento da medição de manutenção", "padrao": 45,… | {"id": "atraso_medicao", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento", … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-05 | campos_especificos.prazo_paradas | {"id": "prazo_paradas", "rotulo": "Prazo de pagamento de paradas e montagem", "padrao": 60, "a… | {"id": "prazo_pecas", "rotulo": "Prazo de pagamento das peças faturadas à parte", "padrao": 45… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-05 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-05 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-05 | premissas_operacionais[0] | Prazo de pagamento da medição: 45 dias | Atraso do cliente depois do vencimento (contrato e medição): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-05 | analise_critica | A calculadora faz sentido e o efeito dominante é débito antecipado, mas menor do que se espera… | A calculadora faz sentido e o efeito dominante é débito antecipado. O prazo de 45 a 60 dias nã… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-05 | analise_critica | As entradas que mais mexem são o percentual antecipado, o prazo de medição e o peso de peças. | As entradas que mais mexem são a parcela de clientes do regime regular, o atraso depois do ven… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-06 | linhas_receita.locacao_construtoras.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-06 | linhas_receita.locacao_agro.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-06 | linhas_receita.locacao_simples.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-06 | campos_especificos.prazo_cliente | {"id": "prazo_cliente", "rotulo": "Prazo de pagamento da locação", "padrao": 30, "alvos": ["li… | {"id": "atraso_locacao", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento", … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-06 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-06 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-06 | premissas_operacionais[+] | (vazio) | {"premissa": "Atraso do cliente depois do vencimento (locação mensal)", "valor": "3 dias", "ti… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-07 | linhas_receita.gtf_regular.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-07 | campos_especificos.prazo_cliente | {"id": "prazo_cliente", "rotulo": "Prazo de pagamento da fatura mensal de frota", "padrao": 30… | {"id": "atraso_frota", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento", "p… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-07 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-07 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-07 | premissas_operacionais[+] | (vazio) | {"premissa": "Atraso do cliente depois do vencimento (fatura mensal de frota)", "valor": "3 di… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-08 | linhas_receita.fee_regular.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-08 | campos_especificos.prazo_cliente | {"id": "prazo_cliente", "rotulo": "Prazo de pagamento dos anunciantes", "padrao": 30, "alvos":… | {"id": "atraso_honorario_fixo", "rotulo": "Dias que o cliente costuma atrasar depois do vencim… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-08 | campos_especificos[+] | (vazio) | {"id": "prazo_producao", "rotulo": "Prazo de pagamento da produção refaturada", "padrao": 30, … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-08 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-08 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-08 | premissas_operacionais[+] | (vazio) | {"premissa": "Atraso do cliente depois do vencimento (honorário fixo mensal)", "valor": "3 dia… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-09 | linhas_receita.corporativo.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-09 | campos_especificos.dia_pagamento | {"id": "dia_pagamento", "rotulo": "Dia do mês em que a empresa cliente paga a fatura do mês an… | {"id": "atraso_corporativo", "rotulo": "Dias que o cliente costuma atrasar depois do venciment… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-09 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-09 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-09 | premissas_operacionais[3] | Pagamento dos clientes corporativos: Dia 15 do mês seguinte | Atraso do cliente depois do vencimento (contratos corporativos): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-09 | analise_critica | o dia de pagamento dos clientes corporativos | o atraso dos clientes corporativos depois do vencimento | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-10 | linhas_receita.atendimento.prazo_dias | 45 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-10 | campos_especificos.prazo_cliente | {"id": "prazo_cliente", "rotulo": "Prazo de pagamento dos clientes de atendimento", "padrao": … | {"id": "atraso_atendimento", "rotulo": "Dias que o cliente costuma atrasar depois do venciment… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-10 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-10 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-10 | premissas_operacionais[0] | Prazo dos clientes de atendimento: 45 dias | Atraso do cliente depois do vencimento (contratos de atendimento): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-10 | analise_critica | mas o prazo longo dos grandes clientes (45 a 60 dias) reduz bastante o float que se perde. | e o prazo longo dos grandes clientes (45 a 60 dias) não ajuda: no contrato mensal, o imposto s… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-10 | split.observacoes[1] | Clientes grandes pagam em 45 a 60 dias, o que dilui o efeito. | Clientes grandes pagam em 45 a 60 dias, mas isso não dilui o efeito, porque o imposto nasce no… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-10 | analise_critica | As entradas que mais mexem são o percentual antecipado, o prazo dos clientes e o peso da cobra… | As entradas que mais mexem são a parcela de clientes do regime regular, o percentual antecipad… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-11 | linhas_receita.temporario.prazo_dias | 15 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-11 | linhas_receita.bpo_rh.prazo_dias | 15 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-11 | campos_especificos.periodicidade | {"id": "periodicidade", "rotulo": "Como fatura os temporários", "padrao": 15, "alvos": ["linha… | {"id": "atraso_fatura", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento", "… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-11 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-11 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-11 | premissas_operacionais[0] | Prazo de pagamento da fatura de temporários: 15 dias | Atraso do cliente depois do vencimento (temporários e gestão de folha): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-11 | analise_critica | A agência fatura salários mais taxa, recebe em cerca de 15 dias e quase não tem crédito. | A agência fatura salários mais taxa, recebe perto do vencimento e quase não tem crédito; como … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-11 | analise_critica | As entradas que mais mexem são o prazo de pagamento, a antecipação e a parcela de clientes do … | As entradas que mais mexem são a parcela de clientes do regime regular, a margem da agência e … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-11 | tese_consultoria | renegociação de prazo e periodicidade de faturamento | renegociação de preço e da periodicidade de faturamento | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-12 | linhas_receita.retainer.prazo_dias | 10 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-12 | regras_especiais_calculo[+] | (vazio) | Honorário fixo mensal: retainer.prazo_dias = 3 (atraso depois do vencimento); notas de projeto… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-14 | linhas_receita.comissao_industria.prazo_dias | 15 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-14 | linhas_receita.comissao_simples.prazo_dias | 15 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-14 | campos_especificos.prazo_comissao | {"id": "prazo_comissao", "rotulo": "Dias entre a nota da comissão e o pagamento da indústria",… | {"id": "atraso_comissao", "rotulo": "Dias que a indústria atrasa a comissão depois da data de … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-14 | premissas_operacionais[0] | Prazo de pagamento da comissão: 15 dias após a nota | Atraso do cliente depois do vencimento (comissão): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C02-14 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C06-01 | linhas_receita.contratos_privados.prazo_dias | 40 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C06-01 | campos_especificos.prazo_fatura | {"id": "prazo_fatura", "rotulo": "Prazo de pagamento das faturas privadas", "padrao": 40, "alv… | {"id": "atraso_fatura", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento", "… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C06-01 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C06-01 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C06-01 | premissas_operacionais[0] | Prazo de pagamento das faturas privadas: 40 dias da refeição ao pagamento | Atraso do cliente depois do vencimento (faturas de refeições): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C06-01 | analise_critica | O efeito dominante é a perda do imposto que hoje fica no caixa nas faturas antecipadas no banc… | O efeito dominante é o débito antecipado: como o contrato é contínuo, o imposto nasce no venci… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C06-01 | analise_critica | parcela de clientes privados do regime regular, percentual antecipado e prazo da fatura. | parcela de clientes privados do regime regular, percentual antecipado e atraso depois do venci… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C06-01 | split.observacoes[0] | Dois efeitos somam: o imposto deixa de ficar no caixa nas faturas pagas antes do vencimento e … | Dois efeitos somam: o imposto, que nasce no vencimento da fatura (art. 10, §3º), deixa de fica… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-01 | linhas_receita.medicao_privada.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-01 | campos_especificos.prazo_medicao | {"id": "prazo_medicao", "rotulo": "Prazo de pagamento da medição", "padrao": 30, "alvos": ["li… | {"id": "atraso_medicao", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento", … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-01 | premissas_operacionais[0] | Prazo de pagamento da medição de clientes privados: 30 dias | Atraso do cliente depois do vencimento (medições): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-01 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-02 | linhas_receita.medicao.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-02 | campos_especificos.prazo_medicao | {"id": "prazo_medicao", "rotulo": "Prazo de pagamento da medição", "padrao": 30, "alvos": ["li… | {"id": "atraso_medicao", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento", … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-02 | premissas_operacionais[0] | Prazo de pagamento da medição: 30 dias | Atraso do cliente depois do vencimento (medições): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-02 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-03 | linhas_receita.obra_construtoras.prazo_dias | 35 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-03 | linhas_receita.manutencao.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-03 | campos_especificos.prazo_medicao | {"id": "prazo_medicao", "rotulo": "Prazo de pagamento das construtoras", "padrao": 35, "alvos"… | {"id": "atraso_medicao", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento", … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-03 | premissas_operacionais[1] | Prazo das construtoras: 35 dias | Atraso do cliente depois do vencimento (medições e manutenção): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-03 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-01 | pendencias_verificar[+] | (vazio) | Leitura alternativa da caução: pelo art. 10, §3º, o imposto da parte retida pode nascer só na … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-02 | pendencias_verificar[+] | (vazio) | Leitura alternativa da caução: pelo art. 10, §3º, o imposto da parte retida pode nascer só na … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-07 | linhas_receita.locacao_construtoras.prazo_dias | 28 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-07 | linhas_receita.montagem_frete.prazo_dias | 28 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-07 | campos_especificos.prazo_fatura | {"id": "prazo_fatura", "rotulo": "Prazo do boleto da fatura mensal", "padrao": 28, "alvos": ["… | {"id": "atraso_fatura", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento", "… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-07 | premissas_operacionais[0] | Prazo do boleto da fatura: 28 dias | Atraso do cliente depois do vencimento (locação mensal): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-07 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C07-08 | linhas_receita.comissao_lancamento.prazo_dias | 30 | 0 | Art. 254, IV, e §2º (conferido): na intermediação e administração de imóveis o imposto nasce em cada pagament… |
| C07-08 | linhas_receita.comissao_empresas.prazo_dias | 10 | 0 | Art. 254, IV, e §2º (conferido): na intermediação e administração de imóveis o imposto nasce em cada pagament… |
| C07-08 | campos_especificos.prazo_incorporadora | {"id": "prazo_incorporadora", "rotulo": "Prazo para a incorporadora pagar a comissão", "padrao… | {"id": "prazo_incorporadora", "rotulo": "Prazo para a incorporadora pagar a comissão", "padrao… | Art. 254, IV, e §2º (conferido): na intermediação e administração de imóveis o imposto nasce em cada pagament… |
| C07-08 | regras_especiais_calculo[+] | (vazio) | Comissões e taxas: prazo_dias = 0, porque o imposto da intermediação e da administração nasce … | Art. 254, IV, e §2º (conferido): na intermediação e administração de imóveis o imposto nasce em cada pagament… |
| C10-01 | linhas_receita.honorarios_regular.prazo_dias | 10 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-01 | campos_especificos.dia_vencimento | {"id": "dia_vencimento", "rotulo": "Prazo do boleto da mensalidade", "padrao": 10, "alvos": ["… | {"id": "atraso_honorarios", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-01 | premissas_operacionais[1] | Prazo do boleto: 10 dias | Atraso do cliente depois do vencimento (honorário mensal): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-01 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-02 | linhas_receita.partido_regular.prazo_dias | 15 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-02 | linhas_receita.exito_regular.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-02 | campos_especificos.prazo_boleto | {"id": "prazo_boleto", "rotulo": "Prazo do boleto do partido", "padrao": 15, "alvos": ["linhas… | {"id": "atraso_partido", "rotulo": "Dias que o cliente costuma atrasar depois do vencimento", … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-02 | premissas_operacionais[+] | (vazio) | {"premissa": "Atraso do cliente depois do vencimento (partido e êxito)", "valor": "3 dias", "t… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-02 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-03 | linhas_receita.projetos_privados.prazo_dias | 40 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-03 | campos_especificos.prazo_etapa | {"id": "prazo_etapa", "rotulo": "Prazo de pagamento das etapas privadas", "padrao": 40, "alvos… | {"id": "atraso_etapa", "rotulo": "Dias que a empresa atrasa o pagamento das etapas depois do v… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-03 | premissas_operacionais[0] | Prazo das etapas privadas: 40 dias | Atraso do cliente depois do vencimento (etapas de projeto): 3 dias | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-03 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-04 | linhas_receita.projetos_empresas.prazo_dias | 30 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-04 | campos_especificos.prazo_empresas | {"id": "prazo_empresas", "rotulo": "Prazo de pagamento das empresas", "padrao": 30, "alvos": [… | {"id": "atraso_etapa", "rotulo": "Dias que a empresa atrasa o pagamento das etapas depois do v… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-04 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-04 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C10-04 | premissas_operacionais[+] | (vazio) | {"premissa": "Atraso do cliente depois do vencimento (etapas de projeto)", "valor": "3 dias", … | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C09-01 | linhas_receita.convenio_empresas.prazo_dias | 10 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C09-01 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C09-01 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C03-11 | linhas_receita.agregadores.prazo_dias | 40 | 3 | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C03-11 | campos_especificos.prazo_agregadores | {"id": "prazo_agregadores", "rotulo": "Dias até o agregador pagar", "padrao": 40, "alvos": ["l… | {"id": "atraso_agregadores", "rotulo": "Dias que o agregador atrasa o repasse depois do vencim… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C03-11 | tratamento_tributario.regras_relevantes[+] | (vazio) | Contrato mensal ou por etapa é execução continuada ou fracionada: o imposto nasce quando a par… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C03-11 | regras_especiais_calculo[+] | (vazio) | Linhas de contrato mensal ou por etapa: prazo_dias = atraso médio do cliente depois do vencime… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C03-11 | premissas_operacionais[1] | Agregadores corporativos: 20% do faturamento, pagos em cerca de 40 dias | Agregadores corporativos: 20% do faturamento, repasse mensal pago no vencimento (atraso de 3 d… | Art. 10, §3º (redação da LC 227/2026, conferida): em contrato mensal ou por etapa o imposto nasce no vencimen… |
| C06-06 | pendencias_verificar[1] | Confirmar a regra dos 5 dias para pagamento e fornecimento no mesmo período (art. 10, §4º) | Confirmar se o regulamento usou a regra dos 5 dias entre pagamento antecipado e fornecimento (… | Citação corrigida: a regra dos 5 dias é o §7º, não o §4º (art. 10 conferido) |
| C02-15 | tratamento_tributario.regras_relevantes[+] | (vazio) | Pagamento antes do fornecimento: o imposto é antecipado na data de cada pagamento, com acerto … | Harmonização do pagamento antecipado (art. 10, §4º) em todos os nichos com linha de adiantamento |
| C13-02 | tratamento_tributario.regras_relevantes[+] | (vazio) | Pagamento antes do fornecimento: o imposto é antecipado na data de cada pagamento, com acerto … | Harmonização do pagamento antecipado (art. 10, §4º) em todos os nichos com linha de adiantamento |
| C02-02 | analise_critica | A calculadora faz sentido, mas o número tende a ser menor do que o cliente teme. | A calculadora faz sentido e o número tende a ser maior do que o cliente imagina: perto de 11% … | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C02-03 | analise_critica | O split tira entre 3% e 5% de um mês de faturamento do caixa em 2028 | Como o contrato é mensal, o imposto nasce no vencimento da fatura (art. 10, §3º) e o split tir… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C02-03 | analise_critica | Parece pouco, mas a margem é de 4% a 7%: o efeito pode consumir um mês inteiro de lucro | Com margem de 4% a 7%, o efeito passa de um mês inteiro de lucro | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C02-04 | analise_critica | débito antecipado quase puro, porque a folha não gera crédito. | débito antecipado quase puro, porque a folha não gera crédito, e o imposto do contrato mensal … | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C02-05 | analise_critica | O que pesa é o risco sacado: a medição antecipada hoje traz o imposto junto e, com o split, ch… | O resultado fica entre 12% e 22% de um mês de faturamento em 2028; a diferença entre os cenári… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C02-06 | analise_critica | A calculadora faz sentido e o efeito dominante é saldo credor, como no mapeamento. A locadora … | A calculadora faz sentido e há dois efeitos de peso parecido. O débito antecipado na locação m… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C02-06 | split.observacoes[0] | O efeito dominante é saldo credor: o crédito da compra de máquinas passa do débito que sobra e… | Dois efeitos de peso parecido: débito antecipado na locação mensal (imposto no vencimento, art… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C02-07 | analise_critica | As entradas que mais mexem são a compra de carros por mês | Como a fatura de frota é mensal, o imposto nasce no vencimento (art. 10, §3º) e o split também… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C02-08 | analise_critica | O split atinge só a receita própria (fee, honorários e produção) e tira o prazo de imposto de … | O split atinge só a receita própria (honorário fixo, comissão e produção). No honorário fixo m… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C02-09 | analise_critica | A calculadora faz sentido e o efeito é débito antecipado, um pouco menor que na limpeza pura, | A calculadora faz sentido e o efeito é débito antecipado, perto de 9% a 11% de um mês de fatur… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C02-11 | analise_critica | O efeito de caixa de 2028 fica perto de 10% de um mês de faturamento, o que equivale a cerca d… | O efeito de caixa de 2028 fica perto de 13% a 14% de um mês de faturamento, o que passa de um … | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C02-14 | analise_critica | a indústria paga a comissão por TED em cerca de 15 dias e o imposto sai na hora | a comissão é de prestação continuada, o imposto nasce quando ela fica exigível (art. 10, §3º) … | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C03-11 | analise_critica | O efeito de caixa é pequeno: cerca de 3% de um mês de faturamento em 2028, | O efeito de caixa é pequeno: cerca de 4% a 5% de um mês de faturamento em 2028, | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C06-01 | analise_critica | É o nicho de restaurante em que a calculadora mais faz sentido. | É o nicho de restaurante em que a calculadora mais faz sentido: perto de 10% a 12% de um mês d… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C07-01 | analise_critica | O número que mais mexe no caixa é o prazo de ressarcimento, não o float das vendas; | O número que mais mexe no caixa é o prazo de ressarcimento, não o prazo do imposto nas vendas … | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C07-02 | analise_critica | Quem antecipa medições sente mais, porque hoje embolsa o imposto até o vencimento. | Como a medição é execução fracionada, o imposto nasce no vencimento do pagamento (art. 10, §3º… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C07-02 | analise_critica | As entradas que mais mexem são a parcela antecipada, o prazo da medição e a margem. | As entradas que mais mexem são a parcela antecipada, a parcela de construtoras do regime regul… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C07-03 | analise_critica | No cenário favorável domina o débito antecipado nos contratos B2B (cerca de 3% de um mês de re… | No cenário favorável domina o débito antecipado nos contratos B2B (cerca de 6% de um mês de re… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C07-07 | analise_critica | As entradas que mais mexem são a fatia de construtoras do regime regular, o prazo do boleto e … | Na locação mensal o imposto nasce no vencimento da fatura (art. 10, §3º), então o boleto de 28… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C10-01 | analise_critica | e o honorário vence em poucos dias, então o float perdido é o do imposto até o fim do mês segu… | e o imposto do honorário mensal nasce no vencimento (art. 10, §3º), então o split leva o prazo… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C10-02 | analise_critica | moderado porque o boleto vence em cerca de 15 dias e o escritório tem pouco crédito. | de cerca de 6% a 7% de um mês de honorários em 2028: o imposto do partido e do êxito nasce no … | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C10-03 | analise_critica | Débito a 70% da cheia, prazo de 40 dias nas etapas privadas e pouco crédito dão um débito ante… | Débito a 70% da cheia e pouco crédito dão um débito antecipado de cerca de 6% a 7% de um mês d… | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |
| C10-03 | analise_critica | o prazo das etapas e o cumprimento dos requisitos. | o atraso do cliente e o cumprimento dos requisitos. | Números da análise atualizados ao novo resultado do motor (fato gerador no vencimento da parcela, art. 10, §3… |

#### H. Simples Nacional nas regras da calculadora (11)

| Nicho | Campo | Antes | Depois | Motivo |
| --- | --- | --- | --- | --- |
| C04-07 | regras_especiais_calculo[+] | (vazio) | Se o usuário escolher "Simples puro": não rodar o motor; o optante puro paga IBS/CBS no DAS, n… | Briefing: regras_especiais_calculo deve dizer o que a calculadora faz no Simples puro |
| C09-04 | regras_especiais_calculo[+] | (vazio) | Se o usuário escolher "Simples puro": não rodar o motor; o optante puro paga IBS/CBS no DAS, n… | Briefing: regras_especiais_calculo deve dizer o que a calculadora faz no Simples puro |
| C11-02 | regras_especiais_calculo[+] | (vazio) | Se o usuário escolher "Simples puro": não rodar o motor; o optante puro paga IBS/CBS no DAS, n… | Briefing: regras_especiais_calculo deve dizer o que a calculadora faz no Simples puro |
| C11-05 | regras_especiais_calculo[+] | (vazio) | Se o usuário escolher "Simples puro": não rodar o motor; o optante puro paga IBS/CBS no DAS, n… | Briefing: regras_especiais_calculo deve dizer o que a calculadora faz no Simples puro |
| C12-04 | regras_especiais_calculo[+] | (vazio) | Se o usuário escolher "Simples puro": não rodar o motor; o optante puro paga IBS/CBS no DAS, n… | Briefing: regras_especiais_calculo deve dizer o que a calculadora faz no Simples puro |
| C13-05 | regras_especiais_calculo[+] | (vazio) | Se o usuário escolher "Simples puro": não rodar o motor; o optante puro paga IBS/CBS no DAS, n… | Briefing: regras_especiais_calculo deve dizer o que a calculadora faz no Simples puro |
| C13-06 | regras_especiais_calculo[+] | (vazio) | Se o usuário escolher "Simples puro": não rodar o motor; o optante puro paga IBS/CBS no DAS, n… | Briefing: regras_especiais_calculo deve dizer o que a calculadora faz no Simples puro |
| C07-06 | regras_especiais_calculo[+] | (vazio) | Se o usuário escolher "Simples puro": avisar que a atividade é vedada no Simples Nacional (LC … | Briefing: regras_especiais_calculo deve dizer o que a calculadora faz no Simples puro |
| C07-04 | regras_especiais_calculo[+] | (vazio) | Se o usuário escolher "Simples puro": avisar que a atividade é vedada no Simples Nacional (LC … | Briefing: regras_especiais_calculo deve dizer o que a calculadora faz no Simples puro |
| C07-05 | regras_especiais_calculo[+] | (vazio) | Se o usuário escolher "Simples puro": avisar que a atividade é vedada no Simples Nacional (LC … | Briefing: regras_especiais_calculo deve dizer o que a calculadora faz no Simples puro |
| C11-04 | regras_especiais_calculo[+] | (vazio) | Se o produtor PJ for do Simples puro: não rodar o motor e mostrar que ele não aproveita a regr… | Briefing: regras_especiais_calculo deve dizer o que a calculadora faz no Simples puro |

#### I. Português e rótulos (37)

| Nicho | Campo | Antes | Depois | Motivo |
| --- | --- | --- | --- | --- |
| C02-08 | campos_especificos[0].rotulo | (fee, comissão e honorários) | (honorário fixo, comissão e honorários de produção) | Português do Brasil: termo em inglês trocado |
| C02-08 | descricao_negocio | cobrando fee mensal, | cobrando honorário fixo mensal, | Português do Brasil: termo em inglês trocado |
| C02-08 | tratamento_tributario.vendas[0].item | Fee mensal, criação e honorários | Honorário fixo mensal, criação e honorários | Português do Brasil: termo em inglês trocado |
| C02-08 | linhas_receita.fee_regular.nome | Fees e honorários de anunciantes do regime regular | Honorários fixos e de criação de anunciantes do regime regular | Português do Brasil: termo em inglês trocado |
| C02-11 | campos_especificos[1].ajuda | Fee por vaga preenchida. | Taxa por vaga preenchida. | Português do Brasil: termo em inglês trocado |
| C02-12 | campos_especificos.pct_retainer | {"id": "pct_retainer", "rotulo": "Retainer mensal", "padrao": 20, "alvos": ["linhas_receita.re… | {"id": "pct_retainer", "rotulo": "Honorário fixo mensal (contrato de acompanhamento)", "padrao… | Português do Brasil: termo em inglês trocado |
| C02-12 | linhas_receita.retainer.nome | Retainer mensal pago por Pix ou boleto, regime regular | Honorário fixo mensal pago por Pix ou boleto, regime regular | Português do Brasil: termo em inglês trocado |
| C02-12 | tratamento_tributario.vendas[0].item | Projetos, horas e retainer para empresas | Projetos, horas e honorário fixo mensal para empresas | Português do Brasil: termo em inglês trocado |
| C02-12 | descricao_negocio | por hora ou retainer mensal | por hora ou honorário fixo mensal | Português do Brasil: termo em inglês trocado |
| C02-12 | analise_critica | pesa mais no retainer e no sinal | pesa mais no honorário fixo mensal e no sinal | Português do Brasil: termo em inglês trocado |
| C02-12 | dados_para_coletar[2] | Contratos com sinal, retainer e êxito | Contratos com sinal, honorário fixo mensal e êxito | Português do Brasil: termo em inglês trocado |
| C02-12 | regras_especiais_calculo[1] | mostrar checklist do art. 127 | mostrar a lista de requisitos do art. 127 | Português do Brasil: termo em inglês trocado |
| C02-15 | regras_especiais_calculo[1] | mostrar checklist do art. 127 | mostrar a lista de requisitos do art. 127 | Português do Brasil: termo em inglês trocado |
| C02-10 | tratamento_tributario.vendas[2].item | (atendimento offshore) | (atendimento a partir do Brasil) | Português do Brasil: termo em inglês trocado |
| C06-03 | dados_para_coletar[1] | (fee, prazo de fatura) | (taxa de serviço, prazo de fatura) | Português do Brasil: termo em inglês trocado |
| C06-03 | tese_consultoria | ajuste de contratos de fee | ajuste de contratos de taxa de serviço | Português do Brasil: termo em inglês trocado |
| C06-03 | premissas_operacionais[0].racional | somando fee, margem e incentivos | somando taxa de serviço, margem e incentivos | Português do Brasil: termo em inglês trocado |
| C09-05 | campos_especificos.pct_empresas | {"id": "pct_empresas", "rotulo": "Turmas in-company (% do faturamento)", "padrao": 20, "alvos"… | {"id": "pct_empresas", "rotulo": "Turmas fechadas para empresas (% do faturamento)", "padrao":… | Português do Brasil: termo em inglês trocado |
| C09-05 | campos_especificos.prazo_in_company | {"id": "prazo_in_company", "rotulo": "Prazo de pagamento das turmas in-company", "padrao": 30,… | {"id": "prazo_in_company", "rotulo": "Prazo de pagamento das turmas fechadas para empresas", "… | Português do Brasil: termo em inglês trocado |
| C14-03 | linhas_compra.servicos.nome | Call center, leads, sistemas, energia e serviços PJ | Call center, compra de contatos de clientes, sistemas, energia e serviços PJ | Português do Brasil: termo em inglês trocado |
| C14-03 | campos_especificos.pct_servicos | {"id": "pct_servicos", "rotulo": "Call center, leads, sistemas, energia e serviços PJ (% das c… | {"id": "pct_servicos", "rotulo": "Call center, compra de contatos, sistemas, energia e serviço… | Português do Brasil: termo em inglês trocado |
| C14-03 | pendencias_verificar[2] | (chargeback) | (estorno da comissão) | Português do Brasil: termo em inglês trocado |
| C12-02 | linhas_receita.cliente_simples.nome | Sellers de e-commerce e clientes do Simples | Lojistas de comércio eletrônico e clientes do Simples | Português do Brasil: termo em inglês trocado |
| C12-05 | linhas_compra.aluguel_hub.nome | Aluguel de base ou hub de PJ | Aluguel de base ou centro de distribuição de PJ | Português do Brasil: termo em inglês trocado |
| C14-01 | premissas_operacionais[1].racional | com funding misto | com captação mista | Português do Brasil: termo em inglês trocado |
| C03-05 | premissas_operacionais[0].racional | markup | margem sobre o custo | Português do Brasil: termo em inglês trocado |
| C03-06 | premissas_operacionais[0].racional | markup | margem sobre o custo | Português do Brasil: termo em inglês trocado |
| C03-12 | premissas_operacionais[1].racional | markup | margem sobre o custo | Português do Brasil: termo em inglês trocado |
| C10-05 | campos_especificos.cumpre_127 | {"id": "cumpre_127", "rotulo": "A sociedade cumpre os requisitos do art. 127 na topografia?", … | {"id": "cumpre_127", "rotulo": "Todos os sócios da topografia são engenheiros ou técnicos regi… | Rótulo escrito para o dono do negócio, sem jargão de lei |
| C11-03 | campos_especificos.opcao_271 | {"id": "opcao_271", "rotulo": "A cooperativa optou pelo regime do art. 271 (alíquota zero com … | {"id": "opcao_271", "rotulo": "A cooperativa optou pelo regime de cooperativas (alíquota zero … | Rótulo escrito para o dono do negócio, sem jargão de lei |
| C01-13 | campos_especificos.pct_reduzida | {"id": "pct_reduzida", "rotulo": "Vendas de pão de forma e massas do Anexo VII", "padrao": 10,… | {"id": "pct_reduzida", "rotulo": "Vendas de pão de forma e massas recheadas ou instantâneas (r… | Rótulo escrito para o dono do negócio, sem jargão de lei |
| C08-07 | campos_especificos.pct_fora_anexo | {"id": "pct_fora_anexo", "rotulo": "Terapias que não estão no Anexo III", "padrao": 5, "alvos"… | {"id": "pct_fora_anexo", "rotulo": "Terapias sem a redução de 60% (terapia ocupacional, acupun… | Rótulo escrito para o dono do negócio, sem jargão de lei |
| C11-01 | campos_especificos.pct_outros_regular | {"id": "pct_outros_regular", "rotulo": "Itens fora do Anexo IX vendidos a clientes do regime r… | {"id": "pct_outros_regular", "rotulo": "Peças, ferramentas e outros itens (fora dos insumos) v… | Rótulo escrito para o dono do negócio, sem jargão de lei |
| C11-01 | campos_especificos.prazo_outros | {"id": "prazo_outros", "rotulo": "Prazo médio dos itens fora do Anexo IX", "padrao": 60, "alvo… | {"id": "prazo_outros", "rotulo": "Prazo médio das peças, ferramentas e outros itens", "padrao"… | Rótulo escrito para o dono do negócio, sem jargão de lei |
| C05-02 | campos_especificos.pct_cheia | {"id": "pct_cheia", "rotulo": "Produtos fora do Anexo VII (néctar com açúcar, geleia, bolos)",… | {"id": "pct_cheia", "rotulo": "Produtos sem a redução de 60% (néctar com açúcar, geleia, bolos… | Rótulo escrito para o dono do negócio, sem jargão de lei |
| C05-02 | campos_especificos.pct_insumo_reduzido | {"id": "pct_insumo_reduzido", "rotulo": "Insumos do Anexo VII comprados de indústrias (% do fa… | {"id": "pct_insumo_reduzido", "rotulo": "Insumos com redução de 60% comprados de indústrias (p… | Rótulo escrito para o dono do negócio, sem jargão de lei |
| C08-05 | campos_especificos.pct_higiene | {"id": "pct_higiene", "rotulo": "Higiene básica do Anexo VIII (sabonete, creme dental, papel h… | {"id": "pct_higiene", "rotulo": "Higiene básica com redução de 60% (sabonete em barra, creme d… | Rótulo escrito para o dono do negócio, sem jargão de lei |

#### J. Outras (15)

| Nicho | Campo | Antes | Depois | Motivo |
| --- | --- | --- | --- | --- |
| C03-01 | pendencias_verificar[0] | Confirmar no texto da LC 214 o artigo da alíquota zero de hortícolas, frutas e ovos (Anexo XV) | (removido) | Resolvida na revisão: art. 148 conferido no Jurishand |
| C05-01 | pendencias_verificar[0] | Artigo e requisitos da alíquota zero de produtos de saúde menstrual | (removido) | Resolvida: art. 147 |
| C11-02 | analise_critica | O percentual do crédito presumido de 2027 ainda não foi publicado e pode mudar o resultado. | O percentual do crédito presumido de 2027 ainda não foi publicado; a base usa a mesma estimati… | Harmonização da estimativa do art. 168 |
| C01-01 | tratamento_tributario.regras_relevantes[3] | Saldo credor pode ser compensado ou ressarcido; o prazo depende de programa de conformidade (3… | Saldo credor pode ser compensado ou ressarcido: 30 dias no programa de conformidade, 60 dias s… | Mesmo texto de prazos de ressarcimento do contexto global; "pedido comum" era impreciso |
| C02-08 | analise_critica | A calculadora faz sentido, mas o número de caixa é pequeno, e por isso a exposição baixa de al… | A calculadora faz sentido; em proporção à receita própria o efeito é relevante, mas em reais é… | Texto ajustado ao novo resultado (8% a 10% de um mês de receita própria em 2028) |
| C03-15 | linhas_compra.frete.observacao | (vazio) | Estimativa: metade dos fretes de transportadoras do regime regular (crédito cheio) e metade de… | Crédito com fração mista sem justificativa: nota da estimativa adicionada |
| C03-07 | linhas_compra.frete_montagem.observacao | (vazio) | Estimativa: mistura de transportadoras e montadores do regime regular (crédito cheio) e do Sim… | Crédito com fração mista sem justificativa: nota da estimativa adicionada |
| C07-04 | linhas_compra.projetos_marketing.observacao | (vazio) | Estimativa: maior parte de agências e projetistas do regime regular (crédito cheio), com parte… | Crédito com fração mista sem justificativa: nota da estimativa adicionada |
| C07-05 | linhas_compra.marketing_projetos.observacao | (vazio) | Estimativa: maior parte de fornecedores do regime regular (crédito cheio), com parte do Simple… | Crédito com fração mista sem justificativa: nota da estimativa adicionada |
| C10-03 | linhas_compra.ensaios.observacao | (vazio) | Estimativa: laboratórios e topógrafos do regime regular, parte com redução de 30% do art. 127 … | Crédito com fração mista sem justificativa: nota da estimativa adicionada |
| C08-06 | linhas_compra.materiais.observacao | (vazio) | Estimativa: parte dos materiais odontológicos é dispositivo médico do Anexo IV (40% da cheia) … | Crédito com fração mista sem justificativa: nota da estimativa adicionada |
| C07-06 | linhas_compra.servicos_prof.observacao | (vazio) | Contadores, advogados e engenheiros em sociedade que cumpre o art. 127 destacam 70% da cheia. | Crédito com fração mista sem justificativa: nota da estimativa adicionada |
| C07-08 | linhas_compra.servicos_prof.observacao | (vazio) | Contadores e advogados em sociedade que cumpre o art. 127 destacam 70% da cheia. | Crédito com fração mista sem justificativa: nota da estimativa adicionada |
| C07-09 | linhas_compra.servicos_prof.observacao | (vazio) | Advogados e contadores em sociedade que cumpre o art. 127 destacam 70% da cheia. | Crédito com fração mista sem justificativa: nota da estimativa adicionada |
| C12-03 | linhas_compra.servicos.observacao | (vazio) | Estimativa: a garagem alugada (locação de imóvel, 30% da cheia) é o maior item da linha. | Crédito com fração mista sem justificativa: nota da estimativa adicionada |

#### K. Fontes adicionadas (64)

| Fonte | Nichos |
| --- | --- |
| LC 214/2025, art. 51 (anulação de créditos só em imunidade e isenção), Juruá Docs | C01-01, C01-11, C03-14, C08-05, C09-04 |
| LC 214/2025, art. 148 (alíquota zero de hortícolas, frutas e ovos do Anexo XV), Jurishand | C03-01 |
| LC 214/2025, art. 47 (§10: redução de alíquota não exige estorno de crédito), Juruá Docs | C09-04, C11-03, C11-05 |
| LC 214/2025, art. 136 (redução de 60% para higiene e limpeza do Anexo VIII), Jurishand | C03-01, C05-01, C05-03 |
| Senado: LC 214/2025, Anexo VIII (higiene pessoal e limpeza com redução de 60%) | C02-03, C03-01, C08-05 |
| LC 214/2025, art. 127 (rol das 18 profissões, requisitos do §1º e §3º para educação física), Jurishand | C02-12, C02-15, C03-11 |
| Simtax: redução de 30% de IBS/CBS, quem tem direito (inclui exceção da educação física) | C03-11 |
| Portal da Reforma Tributária: Fazenda agora diz que MP do Imposto Seletivo sai na quarta-feira (03/11/2026) | C01-01, C03-01, C03-04, C03-14, C06-04 |
| Confeb: Imposto Seletivo em 2027, perdida a noventena, a cobrança começa depois de 1º de janeiro (14/10/2026) | C01-01, C03-01, C03-04, C03-14, C06-04, C15-01, C15-02, C15-03, C15-04 |
| LC 214/2025, art. 10 (§3º execução continuada ou fracionada; §4º pagamento antecipado), Juruá Docs | C02-02, C02-03, C02-04, C02-06, C02-07, C02-08, C02-09, C02-10, C02-11, C02-15, C03-11, C06-01, C07-01, C07-02, C07-03, C07-07, C09-01, C10-01, C10-02, C10-03, C10-04, C13-02 |
| LC 214/2025, art. 254 (momento do fato gerador nas operações com imóveis), Juruá Docs | C07-08 |
| Migalhas: o aspecto temporal do IBS e da CBS à luz da LC 214/25 (18/05/2026) | C02-02, C02-05, C02-10, C06-01, C07-01, C07-03, C10-01, C12-03 |


## 10. Correção do motor feita depois da revisão (versão 1.1)

A recomendação da seção 6.1 sobre o saldo credor estrutural foi aplicada no próprio `engine_v2.js`, para que o `resultado_exemplo` já venha certo.

- **Saldo credor.** O motor calcula o saldo credor que existiria sem split: max(0, crédito − débito total) × prazo de ressarcimento / 30. Esse valor sai do efeito do split e passa a aparecer à parte, em `saldo_credor_sem_split`, em cada ano.
- **Cenário favorável.** Só abate em tempo real o crédito que encontra retenção para abater, no máximo débito × phi. O resultado não fica abaixo de zero: o crédito abatido na retenção não sai antes do débito que abate.
- **Teste de regressão.** A distribuidora do simulador original continua em R$ 907.198 (prudente) e R$ 242.355 (favorável) em 2028. Como o crédito dela é menor que o débito, nada muda.
- **Mudaram 17 nichos**, todos com crédito acima do débito. Os demais 106 ficaram iguais. Três textos de análise que citavam números foram atualizados (C04-10, C11-05, C13-05).

| Nicho | 2028 favorável | 2028 prudente | 2033 prudente | Saldo credor sem split, 2028 (% de um mês) |
| --- | --- | --- | --- | --- |
| C04-01 Frigorífico e abatedouro | 2,8% → 1,2% | 11,5% → 7,4% | 30,7% → 19,7% | 4,1% |
| C04-02 Laticínio | 2,9% → 1,5% | 12,8% → 9,3% | 34% → 24,6% | 3,5% |
| C04-03 Beneficiadora de arroz, feijão e cereais | 6% → 3,1% | 13,2% → 5,8% | 35% → 15,4% | 7,4% |
| C04-04 Moinho, farinhas e massas | 7,6% → 2,2% | 14,3% → 6,7% | 37,8% → 17,7% | 7,6% |
| C04-06 Torrefação de café | 4,3% → 2,2% | 11,9% → 6,7% | 31,7% → 17,8% | 5,2% |
| C04-07 Granja de ovos e avicultura | 4% → 1,5% | 5,9% → 2,4% | 15,8% → 6,4% | 3,5% |
| C04-08 Açougue e casa de carnes | 1,2% → 0,9% | 1,2% → 0,9% | 3,2% → 2,3% | 0,3% |
| C04-10 Distribuidora de hortifrúti (Ceasa) | 1,6% → 0,2% | 4,1% → 1,1% | 11,5% → 2,9% | 3,0% |
| C04-11 Peixaria e indústria de pescados | 0,8% → 0,7% | 11,3% → 11,1% | 30% → 29,5% | 0,2% |
| C07-01 Construtora de empreitada global | 6,8% → 6,3% | 21,6% → 20,8% | 57,1% → 55% | 0,8% |
| C07-04 Incorporadora | 4,4% → 3,9% | 6% → 5,4% | 15,8% → 14,2% | 0,6% |
| C08-01 Distribuidora de medicamentos e materiais hospitalares | 6,4% → 4,8% | 8,9% → 7,2% | 23,6% → 19,1% | 1,7% |
| C09-04 Faculdade e ensino superior | 4,5% → 2,7% | 5,8% → 3,8% | 8,4% → 8,4% | 1,9% |
| C11-02 Cerealista, armazém e trading de grãos | 1,3% → 0,2% | 9,6% → 7,5% | 25,7% → 20% | 2,1% |
| C11-05 Concessionária de máquinas agrícolas | 2,1% → 1,5% | 36,8% → 35,5% | 97,6% → 94,1% | 1,3% |
| C13-04 Distribuidora de gás GLP | 0,8% → 0,2% | 3,2% → 2% | 8,9% → 5,2% | 1,3% |
| C13-05 TRR (revenda de diesel a frotas e agro) | 0% → 0% | 2,4% → 2,1% | 6,4% → 5,6% | 0,3% |
