# Resumo da base de nichos

Versão 1.1, data de referência 04/11/2026.

A base tem 123 nichos. Nove agentes pesquisaram em paralelo, e um revisor no fim conferiu se os lotes concordam entre si e seguem o plano. Todos passam no validador.

Cada nicho traz:
- o enquadramento de IBS/CBS, com base legal e quanto ela é certa;
- como a empresa recebe e compra;
- os campos do formulário com o vocabulário do setor e um valor de exemplo;
- as premissas, marcadas como fato, estimativa ou hipótese, com fonte (são 290 páginas diferentes ao todo);
- a análise crítica, a tese de consultoria e as perguntas para a reunião;
- um resultado de exemplo já calculado.

No seu exemplo, "Agronegócio e insumos > Produtor rural PJ (grãos e pecuária)", o formulário pergunta:
- se a fazenda é contribuinte de IBS/CBS;
- quanto dos grãos vai para cerealista e quanto para trading exportadora;
- quanto é boi vendido a frigorífico;
- em quantos dias recebe;
- quanto gasta com diesel e máquinas por ano.

Com os valores de exemplo, o capital de giro extra em 2028 fica entre 3,4% e 8,8% de um mês de receita.

**O que o revisor mudou:** foram 491 mudanças em 94 nichos. As que mais mexem nos números:
- **Contratos mensais:** o imposto nasce no vencimento da parcela, não na nota (art. 10, §3º). Em 24 nichos de serviço o efeito mais que dobrou. Limpeza, por exemplo, foi de 4,6% para 9,6% de um mês de receita.
- **Diesel:** o crédito passou a 4,6% do preço, pela CBS por litro da Portaria 3.074. Alguns lotes usavam a alíquota cheia, cerca de 2,5 vezes mais.
- **Crédito presumido** na compra de produtor rural e de caminhoneiro autônomo: agora uma tabela só para todos os nichos.

Depois da revisão eu corrigi o motor. Nos nichos de alíquota zero (cesta, exportação), ele contava como custo do split um crédito que fica preso em ressarcimento mesmo sem split. Agora esse valor aparece à parte, em `saldo_credor_sem_split`, e 17 nichos mudaram. O frigorífico, por exemplo, foi de 11,5% para 7,4% no cenário prudente. A distribuidora do simulador original deu os mesmos números de antes.

**O que a base mostra:**
- **Quem sente mais:** indústria e atacado B2B (mediana de 14,9% de um mês de receita em 2028) e serviços B2B (12,6%). Saúde, educação, restaurantes e varejo ficam entre 3% e 5%.
- **Os mais expostos:** concessionária de máquinas agrícolas (até 35,5%), máquinas sob encomenda (29,2%) e locação de frotas (26,3%).
- **Para todos:** em 2033, com o IBS cheio, a mediana passa de 7,3% para 19,6% de um mês de receita.

**O que continua sem resposta oficial:**
- **Regra de compensação:** não saiu a regra que diz se o crédito abate o split em até 48 horas ou só na apuração mensal. É isso que separa os dois cenários, e em 31 nichos o prudente passa do dobro do favorável. O site deve mostrar os dois sempre.
- **Crédito presumido de 2027:** os percentuais oficiais ainda não foram publicados.
- **Imposto Seletivo:** a medida provisória ainda não saiu.
- **Academias:** ainda não está confirmado se têm a redução de 30%.

**Para o prompt do site:** use o `base-nichos-split.json` e o `engine_v2.js`, que é o motor de cálculo. O `dicionario-base.md` explica cada campo e como o formulário vira cálculo. Três coisas precisam constar no prompt:
1. Cerca de 25 campos têm fórmulas que não são cópia direta para o cálculo; a fórmula de cada um está no campo `derivacao` e o site precisa implementá-la.
2. A opção "Simples puro" é um fluxo separado, que não roda o motor.
3. O site tem de chegar ao mesmo `resultado_exemplo` com os valores padrão; é o teste de que a implementação está certa.

A seção 6 do `revisao-base.md` lista o que o site deve avisar e o que não deve prometer. A planilha é só para leitura: parte dos campos fica apenas no JSON.