# Dicionário da base de nichos do split payment

Versão 1.1. Data de referência: 04/11/2026. Este arquivo explica cada campo de `base-nichos-split.json` e como o site deve usar a base. O cálculo está em `engine_v2.js`.

## Como o site usa a base

1. **Menu:** agrupar `nichos` por `categoria` e mostrar `nicho`. O `rotulo_menu` já vem no formato "Categoria > Nicho".
2. **Formulário:** campos comuns (`contexto_global.campos_comuns_formulario`: caixa, limites, alíquotas, adesão, ano do teste) mais os `campos_especificos` do nicho, com os valores de `padrao` preenchidos como exemplo.
3. **Do formulário para o cálculo:** cada campo específico diz em `alvos` o que altera e em `derivacao` a fórmula. O site reconstrói `linhas_receita`, `linhas_compra`, `receita_mensal` e `prazo_pagamento_fornecedor_dias` e chama o motor.
4. **Regras e avisos:** aplicar `regras_especiais_calculo` (alertas, casos em que a calculadora não se aplica, por exemplo empresa no Simples puro) e mostrar o texto de `tratamento_tributario.simples_nacional` quando o usuário marcar Simples.
5. **Resultado:**
   - mostrar a faixa favorável a prudente por ano;
   - fazer o teste de caixa (`cashTest` do motor);
   - mostrar `tese_consultoria` e `perguntas_diagnostico` como próximo passo.
6. **Conferência:** `resultado_exemplo` traz o que o motor dá com os valores padrão. Use para testar a implementação: com os padrões, o site deve chegar aos mesmos números.

## Nível superior

| Campo | O que é |
| --- | --- |
| `versao`, `data_referencia`, `descricao` | Identificação da base |
| `contexto_global` | Alíquotas, rampa do IBS, regras do split, reduções, parâmetros padrão e campos comuns do formulário, com fontes |
| `motor` | Resumo das fórmulas do `engine_v2.js` |
| `nichos` | Lista dos 123 nichos |

## Campos de cada nicho

| Campo | Tipo | O que é |
| --- | --- | --- |
| `id` | texto | Código `Cxx-nn` (categoria e sequência) |
| `categoria_codigo`, `categoria`, `nicho`, `rotulo_menu` | texto | Navegação do site |
| `cnae` | objeto | `divisao` e `classes_exemplo` para buscar empresas pelo CNAE |
| `descricao_negocio`, `porte_alvo`, `regimes_tipicos` | texto, lista | Quem é o cliente típico |
| `tratamento_tributario.resumo` | texto | Enquadramento em uma frase |
| `tratamento_tributario.vendas[]` | lista | Cada item vendido com `aliquota_pct_cheia`, `base_legal`, `status` (lei, regulamento, interpretacao, estimativa), `confianca` e `observacao` |
| `tratamento_tributario.credito_ao_cliente` | texto | Se o comprador PJ toma crédito |
| `tratamento_tributario.regras_relevantes` | lista | Regras do setor que mexem no caixa |
| `tratamento_tributario.simples_nacional` | objeto | `relevancia` e `tratamento`: o que muda no Simples puro e o que a calculadora mostra |
| `split` | objeto | `exposicao` (alta, media, baixa) do lado das vendas, `quando`, `meios_fase1`, `observacoes` |
| `receita_mensal_padrao` | número (R$) | Receita mensal do exemplo, sem IBS/CBS |
| `linhas_receita[]` | lista | Como a empresa fatura e recebe (ver abaixo) |
| `linhas_compra[]` | lista | O que gera crédito (ver abaixo) |
| `prazo_pagamento_fornecedor_dias` | número | Prazo médio pago aos fornecedores |
| `caixa_exemplo` | objeto | `caixa`, `caixa_minimo`, `limites`, `custo_credito_pct_am`, `geracao_caixa_mes` do exemplo |
| `campos_especificos[]` | lista | Campos do formulário do nicho (ver abaixo) |
| `regras_especiais_calculo` | lista | Lógica além do motor padrão, alertas e casos fora do escopo |
| `perguntas_diagnostico`, `dados_para_coletar` | lista | Roteiro da reunião e lista de documentos |
| `analise_critica` | texto | Leitura de consultor: se a calculadora faz sentido, o que domina, o que é contraintuitivo |
| `tese_consultoria` | texto | O serviço que vale vender a esse nicho |
| `premissas_operacionais[]` | lista | Premissa, valor, tipo (F fato, E estimativa, H hipótese), racional e fonte |
| `riscos_pontos_abertos`, `pendencias_verificar` | lista | O que pode mudar a conta e o que falta confirmar |
| `prioridade` | 1, 2 ou 3 | 1 = construir primeiro |
| `confianca_geral` | alta, media, baixa | Confiança no enquadramento e nas premissas |
| `fontes[]` | lista | `titulo`, `url`, `acesso` |
| `resultado_exemplo` | objeto | Calculado pelo motor com os padrões: por ano (débito, crédito, favorável, prudente, novo no ano, decomposição do prudente e `saldo_credor_sem_split`), % de um mês de receita em 2028 e 2033 e teste de caixa de 2028 |

## Linha de receita

| Campo | O que é |
| --- | --- |
| `id`, `nome` | Identificador e descrição |
| `participacao_pct` | % da receita mensal; a soma das linhas é 100 |
| `cliente` | `regime_regular`, `simples`, `consumidor_final`, `publico`, `exportacao`, `misto`, `produtor_nao_contribuinte`, `plataforma` |
| `meio` | `pix_ted`, `boleto`, `tef`, `medicao`, `adiantamento`, `cartao`, `voucher`, `repasse_financiamento`, `dinheiro`, `outro` |
| `prazo_dias` | Dias entre a nota e o pagamento do cliente |
| `antecipado_pct` | % da linha antecipada em banco, FIDC ou factoring |
| `aliquota_pct_cheia` | Fração da alíquota cheia aplicada: 100 cheia, 70 (−30%), 60 (−40%), 50 (−50%), 40 (−60%), 30 (−70%), 0 (zero, exportação, revenda monofásica) |
| `aliquota_especifica_por_ano` | Opcional: alíquota em % por ano quando não é fração da referência (serviços financeiros) |
| `parcela_sujeita_split_pct` | % da linha paga por comprador do regime regular por meio da etapa 1. É 0 para cartão, voucher, dinheiro, consumidor, órgão público, exportação, Simples e produtor não contribuinte |

## Linha de compra

| Campo | O que é |
| --- | --- |
| `id`, `nome` | Identificador e descrição |
| `pct_receita` | Valor mensal da compra em % da receita |
| `credito_pct_cheia` | Crédito em fração da alíquota cheia: 100 fornecedor regular, 40 com redução de 60%, 7 fornecedor do Simples |
| `credito_fixo_pct_valor_por_ano` | Opcional: crédito em % do valor por ano (crédito presumido, combustível ad rem) |
| `condicionado` | `true` se o crédito depende da extinção do débito do fornecedor; `false` para combustíveis e casos sem condição |

## Campo específico do formulário

| Campo | O que é |
| --- | --- |
| `id`, `rotulo`, `ajuda` | Identificador, texto do campo e explicação curta |
| `tipo` | `moeda`, `percentual`, `dias`, `meses`, `numero`, `selecao`, `booleano` |
| `unidade`, `min`, `max`, `opcoes` | Restrições e opções de seleção |
| `padrao` | Valor de exemplo, que reproduz as linhas padrão |
| `alvos` | O que o campo altera: `linhas_receita.<id>.<atributo>`, `linhas_compra.<id>.<atributo>`, `receita_mensal`, `prazo_pagamento_fornecedor_dias`, `mensagem`, `regra_especial` |
| `derivacao` | A fórmula, em texto, que liga o campo aos alvos |

## O que o resultado significa

- **Capital de giro extra:** dinheiro que a empresa precisa ter a mais, de forma permanente, por causa do split e do crédito condicionado, contra o mesmo ano sem split e com crédito pelo destaque. A carga de imposto não muda; o prazo muda.
- **Novo no ano:** quanto entra de necessidade nova naquele ano. O salto de 2033 vem do IBS cheio.
- **Saldo credor sem split** (`saldo_credor_sem_split`): crédito que passa do débito total e ficaria em ressarcimento mesmo sem split. É comum com alíquota zero (cesta, exportação). Não entra no capital de giro extra. O site deve mostrá-lo à parte, como "capital que já fica preso hoje".
- **Decomposição do prudente:** débito antecipado (o imposto sai na hora do recebimento), crédito condicionado (o crédito espera o fornecedor pagar) e saldo credor (a sobra de crédito que o split acrescenta).
- **Cenários:**
  - Favorável: os créditos abatem a retenção em até 48 h.
  - Prudente: os créditos só abatem na apuração mensal.
  - A regra oficial ainda não foi publicada.
- **Semáforo:**
  - Verde: o caixa livre cobre e o custo fica abaixo de 5% da geração de caixa.
  - Amarelo: não falta dinheiro e o custo fica abaixo de 15%.
  - Vermelho: nos demais casos.
