# Plataforma de diagnóstico de caixa do split payment

Data de referência: 04/11/2026. Este pacote reúne tudo o que foi produzido para estudar o split payment de IBS/CBS e montar uma plataforma de consultoria sobre o tema: estudo, simuladores, mapa de nichos, base de dados com 123 nichos, estratégia de produto e as ferramentas para manter a base.

É análise financeira, não parecer jurídico ou contábil. As datas do split são previsão da Receita, sem ato normativo publicado.

## O que tem em cada pasta

| Pasta | Arquivo | O que é |
| --- | --- | --- |
| 01-estudo | `estudo-split-payment.md` | O estudo completo: como o split funciona, cronograma, de onde vem o buraco no caixa, por que o middle market é o mais exposto, metodologia do diagnóstico, consultoria, software, riscos e fontes |
| 01-estudo | `grafico-distribuidora.png` | Gráfico do estudo: capital de giro extra de uma distribuidora B2B de 2027 a 2033 |
| 02-simuladores | `simulador-caixa-split.html` | Simulador geral com quatro perfis (distribuidora, indústria, serviços, varejo). Abre direto no navegador |
| 02-simuladores | `split-empreitada-global.html`, `split-consultoria-engenharia.html` | Calculadoras setoriais, os primeiros exemplos de formulário por nicho |
| 03-mapa-de-nichos | `mapa-nichos-split.xlsx` | Mapa preliminar dos 123 nichos em 15 categorias de tributação. Foi o ponto de partida da base; onde os dois divergem, vale a base |
| 04-base-de-dados | `base-nichos-split.json` | **A base para o site.** 123 nichos com enquadramento, linhas de receita e compra, campos do formulário, premissas, análise crítica, tese de consultoria, fontes e resultado de exemplo |
| 04-base-de-dados | `engine_v2.js` | O motor de cálculo usado na base. O site deve usar este motor sem reescrever as fórmulas |
| 04-base-de-dados | `dicionario-base.md` | O que significa cada campo e como o site usa a base |
| 04-base-de-dados | `revisao-base.md` | Relatório do revisor: contradições resolvidas, 491 mudanças, pendências e, na seção 6, o que o site deve avisar e o que não deve prometer |
| 04-base-de-dados | `base-nichos-split.xlsx` | A base em planilha, para leitura. Não tem todos os campos do JSON |
| 04-base-de-dados | `resumo-da-base.md` | Os principais achados da base |
| 05-produto | `estrategia-de-produto.md` | Como transformar isso em produto de consultoria: escada de ofertas, preço, nichos para começar, canais, momento e cuidados |
| 05-produto | `roteiro-do-prompt-do-site.md` | O que o prompt para construir o site precisa conter, os campos do formulário e as decisões em aberto |
| 06-manutencao-da-base | lotes e scripts | Para atualizar a base ou acrescentar nichos (ver abaixo) |

## Como as peças se encaixam

1. **Entender o tema:** `01-estudo`.
2. **Ver o cálculo funcionando:** `02-simuladores`.
3. **Escolher os nichos:** `03-mapa-de-nichos` e, com mais detalhe, a base.
4. **Construir a plataforma:** entregue a quem vai construir o site a pasta `04-base-de-dados` inteira e o `roteiro-do-prompt-do-site.md`. Antes, responda as quatro decisões em aberto no fim do roteiro.
5. **Vender:** `05-produto/estrategia-de-produto.md`.

## Versões online

- [Estudo (documento online)](https://claude.ai/artifact/SbGCVj2A4wW2HmEt4pJK9r)
- [Simulador de caixa do split](https://claude.ai/artifact/JYLcmkY1txKn8JPUc39hGj)
- [Calculadora de empreitada global](https://claude.ai/artifact/J2wjMUq97debpfvpMiX86g)
- [Calculadora de consultoria de engenharia](https://claude.ai/artifact/6uSbBih9jQdCUsoNWswrLP)

Os links são privados até você compartilhar.

## Simuladores e motor da base

Os três simuladores HTML são protótipos com o motor da primeira versão embutido. A base usa o `engine_v2.js`, que generaliza o mesmo cálculo para qualquer nicho. A v2 também separa o saldo credor que já existiria sem split, comum em nichos de alíquota zero. Para a distribuidora do simulador os dois motores dão o mesmo número: R$ 907.198 no cenário prudente e R$ 242.355 no favorável, em 2028. Para a plataforma, use o `engine_v2.js`.

## Como manter a base (pasta 06)

Precisa de Node.js para os scripts `.js` e de Python com openpyxl para a planilha. Rode os comandos dentro da pasta `06-manutencao-da-base`.

- **Conferir um lote:** `node validate.js out_L1.json`. Tem de terminar em "TUDO OK".
- **Gerar a base de novo:** `node merge.js`. Grava `base_consolidada.json` nesta pasta. Com os arquivos como estão, sai idêntica ao `base-nichos-split.json`.
- **Gerar a planilha:** `python3 build_entrega.py base_consolidada.json base-nichos-split.xlsx`.
- **Mudar uma premissa global** (por exemplo, a CBS de 2027 depois da decisão do Senado): edite `parametros_globais_padrao` em `contexto_global.json` e rode o `merge.js`. Os resultados de exemplo dos 123 nichos são recalculados.
- **Corrigir um nicho:** edite o registro no lote (`out_L1.json` a `out_L9.json`), rode o validador e o `merge.js`.
- **Acrescentar um nicho:** siga o `briefing.md` e use o `exemplo_registro.json` como modelo. Acrescente o nicho em `nichos_input.json` e o registro num lote.

Os lotes por categoria:

| Lote | Categorias |
| --- | --- |
| L1 | C01 |
| L2 | C02 |
| L3 | C03 |
| L4 | C04 e C05 |
| L5 | C06 e C09 |
| L6 | C07 e C10 |
| L7 | C08 e C14 |
| L8 | C11 e C15 |
| L9 | C12 e C13 |

## O que acompanhar e atualizar

| Quando | O quê | O que mudar na base |
| --- | --- | --- |
| 10/11/2026 | Audiência na CAE do Senado sobre a alíquota da CBS | Nada ainda |
| Até 15/12/2026 | Senado fixa a CBS de 2027 (sem resolução, vale 11,35% do TCU) | `cbs_referencia_pct` em `contexto_global.json` |
| Sem data | MP do Imposto Seletivo e sua conversão em lei até 31/12/2026 | Nichos C15-01 e C15-02, e o status do IS em 9 nichos |
| Sem data | Regra de compensação do crédito: em até 48 horas ou só na apuração mensal | Qual cenário mostrar como principal |
| Sem data | Ato conjunto com os percentuais do crédito presumido de 2027 | 19 linhas de compra em 16 nichos (C04, C05-02, C11, C12) |
| 2º semestre de 2027 | Split facultativo, previsto | `adesao_2027_pct` |

A lista completa de pendências está na seção 5 do `revisao-base.md` e no campo `pendencias_verificar` de cada nicho.
