# Briefing comum: base de dados de nichos para o diagnóstico de caixa do split payment

Data de referência: 04/11/2026. Todos os agentes usam este mesmo briefing. Leia inteiro antes de começar.

## Para que serve a base

Uma consultoria vai lançar um site onde o usuário escolhe uma categoria e um nicho (ex.: "Agronegócio e insumos > Produtor rural PJ") e recebe um formulário personalizado, com o vocabulário do setor. O formulário alimenta um motor de cálculo (`engine_v2.js`) que mede quanto capital de giro a mais a empresa vai precisar por causa do split payment e do crédito condicionado de IBS/CBS, de 2027 a 2033. O motor também diz se o caixa, os limites de crédito ou um aporte do sócio cobrem esse valor.

Sua tarefa: produzir, para cada nicho do seu lote, um registro JSON com tudo o que o site precisa para montar o formulário e rodar o cálculo. Isso inclui tratamento tributário verificado, linhas de receita e de compra com valores padrão realistas, campos do formulário, premissas com fonte, análise crítica e fontes.

## Arquivos

Todos ficam na mesma pasta deste briefing (06-manutencao-da-base).

- `contexto_global.json`: alíquotas, cronograma do split, regras gerais e parâmetros globais. Já verificado. **Não pesquise de novo o que está aqui.** Use e cite.
- `nichos_input.json`: os 123 nichos com o mapeamento preliminar. Filtre pelo seu `lote`. O mapeamento é um ponto de partida e pode estar errado; corrija o que achar.
- `exemplo_registro.json`: um registro completo (C07-01, empreitada global). **É o padrão de profundidade e de formato.** Copie a estrutura.
- `engine_v2.js`: o motor. Leia para entender o que cada campo faz no cálculo.
- `validate.js`: o validador. Rode antes de terminar.

## Como o motor usa os dados (resumo)

- **Débito mensal de cada linha de receita** = receita × participação × alíquota cheia do ano × `aliquota_pct_cheia`/100. A alíquota cheia de 2027-2028 é a CBS de referência; de 2029 a 2033 soma o IBS na rampa.
- **Efeito das vendas:** só existe na parte da linha paga por comprador do regime regular por meio da etapa 1 (`parcela_sujeita_split_pct`). O imposto deixa de ficar no caixa entre o recebimento e o vencimento (último dia útil do mês seguinte). Recebível antecipado perde o imposto que hoje entra adiantado.
- **Crédito de cada linha de compra** = receita × `pct_receita` × alíquota cheia do ano × `credito_pct_cheia`/100. Uma alternativa é `credito_fixo_pct_valor_por_ano`, para crédito presumido ou ad rem.
  - Se `condicionado` = true, o crédito atrasa até o fornecedor extinguir o débito: no pagamento via split ou RAD, ou no vencimento dele.
  - Se `condicionado` = false (ex.: combustíveis, art. 47, §§4º e 5º), não atrasa.
- **Saldo credor:** se os créditos passam dos débitos que ainda estão em aberto, a sobra vai para ressarcimento.
- **Dois cenários:**
  - **Favorável:** os créditos abatem a retenção em até 48 h.
  - **Prudente:** os créditos só abatem na apuração mensal.

## Regras de preenchimento das linhas

- **`aliquota_pct_cheia`** é a fração da alíquota cheia aplicada, de 0 a 100:

  | Tratamento | Valor |
  | --- | --- |
  | Cheia | 100 |
  | Redução de 30% | 70 |
  | Redução de 40% | 60 |
  | Redução de 50% | 50 |
  | Redução de 60% | 40 |
  | Redução de 70% | 30 |
  | Zero, exportação ou revenda monofásica | 0 |

  Para alíquota que não é fração da referência (serviços financeiros: 10,85% em 2027-2028, subindo a 12,5% em 2033), use `aliquota_especifica_por_ano` com os percentuais por ano. Nesse caso, explique na observação.
- **`parcela_sujeita_split_pct`:**
  - Deve ser 0 quando o meio é `cartao`, `voucher` ou `dinheiro`.
  - Deve ser 0 quando o cliente é `consumidor_final`, `publico`, `exportacao`, `simples` ou `produtor_nao_contribuinte`.
  - Para `regime_regular` por meio da etapa 1 (Pix, TED, TEF, boleto, medição, adiantamento), use 100. A adesão por ano é global.
  - Para `misto`, informe a parte do regime regular.
  - Prefira separar em linhas a usar `misto`.
- **Enumerações:**
  - `cliente`: regime_regular, simples, consumidor_final, publico, exportacao, misto, produtor_nao_contribuinte, plataforma.
  - `meio`: pix_ted, boleto, tef, medicao, adiantamento, cartao, voucher, repasse_financiamento, dinheiro, outro.
- **Soma das linhas:** a soma de `participacao_pct` das linhas de receita é 100. Use de 2 a 6 linhas.
- **Linhas de compra:**
  - Só o que gera crédito de IBS/CBS: mercadorias, insumos, serviços de PJ, aluguel de PJ, energia, frete, ativo imobilizado em média mensal.
  - Nunca inclua folha, pró-labore, tributos, juros ou tarifas bancárias.
  - Fornecedor do Simples puro: 7% da cheia.
  - Fornecedor com alíquota reduzida: a fração reduzida (ex.: 40 para −60%).
  - Compra de produtor rural não contribuinte: use crédito presumido em `credito_fixo_pct_valor_por_ano`, com estimativa e nota.
- **Coerência dos valores padrão:**
  - Os `padrao` dos `campos_especificos` devem reproduzir exatamente as linhas padrão.
  - `receita_mensal_padrao` e `caixa_exemplo` devem ser coerentes entre si e com o porte alvo.
  - Geração de caixa: margem operacional típica do setor.
- **Campos do formulário:**
  - De 5 a 14 campos específicos, no vocabulário do dono do negócio ("medição", "honorários", "safra", "convênio").
  - Cada campo diz em `alvos` o que altera: `linhas_receita.<id>.<atributo>`, `linhas_compra.<id>.<atributo>`, `receita_mensal`, `prazo_pagamento_fornecedor_dias`, `mensagem` ou `regra_especial`.
  - Em `derivacao`, a fórmula em texto.
  - Os campos comuns (caixa, limites, alíquotas, adesão) já existem em `contexto_global.json`; não repita.

## Simples Nacional

Para cada nicho, diga em `tratamento_tributario.simples_nacional` o que muda se a empresa estiver no Simples puro. O optante puro não destaca IBS/CBS por fora, não toma crédito e quase não sente o split. Se o nicho é majoritariamente Simples, a análise crítica deve dizer qual é a conversa certa: escolha entre Simples puro e regime regular, perda de clientes B2B, preço. Os `regras_especiais_calculo` devem dizer o que a calculadora faz quando o usuário escolhe "Simples puro".

## Pesquisa

- **Foco:** o que é específico do nicho.
  - Enquadramento legal (redução, anexo, regime específico, Imposto Seletivo, exceções); confirme NCM ou NBS quando a redução depende de lista.
  - Regras de crédito do setor.
  - Como o setor recebe (meios de pagamento, prazos, antecipação, adiantamentos, glosas, safra, medição, convênio).
  - Estrutura de compras (% da receita que gera crédito).
  - Particularidades: plataforma, cooperativa, exportação, obra pública, responsabilidade solidária, crédito presumido.
- **Fontes, em ordem de preferência:**
  1. Texto da LC 214/2025, LC 227/2026 e Decreto 12.955/2026 (espelhos como legjur.com, juruadocs.com, modeloinicial.com.br, camara.leg.br e normas.leg.br funcionam quando o Planalto bloquear).
  2. Receita Federal e CGIBS.
  3. Associações setoriais.
  4. Escritórios e consultorias tributárias reconhecidos.
  5. IBGE (PAC, PIA, PAS) e balanços de empresas do setor para estrutura de custos.
  6. Sebrae para prazos e meios de pagamento.
- **Datas mais recentes possíveis.** Se algo mudou em 2026 (LC 227, LC 235, resoluções do CGIBS, notas técnicas), use a versão nova.
- **Só cite páginas que você abriu.** Cada registro precisa de pelo menos 2 fontes com URL e data de acesso. Fontes podem se repetir entre nichos do mesmo lote.
- **Marque cada premissa operacional** como F (fato com fonte), E (estimativa com racional) ou H (hipótese a validar com o cliente). Estimativa é aceitável; inventar fonte não é.
- **Se não conseguir confirmar o enquadramento:**
  - coloque `status: "interpretacao"` ou `"estimativa"`;
  - use `confianca: "baixa"`;
  - registre em `pendencias_verificar`.
- **Direitos autorais:** parafraseie. Nenhuma citação literal longa.
- **Orçamento:** cerca de 3 a 6 buscas por nicho em média, mais algumas por categoria. Abra a fonte primária para afirmações legais.

## Análise crítica (obrigatória, mínimo 200 caracteres)

Escreva como um consultor experiente responderia:

- A calculadora de caixa faz sentido para esse nicho?
- Qual efeito domina: débito antecipado, recebível antecipado, crédito condicionado ou saldo credor?
- O que é contraintuitivo?
- Quais 2 ou 3 entradas mais mexem no resultado?
- Qual é a conversa que realmente vale dinheiro com esse cliente?

Se discordar do mapeamento preliminar (exposição ou prioridade), corrija em `split.exposicao` e `prioridade` e explique em uma frase.

## Estilo

Português do Brasil, frases curtas e diretas, palavras simples, números com unidade. Sem jargão desnecessário. Rótulos e ajudas do formulário escritos para o dono da empresa, não para o contador.

## Entrega

1. Grave seu lote como um array JSON em `out_<LOTE>.json` na mesma pasta (ex.: `out_L4.json`), com um registro por nicho do seu lote, na ordem dos ids.
2. Rode `node validate.js out_<LOTE>.json <ids separados por vírgula>` e corrija até aparecer "TUDO OK". Leia também os avisos e a prévia de resultado (% de um mês de receita em 2028). Se a prévia parecer absurda para o setor, reveja as premissas.
3. Responda com um resumo de até 200 palavras:
   - nichos feitos;
   - mudanças em relação ao mapeamento preliminar;
   - os 3 achados mais importantes do lote;
   - o que ficou sem confirmação.
