# -*- coding: utf-8 -*-
# Gera a planilha de leitura humana a partir de base_consolidada.json.
import json, sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

src = sys.argv[1]; dst = sys.argv[2]
b = json.load(open(src, encoding='utf-8'))
N = b['nichos']
F = 'Arial'
hf = Font(name=F, bold=True, color='FFFFFF', size=10); hfill = PatternFill('solid', fgColor='0D5F6B')
body = Font(name=F, size=10); wrap = Alignment(wrap_text=True, vertical='top'); thin = Side(style='thin', color='D3DCD9')
fills = {'alta': PatternFill('solid', fgColor='F8D7D3'), 'media': PatternFill('solid', fgColor='FBE8C8'), 'baixa': PatternFill('solid', fgColor='D7EEDD')}
sem = {'verde': PatternFill('solid', fgColor='D7EEDD'), 'amarelo': PatternFill('solid', fgColor='FBE8C8'), 'vermelho': PatternFill('solid', fgColor='F8D7D3')}
wb = Workbook()

def sheet(title, heads, widths, rows, idx=None, fmt=None, fill_col=None, fill_map=None):
    ws = wb.create_sheet(title) if idx is None else wb.active
    if idx is not None: ws.title = title
    for j, h in enumerate(heads, 1):
        c = ws.cell(row=1, column=j, value=h); c.font = hf; c.fill = hfill; c.alignment = Alignment(wrap_text=True, vertical='center', horizontal='center')
        ws.column_dimensions[get_column_letter(j)].width = widths[j - 1]
    for i, r in enumerate(rows, 2):
        for j, v in enumerate(r, 1):
            c = ws.cell(row=i, column=j, value=v); c.font = body; c.alignment = wrap; c.border = Border(bottom=thin)
            if fmt and j in fmt: c.number_format = fmt[j]
        if fill_col and r[fill_col - 1] in fill_map: ws.cell(row=i, column=fill_col).fill = fill_map[r[fill_col - 1]]
    ws.freeze_panes = 'C2'
    ws.auto_filter.ref = f'A1:{get_column_letter(len(heads))}{len(rows) + 1}'
    return ws

ws0 = wb.active; ws0.title = 'Leia primeiro'
txt = [
 ('Base de nichos do diagnóstico de caixa do split payment', True),
 (f"Versão {b['versao']}, data de referência {b['data_referencia']}. {b['descricao']}", False),
 ('', False),
 ('Arquivos da entrega', True),
 ('base-nichos-split.json: a base completa, para o prompt do site. Esta planilha é a versão de leitura e não tem todos os campos (fontes completas, perguntas e regras ficam no JSON).', False),
 ('engine_v2.js: o motor de cálculo que gerou os resultados de exemplo. dicionario-base.md: o significado de cada campo.', False),
 ('', False),
 ('Abas', True),
 ('Nichos: uma linha por nicho, com enquadramento, exposição, prioridade, resultado de exemplo e tese.', False),
 ('Linhas de receita e Linhas de compra: os valores padrão que o formulário carrega para cada nicho.', False),
 ('Campos do formulário: os campos específicos de cada nicho, com o que cada um altera no cálculo.', False),
 ('Resultado por ano: o capital de giro extra de 2027 a 2033 no exemplo padrão de cada nicho.', False),
 ('Fontes: as páginas consultadas por nicho.', False),
 ('revisao-base.md: o relatório do revisor, com as contradições resolvidas, as 491 mudanças e as pendências.', False),
 ('', False),
 ('Como ler o resultado', True),
 ('Percentuais em "% de um mês de receita": quanto capital de giro a mais a empresa precisa, dividido pela receita de um mês. Favorável: créditos abatem a retenção em até 48 h. Prudente: só na apuração mensal. Semáforo: teste de caixa de 2028 com o caixa de exemplo do nicho.', False),
 ('', False),
 ('Cuidados', True),
 (b['contexto_global']['aviso'], False),
 ('Os valores padrão são estimativas de um negócio típico, marcadas como F (fato), E (estimativa) ou H (hipótese) no JSON. Cada diagnóstico real precisa dos números do cliente.', False),
 ('Pendências de verificação estão listadas por nicho no JSON e no relatório de revisão.', False),
]
for i, (t, bold) in enumerate(txt, 1):
    c = ws0.cell(row=i, column=1, value=t); c.font = Font(name=F, size=14 if i == 1 else 10, bold=bold); c.alignment = Alignment(wrap_text=True, vertical='top')
ws0.column_dimensions['A'].width = 140

rows = []
for x in N:
    tt = x['tratamento_tributario']; re_ = x['resultado_exemplo']
    vendas = '; '.join(f"{v['item']}: {v['aliquota_pct_cheia']}% da cheia ({v['base_legal']})" for v in tt['vendas'])
    rows.append([x['id'], x['categoria'], x['nicho'], ', '.join(x['regimes_tipicos']), tt['resumo'], vendas, tt['credito_ao_cliente'],
                 x['split']['exposicao'], x['split']['quando'], x['prioridade'], x['confianca_geral'], x['receita_mensal_padrao'],
                 re_['pct_um_mes_receita_2028']['favoravel'] / 100, re_['pct_um_mes_receita_2028']['prudente'] / 100,
                 re_['pct_um_mes_receita_2033']['prudente'] / 100, re_['teste_caixa_2028']['semaforo'],
                 x['tese_consultoria'], x['analise_critica'], tt['simples_nacional']['tratamento'], '; '.join(x['pendencias_verificar'])])
sheet('Nichos', ['ID', 'Categoria', 'Nicho', 'Regimes típicos', 'Tratamento de IBS/CBS', 'Vendas: alíquota e base legal', 'Cliente PJ tem crédito?',
                 'Exposição ao split', 'Quando pega', 'Prioridade', 'Confiança', 'Receita mensal do exemplo (R$)',
                 '2028 favorável (% de um mês)', '2028 prudente (% de um mês)', '2033 prudente (% de um mês)', 'Semáforo 2028 do exemplo',
                 'Tese para a consultoria', 'Análise crítica', 'Se estiver no Simples puro', 'Pendências'],
      [8, 26, 34, 18, 46, 46, 24, 11, 26, 10, 10, 14, 12, 12, 12, 11, 40, 70, 46, 46], rows,
      fmt={12: '#,##0', 13: '0.0%', 14: '0.0%', 15: '0.0%'}, fill_col=8, fill_map=fills)
ws = wb['Nichos']
for i, r in enumerate(rows, 2):
    if r[15] in sem: ws.cell(row=i, column=16).fill = sem[r[15]]

lr = [[x['id'], x['nicho'], l['id'], l['nome'], l['participacao_pct'] / 100, l['cliente'], l['meio'], l['prazo_dias'], l['antecipado_pct'] / 100,
       l['aliquota_pct_cheia'] / 100, l['parcela_sujeita_split_pct'] / 100, 'sim' if l.get('aliquota_especifica_por_ano') else ''] for x in N for l in x['linhas_receita']]
sheet('Linhas de receita', ['ID', 'Nicho', 'Linha', 'Descrição', 'Participação na receita', 'Cliente', 'Meio', 'Prazo (dias)', 'Antecipado', 'Alíquota (% da cheia)', 'Parcela sujeita ao split', 'Alíquota específica por ano'],
      [8, 30, 18, 40, 12, 18, 16, 10, 11, 12, 12, 12], lr, fmt={5: '0.0%', 9: '0%', 10: '0%', 11: '0%'})
lc = [[x['id'], x['nicho'], c['id'], c['nome'], c['pct_receita'] / 100, (c['credito_pct_cheia'] / 100) if c.get('credito_pct_cheia') is not None else None,
       'sim' if c['condicionado'] else 'não', json.dumps(c['credito_fixo_pct_valor_por_ano'], ensure_ascii=False) if c.get('credito_fixo_pct_valor_por_ano') else '', x['prazo_pagamento_fornecedor_dias']] for x in N for c in x['linhas_compra']]
sheet('Linhas de compra', ['ID', 'Nicho', 'Linha', 'Descrição', '% da receita', 'Crédito (% da cheia)', 'Crédito condicionado?', 'Crédito fixo por ano (% do valor)', 'Prazo de pagamento ao fornecedor (dias)'],
      [8, 30, 18, 40, 11, 12, 12, 30, 14], lc, fmt={5: '0.0%', 6: '0%'})
cf = []
for x in N:
    for f in x['campos_especificos']:
        op = f.get('opcoes')
        op = '; '.join((f"{o.get('valor')}: {o.get('rotulo')}" if isinstance(o, dict) else str(o)) for o in op) if op else ''
        cf.append([x['id'], x['nicho'], f['id'], f['rotulo'], f['tipo'], f.get('unidade', ''), json.dumps(f['padrao'], ensure_ascii=False) if not isinstance(f['padrao'], (int, float, str)) else f['padrao'],
                   f.get('min', ''), f.get('max', ''), op, f['ajuda'], '; '.join(f['alvos']), f['derivacao']])
sheet('Campos do formulário', ['ID', 'Nicho', 'Campo', 'Rótulo', 'Tipo', 'Unidade', 'Padrão', 'Mín.', 'Máx.', 'Opções', 'Ajuda', 'Altera', 'Derivação'],
      [8, 30, 18, 36, 10, 10, 12, 8, 8, 30, 44, 40, 44], cf)
ra = [[x['id'], x['nicho'], str(y['ano']), y['aliquota_cheia_pct'] / 100, y['debito_mes'], y['credito_mes'], y['favoravel'], y['prudente'], y['novo_no_ano_prudente'],
       y['decomposicao_prudente']['debito_antecipado'], y['decomposicao_prudente']['credito_condicionado'], y['decomposicao_prudente']['saldo_credor'], y.get('saldo_credor_sem_split', 0)] for x in N for y in x['resultado_exemplo']['por_ano']]
sheet('Resultado por ano', ['ID', 'Nicho', 'Ano', 'Alíquota cheia CBS+IBS', 'Débito por mês (R$)', 'Crédito por mês (R$)', 'Favorável (R$)', 'Prudente (R$)', 'Novo no ano, prudente (R$)',
                            'Prudente: débito antecipado (R$)', 'Prudente: crédito condicionado (R$)', 'Prudente: saldo credor do split (R$)', 'Saldo credor que já existe sem split (R$, fora do total)'],
      [8, 30, 8, 12, 14, 14, 14, 14, 14, 14, 14, 14, 16], ra, fmt={4: '0.00%', **{k: '#,##0;(#,##0);-' for k in range(5, 14)}})
fo = [[x['id'], x['nicho'], s.get('titulo', ''), s.get('url', ''), s.get('acesso', '')] for x in N for s in x['fontes']]
sheet('Fontes', ['ID', 'Nicho', 'Título', 'URL', 'Acesso'], [8, 30, 60, 70, 12], fo)
wb.save(dst)
print('ok', dst, len(N), 'nichos', len(lr), 'linhas receita', len(lc), 'linhas compra', len(cf), 'campos', len(fo), 'fontes')
