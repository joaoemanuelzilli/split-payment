// Valida um arquivo de lote (array de registros de nicho). Uso: node validate.js <arquivo.json> [ids esperados separados por vírgula]
const fs = require('fs');
const path = require('path');
const E = require(path.join(__dirname, 'engine_v2.js'));
const G = JSON.parse(fs.readFileSync(path.join(__dirname, 'contexto_global.json'), 'utf8')).parametros_globais_padrao;

const CLIENTES = ['regime_regular', 'simples', 'consumidor_final', 'publico', 'exportacao', 'misto', 'produtor_nao_contribuinte', 'plataforma'];
const MEIOS = ['pix_ted', 'boleto', 'tef', 'medicao', 'adiantamento', 'cartao', 'voucher', 'repasse_financiamento', 'dinheiro', 'outro'];
const SEM_SPLIT_MEIO = ['cartao', 'voucher', 'dinheiro'];
const SEM_SPLIT_CLIENTE = ['consumidor_final', 'publico', 'exportacao', 'simples', 'produtor_nao_contribuinte'];
const TIPOS = ['moeda', 'percentual', 'dias', 'meses', 'numero', 'selecao', 'booleano'];
const NIVEIS = ['alta', 'media', 'baixa'];
const REQ = ['id', 'categoria_codigo', 'categoria', 'nicho', 'rotulo_menu', 'cnae', 'descricao_negocio', 'porte_alvo', 'regimes_tipicos',
  'tratamento_tributario', 'split', 'receita_mensal_padrao', 'linhas_receita', 'linhas_compra', 'prazo_pagamento_fornecedor_dias',
  'caixa_exemplo', 'campos_especificos', 'regras_especiais_calculo', 'perguntas_diagnostico', 'dados_para_coletar', 'analise_critica',
  'tese_consultoria', 'premissas_operacionais', 'riscos_pontos_abertos', 'prioridade', 'confianca_geral', 'pendencias_verificar', 'fontes'];

function check(rec) {
  const err = [], warn = [];
  for (const k of REQ) if (rec[k] === undefined) err.push(`falta ${k}`);
  if (err.length) return { err, warn };
  const tt = rec.tratamento_tributario;
  for (const k of ['resumo', 'vendas', 'credito_ao_cliente', 'regras_relevantes', 'simples_nacional']) if (tt[k] === undefined) err.push(`tratamento_tributario.${k} ausente`);
  if (!Array.isArray(tt.vendas) || !tt.vendas.length) err.push('tratamento_tributario.vendas vazio');
  for (const v of tt.vendas || []) { if (typeof v.aliquota_pct_cheia !== 'number') err.push(`vendas.${v.item}: aliquota_pct_cheia não numérica`); if (!v.base_legal) err.push(`vendas.${v.item}: sem base_legal`); if (!['lei', 'regulamento', 'interpretacao', 'estimativa'].includes(v.status)) err.push(`vendas.${v.item}: status inválido`); }
  if (!tt.simples_nacional || !tt.simples_nacional.tratamento) err.push('simples_nacional.tratamento ausente');
  if (!NIVEIS.includes(rec.split.exposicao)) err.push('split.exposicao inválida');
  if (!rec.split.quando) err.push('split.quando ausente');
  const ids = new Set();
  let soma = 0;
  for (const l of rec.linhas_receita) {
    if (!l.id || ids.has(l.id)) err.push(`linha_receita id inválido/duplicado: ${l.id}`); ids.add(l.id);
    if (!CLIENTES.includes(l.cliente)) err.push(`${l.id}: cliente inválido ${l.cliente}`);
    if (!MEIOS.includes(l.meio)) err.push(`${l.id}: meio inválido ${l.meio}`);
    for (const k of ['participacao_pct', 'prazo_dias', 'antecipado_pct', 'aliquota_pct_cheia', 'parcela_sujeita_split_pct']) if (typeof l[k] !== 'number' || !isFinite(l[k])) err.push(`${l.id}: ${k} não numérico`);
    if (l.participacao_pct < 0 || l.participacao_pct > 100) err.push(`${l.id}: participacao fora de 0-100`);
    if (l.parcela_sujeita_split_pct < 0 || l.parcela_sujeita_split_pct > 100) err.push(`${l.id}: parcela_sujeita_split fora de 0-100`);
    if (l.aliquota_pct_cheia < 0 || l.aliquota_pct_cheia > 100) err.push(`${l.id}: aliquota_pct_cheia fora de 0-100`);
    if (SEM_SPLIT_MEIO.includes(l.meio) && l.parcela_sujeita_split_pct > 0) err.push(`${l.id}: meio ${l.meio} está fora da etapa 1, parcela_sujeita_split deve ser 0`);
    if (SEM_SPLIT_CLIENTE.includes(l.cliente) && l.parcela_sujeita_split_pct > 0) err.push(`${l.id}: cliente ${l.cliente} não usa split na etapa 1, parcela deve ser 0`);
    if (l.cliente === 'regime_regular' && !SEM_SPLIT_MEIO.includes(l.meio) && l.parcela_sujeita_split_pct < 100) warn.push(`${l.id}: regime_regular por meio da etapa 1 normalmente tem parcela 100`);
    if (!l.nome) err.push(`${l.id}: sem nome`);
    soma += l.participacao_pct || 0;
  }
  if (Math.abs(soma - 100) > 1) err.push(`participacao_pct das linhas de receita soma ${soma}, deveria ser 100`);
  const cids = new Set();
  for (const c of rec.linhas_compra) {
    if (!c.id || cids.has(c.id) || ids.has(c.id)) err.push(`linha_compra id inválido/duplicado: ${c.id}`); cids.add(c.id);
    if (typeof c.pct_receita !== 'number' || c.pct_receita < 0 || c.pct_receita > 300) err.push(`${c.id}: pct_receita inválido`);
    if (c.credito_fixo_pct_valor_por_ano == null && (typeof c.credito_pct_cheia !== 'number' || c.credito_pct_cheia < 0 || c.credito_pct_cheia > 100)) err.push(`${c.id}: credito_pct_cheia inválido`);
    if (typeof c.condicionado !== 'boolean') err.push(`${c.id}: condicionado deve ser booleano`);
    if (!c.nome) err.push(`${c.id}: sem nome`);
  }
  if (typeof rec.prazo_pagamento_fornecedor_dias !== 'number') err.push('prazo_pagamento_fornecedor_dias não numérico');
  if (typeof rec.receita_mensal_padrao !== 'number' || rec.receita_mensal_padrao <= 0) err.push('receita_mensal_padrao inválida');
  const cx = rec.caixa_exemplo || {};
  for (const k of ['caixa', 'caixa_minimo', 'limites', 'custo_credito_pct_am', 'geracao_caixa_mes']) if (typeof cx[k] !== 'number') err.push(`caixa_exemplo.${k} não numérico`);
  const fids = new Set();
  if (!Array.isArray(rec.campos_especificos) || rec.campos_especificos.length < 3) err.push('campos_especificos precisa de pelo menos 3 campos');
  for (const f of rec.campos_especificos || []) {
    if (!f.id || fids.has(f.id)) err.push(`campo id inválido/duplicado: ${f.id}`); fids.add(f.id);
    if (!TIPOS.includes(f.tipo)) err.push(`campo ${f.id}: tipo inválido ${f.tipo}`);
    if (!f.rotulo || !f.ajuda) err.push(`campo ${f.id}: falta rotulo ou ajuda`);
    if (f.padrao === undefined) err.push(`campo ${f.id}: falta padrao`);
    if (f.tipo === 'selecao' && (!Array.isArray(f.opcoes) || f.opcoes.length < 2)) err.push(`campo ${f.id}: selecao sem opcoes`);
    if (!Array.isArray(f.alvos) || !f.alvos.length) err.push(`campo ${f.id}: sem alvos`);
    for (const a of f.alvos || []) {
      const m = a.match(/^(linhas_receita|linhas_compra)\.([^.]+)\.([a-z_]+)$/);
      if (m) { const set = m[1] === 'linhas_receita' ? ids : cids; if (!set.has(m[2])) err.push(`campo ${f.id}: alvo ${a} aponta para linha inexistente`); }
      else if (!['receita_mensal', 'prazo_pagamento_fornecedor_dias', 'mensagem', 'regra_especial'].includes(a)) err.push(`campo ${f.id}: alvo desconhecido ${a}`);
    }
    if (!f.derivacao) err.push(`campo ${f.id}: falta derivacao`);
  }
  if (!Array.isArray(rec.premissas_operacionais) || rec.premissas_operacionais.length < 3) err.push('premissas_operacionais: precisa de pelo menos 3');
  for (const q of rec.premissas_operacionais || []) { if (!q.premissa || q.valor === undefined || !['F', 'E', 'H'].includes(q.tipo) || !q.racional) err.push(`premissa incompleta: ${q.premissa}`); }
  if (![1, 2, 3].includes(rec.prioridade)) err.push('prioridade deve ser 1, 2 ou 3');
  if (!NIVEIS.includes(rec.confianca_geral)) err.push('confianca_geral inválida');
  if (!Array.isArray(rec.fontes) || rec.fontes.length < 2) err.push('fontes: precisa de pelo menos 2');
  for (const s of rec.fontes || []) if (!/^https?:\/\//.test(s.url || '')) err.push(`fonte sem url válida: ${s.titulo}`);
  if (typeof rec.analise_critica !== 'string' || rec.analise_critica.length < 200) err.push('analise_critica curta demais (mín. 200 caracteres)');
  try {
    const rows = E.run(rec, rec.receita_mensal_padrao, G);
    for (const r of rows) if (!isFinite(r.prud) || !isFinite(r.fav)) err.push(`motor gerou valor não finito em ${r.year}`);
    const r28 = rows[1];
    rec.__preview = { pct_mes_2028_prud: +(100 * r28.prud / rec.receita_mensal_padrao).toFixed(1), pct_mes_2028_fav: +(100 * r28.fav / rec.receita_mensal_padrao).toFixed(1) };
  } catch (e) { err.push('motor falhou: ' + e.message); }
  return { err, warn };
}

const file = process.argv[2];
const expected = process.argv[3] ? process.argv[3].split(',') : null;
const data = JSON.parse(fs.readFileSync(file, 'utf8'));
if (!Array.isArray(data)) { console.log('ERRO: o arquivo deve ser um array de registros'); process.exit(1); }
let total = 0;
const seen = new Set();
for (const rec of data) {
  const { err, warn } = check(rec);
  if (seen.has(rec.id)) err.push('id repetido no arquivo'); seen.add(rec.id);
  total += err.length;
  const p = rec.__preview ? ` | 2028: ${rec.__preview.pct_mes_2028_fav}% a ${rec.__preview.pct_mes_2028_prud}% de um mês de receita` : '';
  console.log(`${rec.id || '?'} ${rec.nicho || ''}: ${err.length ? 'ERROS ' + err.length : 'ok'}${p}`);
  for (const e of err) console.log('   ERRO  ' + e);
  for (const w of warn) console.log('   aviso ' + w);
}
if (expected) for (const id of expected) if (!seen.has(id)) { console.log(`ERRO: falta o nicho ${id}`); total++; }
console.log(total ? `\nTOTAL DE ERROS: ${total}` : '\nTUDO OK');
process.exit(total ? 1 : 0);
