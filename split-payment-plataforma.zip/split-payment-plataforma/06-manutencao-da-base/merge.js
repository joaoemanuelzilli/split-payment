// Junta os lotes, calcula o resultado de exemplo de cada nicho e grava a base consolidada.
// Uso: node merge.js [entrada1.json ...] (padrão: out_L1..out_L9.json) -> base_consolidada.json
const fs = require('fs'), path = require('path');
const dir = __dirname;
const E = require(path.join(dir, 'engine_v2.js'));
const ctx = JSON.parse(fs.readFileSync(path.join(dir, 'contexto_global.json'), 'utf8'));
const G = ctx.parametros_globais_padrao;
const input = JSON.parse(fs.readFileSync(path.join(dir, 'nichos_input.json'), 'utf8'));
const files = process.argv.slice(2).length ? process.argv.slice(2) : ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'L7', 'L8', 'L9'].map(l => `out_${l}.json`);
const outFile = process.env.OUT || 'base_consolidada.json';
let recs = [];
for (const f of files) {
  const p = path.join(dir, f);
  if (!fs.existsSync(p)) { console.log('falta', f); continue; }
  const arr = JSON.parse(fs.readFileSync(p, 'utf8'));
  const list = Array.isArray(arr) ? arr : arr.nichos;
  recs = recs.concat(list);
}
const byId = new Map();
for (const r of recs) { delete r.__preview; byId.set(r.id, r); }
const missing = input.filter(x => !byId.has(x.id)).map(x => x.id);
const round = v => Math.round(v);
const out = [];
for (const x of input) {
  const r = byId.get(x.id); if (!r) continue;
  const rows = E.run(r, r.receita_mensal_padrao, G);
  const c = Object.assign({ cdi_pct_aa: G.cdi_pct_aa }, r.caixa_exemplo);
  const t = rows.find(y => y.year === G.ano_teste);
  const ct = E.cashTest(t.prud, c);
  r.resultado_exemplo = {
    premissas: 'Valores padrão do nicho e parâmetros globais de contexto_global.json',
    por_ano: rows.map(y => ({ ano: y.year, aliquota_cheia_pct: +(y.rate * 100).toFixed(2), debito_mes: round(y.D), credito_mes: round(y.Cr),
      favoravel: round(y.fav), prudente: round(y.prud), novo_no_ano_prudente: round(y.novo_no_ano),
      decomposicao_prudente: { debito_antecipado: round(y.dVendas), credito_condicionado: round(y.credPrud), saldo_credor: round(y.trapPrud) },
      saldo_credor_sem_split: round(y.trapBase) })),
    pct_um_mes_receita_2028: { favoravel: +(100 * rows[1].fav / r.receita_mensal_padrao).toFixed(1), prudente: +(100 * rows[1].prud / r.receita_mensal_padrao).toFixed(1) },
    pct_um_mes_receita_2033: { favoravel: +(100 * rows[6].fav / r.receita_mensal_padrao).toFixed(1), prudente: +(100 * rows[6].prud / r.receita_mensal_padrao).toFixed(1) },
    teste_caixa_2028: { necessidade: round(ct.need), caixa_livre_usado: round(ct.fromCash), limites_usados: round(ct.fromCredit), falta: round(ct.gap),
      custo_anual: round(ct.costYear), custo_pct_geracao_caixa: isFinite(ct.pctFco) ? +(100 * ct.pctFco).toFixed(1) : null, semaforo: ct.verdict }
  };
  out.push(r);
}
const base = {
  versao: '1.1',
  data_referencia: ctx.data_referencia,
  descricao: 'Base de nichos para o diagnóstico de caixa do split payment de IBS/CBS. Cada nicho traz tratamento tributário, linhas de receita e compra com valores padrão, campos do formulário, premissas, análise crítica, fontes e um resultado de exemplo calculado pelo motor v2.',
  contexto_global: ctx,
  motor: {
    arquivo: 'engine_v2.js',
    resumo: [
      'Alíquota cheia do ano: CBS de referência em 2027-2028; de 2029 a 2033 soma o IBS cheio × rampa (10%, 20%, 30%, 40%, 100%).',
      'Débito por linha de receita = receita × participação × alíquota cheia × aliquota_pct_cheia (ou aliquota_especifica_por_ano).',
      'Efeito das vendas = débito × parcela_sujeita_split × adesão do ano × dias de imposto que saem do caixa / 30. Dias = média sobre o mês de max(0, vencimento − prazo) sem antecipação; max(vencimento, prazo) − 2 com antecipação. Vencimento = dia 60 contado do início do mês da venda.',
      'Crédito por linha de compra = receita × pct_receita × alíquota cheia × credito_pct_cheia (ou credito_fixo_pct_valor_por_ano). Linhas com condicionado = false não atrasam.',
      'Atraso do crédito condicionado: o débito do fornecedor é extinto no menor entre o seu prazo de pagamento e o vencimento dele. Prudente: o crédito só é usado na apuração do mês em que fica disponível. Favorável: abate a retenção em tempo real na parcela de débitos extintos pelo split.',
      'Saldo credor: se o crédito passa do débito em aberto na apuração (prudente) ou do débito total (favorável), a sobra fica em ressarcimento por ressarcimento_dias_extra. Desconta-se o saldo credor que já existiria sem split (crédito acima do débito total), informado à parte em saldo_credor_sem_split.',
      'Teste de caixa: caixa livre (caixa − mínimo), depois limites, e o resto é falta (aporte ou linha nova). Custo = juros do crédito e da falta + CDI sobre o caixa próprio usado. Semáforo: verde se o caixa livre cobre e o custo < 5% da geração de caixa; amarelo se não falta dinheiro e o custo < 15%; vermelho nos demais casos.'
    ]
  },
  nichos: out
};
fs.writeFileSync(path.join(dir, outFile), JSON.stringify(base, null, 1));
console.log(`gravado ${outFile}: ${out.length} nichos; faltando: ${missing.length ? missing.join(',') : 'nenhum'}`);
